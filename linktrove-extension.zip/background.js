const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./assets/pageMeta-Cp1CNcZM.js","./assets/preload-helper-CQrtv1eE.js"])))=>i.map(i=>d[i]);
var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k;
import { _ as __vitePreload } from "./assets/preload-helper-CQrtv1eE.js";
function createTabsManager(opts) {
  const { onChange } = opts;
  const created = (tab) => safe(() => onChange({ type: "created", payload: tab }));
  const removed = (tabId) => safe(() => onChange({ type: "removed", payload: { tabId } }));
  const updated = (tabId, changeInfo) => safe(() => onChange({ type: "updated", payload: { tabId, changeInfo } }));
  const activated = (activeInfo) => safe(() => onChange({ type: "activated", payload: activeInfo }));
  const replaced = (addedTabId, removedTabId) => safe(
    () => onChange({ type: "replaced", payload: { addedTabId, removedTabId } })
  );
  const moved = (tabId, moveInfo) => safe(() => onChange({ type: "moved", payload: { tabId, ...moveInfo } }));
  const attached = (tabId, attachInfo) => safe(
    () => onChange({ type: "attached", payload: { tabId, ...attachInfo } })
  );
  const detached = (tabId, detachInfo) => safe(
    () => onChange({ type: "detached", payload: { tabId, ...detachInfo } })
  );
  function removeListeners() {
    chrome.tabs.onCreated.removeListener(created);
    chrome.tabs.onRemoved.removeListener;
    chrome.tabs.onUpdated.removeListener;
    chrome.tabs.onActivated.removeListener(activated);
    chrome.tabs.onReplaced.removeListener(replaced);
  }
  async function hasRequiredPermissions() {
    return new Promise((resolve) => {
      var _a2;
      if (!((_a2 = chrome == null ? void 0 : chrome.permissions) == null ? void 0 : _a2.contains)) return resolve(true);
      chrome.permissions.contains(
        { permissions: ["tabs"] },
        (granted) => resolve(granted)
      );
    });
  }
  async function start() {
    const ok = await hasRequiredPermissions();
    if (!ok) throw new Error('Missing required "tabs" permission');
    removeListeners._created = created;
    removeListeners._removed = (tabId) => removed(tabId);
    removeListeners._updated = (tabId, ci) => updated(tabId, ci);
    removeListeners._activated = activated;
    removeListeners._replaced = replaced;
    removeListeners._moved = (tabId, mi) => moved(tabId, mi);
    removeListeners._attached = (tabId, ai) => attached(tabId, ai);
    removeListeners._detached = (tabId, di) => detached(tabId, di);
    chrome.tabs.onCreated.addListener(removeListeners._created);
    chrome.tabs.onRemoved.addListener(removeListeners._removed);
    chrome.tabs.onUpdated.addListener(removeListeners._updated);
    chrome.tabs.onActivated.addListener(removeListeners._activated);
    chrome.tabs.onReplaced.addListener(removeListeners._replaced);
    chrome.tabs.onMoved.addListener(removeListeners._moved);
    chrome.tabs.onAttached.addListener(removeListeners._attached);
    chrome.tabs.onDetached.addListener(removeListeners._detached);
  }
  function stop() {
    const rl = removeListeners;
    if (rl._created) chrome.tabs.onCreated.removeListener(rl._created);
    if (rl._removed) chrome.tabs.onRemoved.removeListener(rl._removed);
    if (rl._updated) chrome.tabs.onUpdated.removeListener(rl._updated);
    if (rl._activated) chrome.tabs.onActivated.removeListener(rl._activated);
    if (rl._replaced) chrome.tabs.onReplaced.removeListener(rl._replaced);
    if (rl._moved) chrome.tabs.onMoved.removeListener(rl._moved);
    if (rl._attached) chrome.tabs.onAttached.removeListener(rl._attached);
    if (rl._detached) chrome.tabs.onDetached.removeListener(rl._detached);
  }
  return { start, stop, hasRequiredPermissions };
}
function safe(fn) {
  try {
    fn();
  } catch (err) {
    console.error("tabsManager handler error", err);
  }
}
const clients = /* @__PURE__ */ new Set();
function tabToPayload(t) {
  return {
    id: t.id,
    title: t.title,
    url: t.url,
    favIconUrl: t.favIconUrl,
    index: t.index,
    windowId: t.windowId
  };
}
let started = false;
const tabsManager = createTabsManager({
  onChange: (evt) => {
    clients.forEach((p) => {
      try {
        p.postMessage({ kind: "tab-event", evt });
      } catch (err) {
        console.error("postMessage failed", err);
      }
    });
  }
});
async function boot() {
  try {
    if (!started) {
      await tabsManager.start();
      started = true;
      try {
        const { initPendingExtractionListeners } = await __vitePreload(async () => {
          const { initPendingExtractionListeners: initPendingExtractionListeners2 } = await import("./assets/pageMeta-Cp1CNcZM.js");
          return { initPendingExtractionListeners: initPendingExtractionListeners2 };
        }, true ? __vite__mapDeps([0,1]) : void 0, import.meta.url);
        initPendingExtractionListeners();
      } catch (err) {
        console.warn("Failed to initialize pending extraction listeners:", err);
      }
    }
  } catch (err) {
    console.error("Failed to start tabs manager", err);
  }
}
chrome.runtime.onInstalled.addListener(() => {
  boot();
});
(_b = (_a = chrome.runtime.onStartup) == null ? void 0 : _a.addListener) == null ? void 0 : _b.call(_a, () => {
  boot();
});
chrome.runtime.onConnect.addListener((port) => {
  var _a2, _b2;
  if (port.name !== "openTabs") return;
  boot();
  clients.add(port);
  (_b2 = (_a2 = chrome.windows).getLastFocused) == null ? void 0 : _b2.call(_a2, { populate: false }, (w) => {
    var _a3, _b3;
    const activeWindowId = w == null ? void 0 : w.id;
    (_b3 = (_a3 = chrome.windows).getAll) == null ? void 0 : _b3.call(_a3, { populate: false }, (wins) => {
      const windowIds = (wins || []).map((x) => x.id).filter((x) => typeof x === "number");
      chrome.tabs.query({}, (tabs) => {
        try {
          const payload = {
            kind: "init",
            activeWindowId,
            windowIds,
            tabs: tabs.map(tabToPayload)
          };
          port.postMessage(payload);
        } catch (err) {
          console.error("failed to send init tabs", err);
        }
      });
    });
  });
  port.onDisconnect.addListener(() => {
    clients.delete(port);
  });
});
(_e = (_d = (_c = chrome.windows) == null ? void 0 : _c.onFocusChanged) == null ? void 0 : _d.addListener) == null ? void 0 : _e.call(_d, (windowId) => {
  clients.forEach((p) => {
    try {
      p.postMessage({ kind: "window-focus", windowId });
    } catch {
    }
  });
});
(_h = (_g = (_f = chrome.windows) == null ? void 0 : _f.onCreated) == null ? void 0 : _g.addListener) == null ? void 0 : _h.call(_g, (win) => {
  clients.forEach((p) => {
    try {
      p.postMessage({
        kind: "window-event",
        evt: { type: "created", windowId: win == null ? void 0 : win.id }
      });
    } catch {
    }
  });
});
(_k = (_j = (_i = chrome.windows) == null ? void 0 : _i.onRemoved) == null ? void 0 : _j.addListener) == null ? void 0 : _k.call(_j, (windowId) => {
  clients.forEach((p) => {
    try {
      p.postMessage({
        kind: "window-event",
        evt: { type: "removed", windowId }
      });
    } catch {
    }
  });
});
//# sourceMappingURL=background.js.map

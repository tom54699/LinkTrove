async function ensureSubcategoriesMigrated() {
  try {
    const done = await getMeta("migratedSubcategoriesV1");
    if (done) return;
  } catch {
  }
  try {
    await tx(["categories", "subcategories", "webpages", "meta"], "readwrite", async (t) => {
      const metaS = t.objectStore("meta");
      const curFlag = await new Promise((resolve, reject) => {
        const rq = metaS.get("migratedSubcategoriesV1");
        rq.onsuccess = () => {
          var _a;
          return resolve((_a = rq.result) == null ? void 0 : _a.value);
        };
        rq.onerror = () => reject(rq.error);
      });
      if (curFlag) return;
      const catS = t.objectStore("categories");
      const subS = t.objectStore("subcategories");
      const pageS = t.objectStore("webpages");
      const cats = await new Promise((res, rej) => {
        const rq = catS.getAll();
        rq.onsuccess = () => res(rq.result || []);
        rq.onerror = () => rej(rq.error);
      });
      const subs = await new Promise((res, rej) => {
        try {
          const rq = subS.getAll();
          rq.onsuccess = () => res(rq.result || []);
          rq.onerror = () => rej(rq.error);
        } catch {
          res([]);
        }
      });
      const pages = await new Promise((res, rej) => {
        const rq = pageS.getAll();
        rq.onsuccess = () => res(rq.result || []);
        rq.onerror = () => rej(rq.error);
      });
      const hasAnySubByCat = {};
      for (const s of subs) hasAnySubByCat[s.categoryId] = true;
      const need = /* @__PURE__ */ new Set();
      for (const p of pages) if (p.category && !p.subcategoryId) need.add(p.category);
      const now = Date.now();
      const defaults = {};
      for (const cid of need) {
        if (!hasAnySubByCat[cid] && cats.some((c) => c.id === cid)) {
          const id = `g_default_${cid}`;
          const sc = { id, categoryId: cid, name: "group", order: 0, createdAt: now, updatedAt: now };
          subS.put(sc);
          defaults[cid] = sc;
        }
      }
      for (const p of pages) {
        if (!p.subcategoryId && p.category && defaults[p.category]) {
          p.subcategoryId = defaults[p.category].id;
          pageS.put(p);
        }
      }
      try {
        metaS.put({ key: "migratedSubcategoriesV1", value: true });
      } catch {
      }
    });
  } catch {
  }
}
function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("linktrove", 3);
    req.onblocked = () => {
    };
    req.onupgradeneeded = () => {
      var _a, _b, _c;
      const db = req.result;
      if (!db.objectStoreNames.contains("webpages")) {
        const s = db.createObjectStore("webpages", { keyPath: "id" });
        s.createIndex("category", "category");
        s.createIndex("url", "url");
        s.createIndex("updatedAt", "updatedAt");
        try {
          s.createIndex("category_subcategory", ["category", "subcategoryId"]);
        } catch {
        }
      }
      if (db.objectStoreNames.contains("webpages")) {
        const s = (_a = req.transaction) == null ? void 0 : _a.objectStore("webpages");
        try {
          if (s && !s.indexNames.contains("category_subcategory")) {
            s.createIndex("category_subcategory", ["category", "subcategoryId"]);
          }
        } catch {
        }
      }
      if (!db.objectStoreNames.contains("categories")) {
        const s = db.createObjectStore("categories", { keyPath: "id" });
        s.createIndex("order", "order");
        try {
          s.createIndex("by_organizationId", "organizationId");
        } catch {
        }
        try {
          s.createIndex("by_organizationId_order", ["organizationId", "order"]);
        } catch {
        }
      }
      if (db.objectStoreNames.contains("categories")) {
        const s = (_b = req.transaction) == null ? void 0 : _b.objectStore("categories");
        try {
          if (s && !s.indexNames.contains("by_organizationId")) s.createIndex("by_organizationId", "organizationId");
        } catch {
        }
        try {
          if (s && !s.indexNames.contains("by_organizationId_order")) s.createIndex("by_organizationId_order", ["organizationId", "order"]);
        } catch {
        }
      }
      if (!db.objectStoreNames.contains("templates")) {
        db.createObjectStore("templates", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("meta")) {
        db.createObjectStore("meta", { keyPath: "key" });
      }
      if (!db.objectStoreNames.contains("subcategories")) {
        const s = db.createObjectStore("subcategories", { keyPath: "id" });
        try {
          s.createIndex("by_categoryId", "categoryId");
        } catch {
        }
        try {
          s.createIndex("by_categoryId_order", ["categoryId", "order"]);
        } catch {
        }
      }
      if (db.objectStoreNames.contains("subcategories")) {
        const s = (_c = req.transaction) == null ? void 0 : _c.objectStore("subcategories");
        try {
          if (s && !s.indexNames.contains("by_categoryId")) s.createIndex("by_categoryId", "categoryId");
        } catch {
        }
        try {
          if (s && !s.indexNames.contains("by_categoryId_order")) s.createIndex("by_categoryId_order", ["categoryId", "order"]);
        } catch {
        }
      }
      if (!db.objectStoreNames.contains("organizations")) {
        const s = db.createObjectStore("organizations", { keyPath: "id" });
        try {
          s.createIndex("order", "order");
        } catch {
        }
      }
    };
    req.onsuccess = () => {
      const db = req.result;
      try {
        db.onversionchange = () => {
          try {
            db.close();
          } catch {
          }
        };
      } catch {
      }
      resolve(db);
    };
    req.onerror = () => reject(req.error);
  });
}
async function tx(stores, mode, fn) {
  const db = await openDb();
  const names = Array.isArray(stores) ? stores : [stores];
  const shouldNotify = mode === "readwrite" && names.some((n) => n === "webpages" || n === "categories" || n === "templates" || n === "subcategories" || n === "organizations");
  return new Promise((resolve, reject) => {
    const tr = db.transaction(names, mode);
    const done = (v) => resolve(v);
    const fail = (e) => reject(e);
    Promise.resolve(fn(tr)).then(done, fail);
    tr.oncomplete = () => {
      if (shouldNotify) {
        try {
          window.dispatchEvent(new CustomEvent("idb:changed", { detail: { stores: names } }));
        } catch {
        }
      }
    };
    tr.onerror = () => fail(tr.error);
    tr.onabort = () => fail(tr.error || new Error("tx aborted"));
  });
}
async function putAll(store, items) {
  await tx(store, "readwrite", async (t) => {
    const s = t.objectStore(store);
    for (const it of items) s.put(it);
  });
}
async function getAll(store) {
  if (store === "subcategories") {
    try {
      await ensureSubcategoriesMigrated();
    } catch {
    }
  }
  return tx(store, "readonly", async (t) => {
    const s = t.objectStore(store);
    return await new Promise((resolve, reject) => {
      const req = s.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  });
}
async function clearStore(store) {
  await tx(store, "readwrite", async (t) => {
    t.objectStore(store).clear();
  });
}
async function getMeta(key) {
  return tx("meta", "readonly", async (t) => {
    const s = t.objectStore("meta");
    return await new Promise((resolve, reject) => {
      const req = s.get(key);
      req.onsuccess = () => {
        var _a;
        return resolve((_a = req.result) == null ? void 0 : _a.value);
      };
      req.onerror = () => reject(req.error);
    });
  });
}
async function setMeta(key, value) {
  await tx("meta", "readwrite", async (t) => {
    const s = t.objectStore("meta");
    s.put({ key, value });
  });
}
export {
  clearStore,
  getAll,
  getMeta,
  openDb,
  putAll,
  setMeta,
  tx
};
//# sourceMappingURL=db-DtOJvepX.js.map

import { c as client, j as jsxRuntimeExports, A as AppProvider } from "./AppContext-DWoc0B_o.js";
import { R as React } from "./react-JydXHVGU.js";
import "./db-DtOJvepX.js";
function Popup() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 min-w-80", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "LinkTrove" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "opacity-80", children: "Popup ready." })
  ] });
}
client.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AppProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Popup, {}) }) })
);
//# sourceMappingURL=popup-afYe6P7L.js.map

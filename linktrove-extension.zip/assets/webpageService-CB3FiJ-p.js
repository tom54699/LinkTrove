const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./newtab-CEENaU6l.js","./AppContext-DWoc0B_o.js","./react-JydXHVGU.js","./db-DtOJvepX.js","./AppContext-Dx35MhF5.css","./preload-helper-CQrtv1eE.js","./newtab-DT9kj2ZB.css","./pageMeta-Cp1CNcZM.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-CQrtv1eE.js";
import { getMeta, tx, getAll, putAll, setMeta, clearStore } from "./db-DtOJvepX.js";
async function migrateOnce() {
  try {
    const migrated = await getMeta("migratedToIdb");
    if (migrated) return;
  } catch {
  }
  try {
    const localAny = await new Promise((resolve) => {
      var _a, _b, _c;
      try {
        (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { webpages: [] }, resolve);
      } catch {
        resolve({});
      }
    });
    const syncAny = await new Promise((resolve) => {
      var _a, _b, _c;
      try {
        (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.sync) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { categories: [], templates: [] }, resolve);
      } catch {
        resolve({});
      }
    });
    const webpages = Array.isArray(localAny == null ? void 0 : localAny.webpages) ? localAny.webpages : [];
    const categories = Array.isArray(syncAny == null ? void 0 : syncAny.categories) ? syncAny.categories : [];
    const templates = Array.isArray(syncAny == null ? void 0 : syncAny.templates) ? syncAny.templates : [];
    if (webpages.length + categories.length + templates.length > 0) {
      if (webpages.length) await putAll("webpages", webpages);
      if (categories.length) await putAll("categories", categories);
      if (templates.length) await putAll("templates", templates);
    }
  } catch {
  }
  try {
    await setMeta("migratedToIdb", true);
  } catch {
  }
}
function createIdbStorageService() {
  void migrateOnce();
  void migrateOrganizationsOnce();
  void migrateSubcategoriesOnce();
  async function listSubcategoriesImpl(categoryId) {
    return await tx(["subcategories"], "readonly", async (t) => {
      const s = t.objectStore("subcategories");
      try {
        if (s.indexNames.contains("by_categoryId")) {
          const idx = s.index("by_categoryId");
          const range = IDBKeyRange.only(categoryId);
          const rows = await new Promise((resolve, reject) => {
            const req = idx.getAll(range);
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          const byId = /* @__PURE__ */ new Map();
          for (const r of rows) if (!byId.has(r.id)) byId.set(r.id, r);
          return Array.from(byId.values()).filter((x) => !x.deleted).sort((a, b) => {
            var _a, _b;
            return ((_a = a.order) != null ? _a : 0) - ((_b = b.order) != null ? _b : 0);
          });
        }
      } catch {
      }
      try {
        const all = await new Promise((resolve, reject) => {
          const req = s.getAll();
          req.onsuccess = () => resolve(req.result || []);
          req.onerror = () => reject(req.error);
        });
        const byId = /* @__PURE__ */ new Map();
        for (const r of all) if (!byId.has(r.id)) byId.set(r.id, r);
        return Array.from(byId.values()).filter((x) => x.categoryId === categoryId && !x.deleted).sort((a, b) => {
          var _a, _b;
          return ((_a = a.order) != null ? _a : 0) - ((_b = b.order) != null ? _b : 0);
        });
      } catch {
        return [];
      }
    });
  }
  async function migrateOrganizationsOnce() {
    try {
      const done = await getMeta("migratedOrganizationsV1");
      if (done) return;
    } catch {
    }
    try {
      const orgId = "o_default";
      await tx("organizations", "readwrite", async (t) => {
        const s = t.objectStore("organizations");
        try {
          const existing = await new Promise((resolve, reject) => {
            const req = s.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          if ((existing || []).length === 0) {
            s.put({ id: orgId, name: "Personal", color: "#64748b", order: 0 });
          }
        } catch {
          try {
            s.put({ id: orgId, name: "Personal", color: "#64748b", order: 0 });
          } catch {
          }
        }
      });
      const categories = await getAll("categories");
      if (categories.length) {
        const next = categories.map(
          (c) => !("organizationId" in c) || !c.organizationId ? { ...c, organizationId: "o_default" } : c
        );
        const byOrg = {};
        for (const c of next) {
          const oid = c.organizationId || "o_default";
          if (!byOrg[oid]) byOrg[oid] = [];
          byOrg[oid].push(c);
        }
        for (const [oid, list] of Object.entries(byOrg)) {
          list.sort((a, b) => {
            var _a, _b;
            return ((_a = a.order) != null ? _a : 0) - ((_b = b.order) != null ? _b : 0) || String(a.name || "").localeCompare(String(b.name || ""));
          });
          let i = 0;
          for (const c of list) c.order = i++;
        }
        await putAll("categories", next);
      }
    } catch {
    }
    try {
      await setMeta("migratedOrganizationsV1", true);
    } catch {
    }
  }
  async function migrateSubcategoriesOnce() {
    try {
      const done = await getMeta("migratedSubcategoriesV1");
      if (done) return;
    } catch {
    }
    try {
      const [categories, subcats, pages] = await Promise.all([
        getAll("categories"),
        getAll("subcategories").catch(() => []),
        getAll("webpages")
      ]);
      const now = Date.now();
      const byCatHasAny = {};
      for (const sc of subcats) byCatHasAny[sc.categoryId] = true;
      const defaults = {};
      const toCreate = [];
      for (const c of categories) {
        if (!byCatHasAny[c.id]) {
          const id = `g_default_${c.id}`;
          const sc = {
            id,
            categoryId: c.id,
            name: "group",
            order: 0,
            createdAt: now,
            updatedAt: now
          };
          defaults[c.id] = sc;
          toCreate.push(sc);
        }
      }
      if (toCreate.length) {
        const current = await getAll("subcategories").catch(() => []);
        const curByCat = {};
        for (const sc of current) curByCat[sc.categoryId] = true;
        const filtered = toCreate.filter((sc) => !curByCat[sc.categoryId]);
        if (filtered.length) await putAll("subcategories", filtered);
      }
      const toUpdate = [];
      for (const p of pages) {
        if (!p.subcategoryId) {
          const def = defaults[p.category];
          if (def) {
            p.subcategoryId = def.id;
            toUpdate.push(p);
          }
        }
      }
      if (toUpdate.length) await putAll("webpages", toUpdate);
    } catch {
    }
    try {
      await setMeta("migratedSubcategoriesV1", true);
    } catch {
    }
  }
  async function exportData() {
    const [webpages, categories, templates, subcategories, organizations] = await Promise.all([
      getAll("webpages"),
      getAll("categories"),
      getAll("templates"),
      getAll("subcategories").catch(() => []),
      getAll("organizations").catch(() => [])
    ]);
    let theme = void 0;
    let selectedCategoryId = void 0;
    let selectedOrganizationId = void 0;
    try {
      const got = await new Promise((resolve) => {
        var _a, _b, _c;
        try {
          (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(
            _b,
            { theme: void 0, selectedCategoryId: void 0, selectedOrganizationId: void 0 },
            resolve
          );
        } catch {
          resolve({});
        }
      });
      theme = got == null ? void 0 : got.theme;
      selectedCategoryId = got == null ? void 0 : got.selectedCategoryId;
      selectedOrganizationId = got == null ? void 0 : got.selectedOrganizationId;
    } catch {
    }
    if (theme === void 0) {
      try {
        theme = await getMeta("settings.theme");
      } catch {
        theme = void 0;
      }
    }
    if (selectedCategoryId === void 0) {
      try {
        selectedCategoryId = await getMeta("settings.selectedCategoryId");
      } catch {
        selectedCategoryId = void 0;
      }
    }
    if (selectedOrganizationId === void 0) {
      try {
        selectedOrganizationId = await getMeta("settings.selectedOrganizationId");
      } catch {
        selectedOrganizationId = void 0;
      }
    }
    const settings = {};
    if (theme !== void 0) settings.theme = theme;
    if (selectedCategoryId !== void 0)
      settings.selectedCategoryId = selectedCategoryId;
    if (selectedOrganizationId !== void 0)
      settings.selectedOrganizationId = selectedOrganizationId;
    const orders = { subcategories: {} };
    try {
      for (const sc of subcategories) {
        const key = `order.subcat.${sc.id}`;
        try {
          const vals = await getMeta(key) || [];
          if (Array.isArray(vals) && vals.length > 0) orders.subcategories[sc.id] = vals.slice();
        } catch {
        }
      }
    } catch {
    }
    const payload = {
      schemaVersion: 1,
      webpages,
      categories,
      templates,
      subcategories,
      organizations,
      settings,
      orders,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    return JSON.stringify(payload);
  }
  async function importData(jsonData) {
    let parsed;
    try {
      parsed = JSON.parse(jsonData);
    } catch {
      throw new Error("Invalid JSON");
    }
    const pages = Array.isArray(parsed == null ? void 0 : parsed.webpages) ? parsed.webpages : [];
    const cats = Array.isArray(parsed == null ? void 0 : parsed.categories) ? parsed.categories : [];
    const tmpls = Array.isArray(parsed == null ? void 0 : parsed.templates) ? parsed.templates : [];
    const subcats = Array.isArray(parsed == null ? void 0 : parsed.subcategories) ? parsed.subcategories : [];
    const orgs = Array.isArray(parsed == null ? void 0 : parsed.organizations) ? parsed.organizations : [];
    const ordersObj = parsed == null ? void 0 : parsed.orders;
    const ordersSubcats = ordersObj && ordersObj.subcategories && typeof ordersObj.subcategories === "object" ? ordersObj.subcategories : {};
    if (!Array.isArray(pages)) throw new Error("Invalid webpages payload");
    if (!Array.isArray(cats)) throw new Error("Invalid categories payload");
    if (!Array.isArray(tmpls)) throw new Error("Invalid templates payload");
    await clearStore("categories");
    await clearStore("templates");
    await clearStore("subcategories");
    await clearStore("organizations");
    await clearStore("webpages");
    if (orgs.length) await putAll("organizations", orgs);
    if (!orgs.length) {
      try {
        await tx("organizations", "readwrite", async (t) => {
          const s = t.objectStore("organizations");
          const def = { id: "o_default", name: "Personal", color: "#64748b", order: 0 };
          s.put(def);
        });
      } catch {
      }
    }
    const catsNormalized = cats.map(
      (c) => "organizationId" in c && c.organizationId ? c : { ...c, organizationId: "o_default" }
    );
    if (catsNormalized.length) await putAll("categories", catsNormalized);
    if (tmpls.length) await putAll("templates", tmpls);
    if (subcats.length) await putAll("subcategories", subcats);
    if (pages.length) await putAll("webpages", pages);
    try {
      const presentGroups = new Set(subcats.map((s) => s.id));
      for (const [gid, arr] of Object.entries(ordersSubcats || {})) {
        if (!presentGroups.has(gid)) continue;
        const key = `order.subcat.${gid}`;
        try {
          const ids = Array.isArray(arr) ? arr : [];
          await setMeta(key, ids);
        } catch {
        }
      }
    } catch {
    }
  }
  return {
    // naming preserved for compatibility; replace full set to persist deletions
    saveToLocal: async (data) => {
      await clearStore("webpages");
      await putAll("webpages", data || []);
    },
    loadFromLocal: async () => {
      const all = await getAll("webpages");
      return all.filter((w) => !w.deleted);
    },
    // Replace categories set to ensure deletions persist
    saveToSync: async (data) => {
      await clearStore("categories");
      await putAll("categories", data || []);
    },
    loadFromSync: async () => {
      const all = await getAll("categories");
      return all.filter((c) => !c.deleted);
    },
    // Replace templates set to ensure deletions persist
    saveTemplates: async (data) => {
      await clearStore("templates");
      await putAll("templates", data || []);
    },
    loadTemplates: async () => {
      const all = await getAll("templates");
      return all.filter((t) => !t.deleted);
    },
    exportData,
    importData,
    // Subcategories (groups)
    listSubcategories: async (categoryId) => listSubcategoriesImpl(categoryId),
    createSubcategory: async (categoryId, name) => {
      var _a, _b;
      const list = await listSubcategoriesImpl(categoryId);
      const exists = list.find(
        (g) => String(g.name || "").toLowerCase() === String(name || "").toLowerCase()
      );
      if (exists) return exists;
      const now = Date.now();
      const id = "g_" + Math.random().toString(36).slice(2, 9);
      const sc = { id, categoryId, name, order: ((_b = (_a = list[list.length - 1]) == null ? void 0 : _a.order) != null ? _b : -1) + 1, createdAt: now, updatedAt: now };
      await tx(["subcategories"], "readwrite", async (t) => {
        const s = t.objectStore("subcategories");
        try {
          const all = await new Promise((resolve, reject) => {
            const req = s.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          const dup = all.find(
            (g) => g.categoryId === categoryId && String(g.name || "").toLowerCase() === String(name || "").toLowerCase()
          );
          if (dup) return;
        } catch {
        }
        s.put(sc);
      });
      return sc;
    },
    renameSubcategory: async (id, name) => {
      await tx(["subcategories"], "readwrite", async (t) => {
        const s = t.objectStore("subcategories");
        const cur = await new Promise((resolve, reject) => {
          const req = s.get(id);
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        });
        if (!cur) return;
        cur.name = name;
        cur.updatedAt = Date.now();
        s.put(cur);
      });
    },
    deleteSubcategory: async (id, reassignTo) => {
      await tx(["subcategories", "webpages"], "readwrite", async (t) => {
        const ss = t.objectStore("subcategories");
        const ws = t.objectStore("webpages");
        const cur = await new Promise((resolve, reject) => {
          const req = ss.get(id);
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        });
        if (!cur) return;
        const target = await new Promise((resolve, reject) => {
          const req = ss.get(reassignTo);
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        });
        if (!target || target.categoryId !== cur.categoryId) {
          throw new Error("Invalid reassign target");
        }
        const idx = (() => {
          try {
            return ws.index("category_subcategory");
          } catch {
            return null;
          }
        })();
        const pages = await new Promise((resolve, reject) => {
          if (idx) {
            const range = IDBKeyRange.only([cur.categoryId, id]);
            const req = idx.getAll(range);
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          } else {
            const rq = ws.getAll();
            rq.onsuccess = () => resolve((rq.result || []).filter((p) => p.category === cur.categoryId && p.subcategoryId === id));
            rq.onerror = () => reject(rq.error);
          }
        });
        for (const p of pages) {
          p.subcategoryId = reassignTo;
          ws.put(p);
        }
        ss.delete(id);
      });
      try {
        await setMeta(`order.subcat.${id}`, []);
      } catch {
      }
    },
    // Delete the subcategory and all webpages referencing it in one transaction
    deleteSubcategoryAndPages: async (id) => {
      await tx(["subcategories", "webpages"], "readwrite", async (t) => {
        const ss = t.objectStore("subcategories");
        const ws = t.objectStore("webpages");
        const cur = await new Promise((resolve, reject) => {
          const req = ss.get(id);
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        });
        if (!cur) return;
        const pages = await new Promise((resolve, reject) => {
          let idx = null;
          try {
            idx = ws.index("category_subcategory");
          } catch {
          }
          if (idx) {
            const range = IDBKeyRange.only([cur.categoryId, id]);
            const req = idx.getAll(range);
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          } else {
            const rq = ws.getAll();
            rq.onsuccess = () => resolve((rq.result || []).filter((p) => p.category === cur.categoryId && p.subcategoryId === id));
            rq.onerror = () => reject(rq.error);
          }
        });
        for (const p of pages) ws.delete(p.id);
        ss.delete(id);
      });
      try {
        await setMeta(`order.subcat.${id}`, []);
      } catch {
      }
    },
    reorderSubcategories: async (categoryId, orderedIds) => {
      await tx(["subcategories"], "readwrite", async (t) => {
        const s = t.objectStore("subcategories");
        let order = 0;
        for (const id of orderedIds) {
          const cur = await new Promise((resolve, reject) => {
            const req = s.get(id);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
          });
          if (!cur || cur.categoryId !== categoryId) continue;
          cur.order = order++;
          cur.updatedAt = Date.now();
          s.put(cur);
        }
      });
    },
    updateCardSubcategory: async (cardId, subcategoryId) => {
      await tx("webpages", "readwrite", async (t) => {
        const s = t.objectStore("webpages");
        const cur = await new Promise((resolve, reject) => {
          const req = s.get(cardId);
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        });
        if (!cur) return;
        const prev = cur.subcategoryId;
        const next = subcategoryId;
        cur.subcategoryId = next;
        cur.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        s.put(cur);
        try {
          if (prev && prev !== next) {
            const keyPrev = `order.subcat.${prev}`;
            const prevOrder = (await getMeta(keyPrev) || []).filter((x) => x !== cardId);
            await setMeta(keyPrev, prevOrder);
          }
          if (next) {
            const keyNext = `order.subcat.${next}`;
            const nextOrder = (await getMeta(keyNext) || []).filter((x) => x !== cardId);
            nextOrder.push(cardId);
            await setMeta(keyNext, nextOrder);
          }
        } catch {
        }
      });
    },
    deleteSubcategoriesByCategory: async (categoryId) => {
      let deletedIds = [];
      await tx(["subcategories"], "readwrite", async (t) => {
        const s = t.objectStore("subcategories");
        try {
          const idx = s.index("by_categoryId");
          const range = IDBKeyRange.only(categoryId);
          const list = await new Promise((resolve, reject) => {
            const req = idx.getAll(range);
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          for (const it of list) {
            s.delete(it.id);
            deletedIds.push(it.id);
          }
        } catch {
          const all = await new Promise((resolve, reject) => {
            const req = s.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          for (const it of all) {
            if (it.categoryId === categoryId) {
              s.delete(it.id);
              deletedIds.push(it.id);
            }
          }
        }
      });
      for (const id of deletedIds) {
        try {
          await setMeta(`order.subcat.${id}`, []);
        } catch {
        }
      }
    },
    // Cleanup orphaned meta records
    cleanupOrphanedOrderMeta: async () => {
      const subcategories = await getAll("subcategories").catch(() => []);
      const validGroupIds = new Set(subcategories.map((sc) => sc.id));
      const metaKeys = await tx("meta", "readonly", async (t) => {
        const s = t.objectStore("meta");
        const allKeys = [];
        return new Promise((resolve) => {
          const req = s.openCursor();
          req.onsuccess = (event) => {
            const cursor = event.target.result;
            if (cursor) {
              const key = cursor.key;
              if (key.startsWith("order.subcat.")) {
                allKeys.push(key);
              }
              cursor.continue();
            } else {
              resolve(allKeys);
            }
          };
          req.onerror = () => resolve([]);
        });
      });
      let cleanedCount = 0;
      for (const key of metaKeys) {
        const groupId = key.replace("order.subcat.", "");
        if (!validGroupIds.has(groupId)) {
          try {
            await setMeta(key, []);
            cleanedCount++;
          } catch {
          }
        }
      }
      return { cleanedCount, totalOrderKeys: metaKeys.length };
    },
    // Organizations API
    listOrganizations: async () => {
      const list = await getAll("organizations").catch(() => []);
      const arr = Array.isArray(list) ? list.slice() : [];
      const filtered = arr.filter((o) => !o.deleted);
      filtered.sort(
        (a, b) => {
          var _a, _b;
          return ((_a = a.order) != null ? _a : 0) - ((_b = b.order) != null ? _b : 0) || String(a.name || "").localeCompare(String(b.name || ""));
        }
      );
      return filtered;
    },
    createOrganization: async (name, color) => {
      const existing = await getAll("organizations").catch(() => []);
      const order = existing.length ? Math.max(...existing.map((o) => {
        var _a;
        return (_a = o.order) != null ? _a : 0;
      })) + 1 : 0;
      const org = { id: "o_" + Math.random().toString(36).slice(2, 9), name: (name || "Org").trim() || "Org", color, order };
      await tx("organizations", "readwrite", async (t) => {
        t.objectStore("organizations").put(org);
      });
      return org;
    },
    renameOrganization: async (id, name) => {
      await tx("organizations", "readwrite", async (t) => {
        const s = t.objectStore("organizations");
        const cur = await new Promise((resolve, reject) => {
          const req = s.get(id);
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        });
        if (!cur) return;
        cur.name = (name || "").trim() || cur.name;
        s.put(cur);
      });
    },
    deleteOrganization: async (id, options) => {
      await tx(["organizations", "categories"], "readwrite", async (t) => {
        var _a;
        const os = t.objectStore("organizations");
        const cs = t.objectStore("categories");
        let targetId = (options == null ? void 0 : options.reassignTo) || "o_default";
        const orgs = await new Promise((resolve, reject) => {
          const req = os.getAll();
          req.onsuccess = () => resolve(req.result || []);
          req.onerror = () => reject(req.error);
        });
        if (!orgs.some((o) => o.id === targetId) || targetId === id) {
          const alt = orgs.find((o) => o.id !== id);
          if (alt) targetId = alt.id;
          else {
            const def = { id: "o_default", name: "Personal", color: "#64748b", order: 0 };
            os.put(def);
            targetId = def.id;
          }
        }
        const cats = await new Promise((resolve, reject) => {
          const req = cs.getAll();
          req.onsuccess = () => resolve(req.result || []);
          req.onerror = () => reject(req.error);
        });
        let base = 0;
        for (const c of cats) if (c.organizationId === targetId) base = Math.max(base, (_a = c.order) != null ? _a : 0);
        for (const c of cats) {
          if (c.organizationId === id) {
            c.organizationId = targetId;
            c.order = ++base;
            cs.put(c);
          }
        }
        os.delete(id);
      });
    },
    reorderOrganizations: async (orderedIds) => {
      await tx("organizations", "readwrite", async (t) => {
        const s = t.objectStore("organizations");
        const byId = /* @__PURE__ */ new Map();
        try {
          const all = await new Promise((resolve, reject) => {
            const req = s.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          for (const o of all) byId.set(o.id, o);
        } catch {
        }
        let i = 0;
        for (const id of orderedIds) {
          const o = byId.get(id);
          if (!o) continue;
          o.order = i++;
          s.put(o);
          byId.delete(id);
        }
        for (const o of byId.values()) {
          o.order = i++;
          s.put(o);
        }
      });
    },
    // Categories helpers scoped by organization
    addCategory: async (name, color, organizationId) => {
      const orgId = organizationId || "o_default";
      const id = "c_" + Math.random().toString(36).slice(2, 9);
      let nextOrder = 0;
      try {
        await tx("categories", "readonly", async (t) => {
          const s = t.objectStore("categories");
          try {
            const idx = s.index("by_organizationId_order");
            const range = IDBKeyRange.bound([orgId, -Infinity], [orgId, Infinity]);
            const list = await new Promise((resolve, reject) => {
              const req = idx.getAll(range);
              req.onsuccess = () => resolve(req.result || []);
              req.onerror = () => reject(req.error);
            });
            nextOrder = list.length ? Math.max(...list.map((c) => {
              var _a;
              return (_a = c.order) != null ? _a : 0;
            })) + 1 : 0;
          } catch {
            const list = await new Promise((resolve, reject) => {
              const rq = s.getAll();
              rq.onsuccess = () => resolve(rq.result || []);
              rq.onerror = () => reject(rq.error);
            });
            nextOrder = list.filter((c) => c.organizationId === orgId).length;
          }
        });
      } catch {
      }
      const cat = {
        id,
        name: (name || "Collection").trim() || "Collection",
        color: color || "#64748b",
        order: nextOrder,
        organizationId: orgId
      };
      await tx("categories", "readwrite", async (t) => {
        t.objectStore("categories").put(cat);
      });
      return cat;
    },
    reorderCategories: async (categoryIds, organizationId) => {
      await tx("categories", "readwrite", async (t) => {
        const s = t.objectStore("categories");
        const all = await new Promise((resolve, reject) => {
          const req = s.getAll();
          req.onsuccess = () => resolve(req.result || []);
          req.onerror = () => reject(req.error);
        });
        const byId = new Map(all.filter((c) => c.organizationId === organizationId).map((c) => [c.id, c]));
        let i = 0;
        for (const id of categoryIds) {
          const c = byId.get(id);
          if (!c) continue;
          c.order = i++;
          s.put(c);
          byId.delete(id);
        }
        for (const c of byId.values()) {
          c.order = i++;
          s.put(c);
        }
      });
    },
    updateCategoryOrganization: async (categoryId, toOrganizationId) => {
      await tx("categories", "readwrite", async (t) => {
        const s = t.objectStore("categories");
        const cur = await new Promise((resolve, reject) => {
          const req = s.get(categoryId);
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => reject(req.error);
        });
        if (!cur) return;
        let nextOrder = 0;
        try {
          const all = await new Promise((resolve, reject) => {
            const rq = s.getAll();
            rq.onsuccess = () => resolve(rq.result || []);
            rq.onerror = () => reject(rq.error);
          });
          nextOrder = all.filter((c) => c.organizationId === toOrganizationId).length;
        } catch {
        }
        cur.organizationId = toOrganizationId;
        cur.order = nextOrder;
        s.put(cur);
      });
    }
  };
}
function createStorageService() {
  return createIdbStorageService();
}
const storageService = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createStorageService
}, Symbol.toStringTag, { value: "Module" }));
function createWebpageService(deps) {
  const storage = createStorageService();
  const recentlyAdded = /* @__PURE__ */ new Map();
  function nowIso() {
    return (/* @__PURE__ */ new Date()).toISOString();
  }
  function normalizeUrl(raw) {
    if (!raw) throw new Error("Missing URL");
    let url;
    try {
      url = new URL(raw);
    } catch {
      throw new Error("Invalid URL");
    }
    if (!/^https?:$/.test(url.protocol))
      throw new Error("Unsupported URL protocol");
    return url.toString();
  }
  function cleanTitle(t, fallback) {
    const title = (t != null ? t : "").trim();
    if (title) return title;
    if (fallback) {
      try {
        return new URL(fallback).hostname;
      } catch {
      }
    }
    return "Untitled";
  }
  function genId(url) {
    return "w_" + Math.random().toString(36).slice(2, 9) + "_" + Math.abs(hash(url)).toString(36);
  }
  function hash(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
    return h | 0;
  }
  async function getGroupOrder(gid) {
    try {
      const v = await getMeta(`order.subcat.${gid}`);
      return Array.isArray(v) ? v : [];
    } catch {
      return [];
    }
  }
  async function setGroupOrder(gid, ids) {
    try {
      await setMeta(`order.subcat.${gid}`, ids);
    } catch {
    }
  }
  async function loadWebpages() {
    let list = await storage.loadFromLocal();
    const index = new Map(list.map((w, i) => [w.id, i]));
    try {
      const groupIds = Array.from(
        new Set(list.map((w) => w.subcategoryId).filter(Boolean))
      );
      const orders = await Promise.all(groupIds.map((g) => getGroupOrder(g)));
      const posMap = new Map(
        groupIds.map((g, i) => [g, new Map(orders[i].map((id, j) => [id, j]))])
      );
      const groupOrderMap = /* @__PURE__ */ new Map();
      groupIds.forEach((gid, idx) => groupOrderMap.set(gid, idx));
      const sorted = [...list].sort((a, b) => {
        var _a, _b, _c, _d, _e, _f;
        const ga = a.subcategoryId;
        const gb = b.subcategoryId;
        if (ga && gb && ga === gb) {
          const pm = posMap.get(ga);
          const ia = (_a = pm == null ? void 0 : pm.get(a.id)) != null ? _a : Number.MAX_SAFE_INTEGER;
          const ib = (_b = pm == null ? void 0 : pm.get(b.id)) != null ? _b : Number.MAX_SAFE_INTEGER;
          if (ia !== ib) {
            return ia - ib;
          }
        } else if (ga && gb) {
          const groupOrderA = (_c = groupOrderMap.get(ga)) != null ? _c : Number.MAX_SAFE_INTEGER;
          const groupOrderB = (_d = groupOrderMap.get(gb)) != null ? _d : Number.MAX_SAFE_INTEGER;
          if (groupOrderA !== groupOrderB) {
            return groupOrderA - groupOrderB;
          }
        }
        const fallbackA = (_e = index.get(a.id)) != null ? _e : 0;
        const fallbackB = (_f = index.get(b.id)) != null ? _f : 0;
        return fallbackA - fallbackB;
      });
      return sorted;
    } catch {
      return list;
    }
  }
  async function saveWebpages(all) {
    var _a, _b, _c;
    try {
      await storage.saveToLocal(all);
    } catch {
    }
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { webpages: all });
    } catch {
    }
  }
  async function addWebpageFromTab(tab) {
    var _a;
    const url = normalizeUrl(tab.url);
    const title = cleanTitle(tab.title, url);
    const favicon = (_a = tab.favIconUrl) != null ? _a : "";
    const now = nowIso();
    try {
      const nowMs = Date.now();
      const last = recentlyAdded.get(url) || 0;
      if (nowMs - last < 1e3) {
        const cur = await loadWebpages();
        const exist = cur.find((w) => w.url === url);
        if (exist) return exist;
      }
      recentlyAdded.set(url, nowMs);
    } catch {
    }
    const list = await loadWebpages();
    const item = {
      id: genId(url),
      title,
      url,
      favicon,
      note: "",
      category: "default",
      createdAt: now,
      updatedAt: now
    };
    const next = [item, ...list];
    await saveWebpages(next);
    return item;
  }
  async function updateWebpage(id, updates) {
    const list = await loadWebpages();
    const idx = list.findIndex((w) => w.id === id);
    if (idx === -1) throw new Error("Not found");
    const prev = list[idx];
    let nextUrl = prev.url;
    if (updates.url !== void 0) {
      nextUrl = normalizeUrl(updates.url);
    }
    const merged = {
      ...prev,
      ...updates,
      url: nextUrl,
      title: updates.title !== void 0 ? cleanTitle(updates.title, prev.url) : prev.title,
      updatedAt: nowIso()
    };
    const next = [...list];
    next[idx] = merged;
    await saveWebpages(next);
    return merged;
  }
  async function deleteWebpage(id) {
    const list = await storage.loadFromLocal();
    const victim = list.find((w) => w.id === id);
    if (!victim) return;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const updated = {
      ...victim,
      deleted: true,
      deletedAt: now,
      updatedAt: now
    };
    const next = list.map((w) => w.id === id ? updated : w);
    await saveWebpages(next);
    try {
      const gid = victim == null ? void 0 : victim.subcategoryId;
      if (gid) {
        const order = await getGroupOrder(gid);
        const pruned = order.filter((x) => x !== id);
        if (pruned.length !== order.length) await setGroupOrder(gid, pruned);
      }
    } catch {
    }
  }
  async function reorderWebpages(fromId, toId) {
    const list = await storage.loadFromLocal();
    const from = list.find((w) => w.id === fromId);
    const to = list.find((w) => w.id === toId);
    if (!to) return await loadWebpages();
    const targetGid = to.subcategoryId;
    if (!targetGid) return await loadWebpages();
    const sourceGid = from == null ? void 0 : from.subcategoryId;
    const isCrossGroupMove = sourceGid && sourceGid !== targetGid;
    if (isCrossGroupMove) {
      const updated = list.map(
        (w) => w.id === fromId ? { ...w, subcategoryId: targetGid } : w
      );
      await saveWebpages(updated);
      const sourceOrder = await getGroupOrder(sourceGid);
      const pruned = sourceOrder.filter((x) => x !== fromId);
      if (pruned.length !== sourceOrder.length) {
        await setGroupOrder(sourceGid, pruned);
      }
      const freshList = await storage.loadFromLocal();
      const currentIds = freshList.filter((w) => w.subcategoryId === targetGid && w.id !== fromId).map((w) => w.id);
      const existing = await getGroupOrder(targetGid);
      const seen = /* @__PURE__ */ new Set();
      const base = [];
      for (const id of existing) if (currentIds.includes(id) && !seen.has(id)) {
        seen.add(id);
        base.push(id);
      }
      for (const id of currentIds) if (!seen.has(id)) {
        seen.add(id);
        base.push(id);
      }
      const filtered = base.filter((x) => x !== fromId);
      const idx = filtered.indexOf(toId);
      const insertAt = idx === -1 ? filtered.length : idx;
      filtered.splice(insertAt, 0, fromId);
      await setGroupOrder(targetGid, filtered);
    } else {
      const currentIds = list.filter((w) => w.subcategoryId === targetGid).map((w) => w.id);
      const existing = await getGroupOrder(targetGid);
      const seen = /* @__PURE__ */ new Set();
      const base = [];
      for (const id of existing) if (currentIds.includes(id) && !seen.has(id)) {
        seen.add(id);
        base.push(id);
      }
      for (const id of currentIds) if (!seen.has(id)) {
        seen.add(id);
        base.push(id);
      }
      const filtered = base.filter((x) => x !== fromId);
      const idx = filtered.indexOf(toId);
      const insertAt = idx === -1 ? filtered.length : idx;
      filtered.splice(insertAt, 0, fromId);
      await setGroupOrder(targetGid, filtered);
    }
    return await loadWebpages();
  }
  async function moveWebpageToEnd(id) {
    const list = await storage.loadFromLocal();
    const it = list.find((w) => w.id === id);
    if (!it) return await loadWebpages();
    const gid = it.subcategoryId;
    if (!gid) return await loadWebpages();
    const currentIds = list.filter((w) => w.subcategoryId === gid).map((w) => w.id);
    const existing = await getGroupOrder(gid);
    const seen = /* @__PURE__ */ new Set();
    const base = [];
    for (const x of existing) if (currentIds.includes(x) && !seen.has(x)) {
      seen.add(x);
      base.push(x);
    }
    for (const x of currentIds) if (!seen.has(x)) {
      seen.add(x);
      base.push(x);
    }
    const filtered = base.filter((x) => x !== id);
    filtered.push(id);
    await setGroupOrder(gid, filtered);
    return await loadWebpages();
  }
  async function moveCardToGroup(cardId, targetCategoryId, targetGroupId, beforeId) {
    const list = await storage.loadFromLocal();
    const card = list.find((w) => w.id === cardId);
    if (!card) return await loadWebpages();
    const originalCategory = card.category;
    const originalGroupId = card.subcategoryId;
    try {
      const updated = list.map(
        (w) => w.id === cardId ? { ...w, category: targetCategoryId, subcategoryId: targetGroupId } : w
      );
      await saveWebpages(updated);
      if (originalGroupId && originalGroupId !== targetGroupId) {
        const sourceOrder = await getGroupOrder(originalGroupId);
        const pruned = sourceOrder.filter((x) => x !== cardId);
        if (pruned.length !== sourceOrder.length) {
          await setGroupOrder(originalGroupId, pruned);
        }
      }
      const targetOrder = await getGroupOrder(targetGroupId);
      const currentIds = updated.filter((w) => w.subcategoryId === targetGroupId && w.id !== cardId).map((w) => w.id);
      const seen = /* @__PURE__ */ new Set();
      const base = [];
      for (const id of targetOrder) if (currentIds.includes(id) && !seen.has(id)) {
        seen.add(id);
        base.push(id);
      }
      for (const id of currentIds) if (!seen.has(id)) {
        seen.add(id);
        base.push(id);
      }
      if (!beforeId || beforeId === "__END__") {
        base.push(cardId);
      } else {
        const idx = base.indexOf(beforeId);
        const insertAt = idx === -1 ? base.length : idx;
        base.splice(insertAt, 0, cardId);
      }
      await setGroupOrder(targetGroupId, base);
      return await loadWebpages();
    } catch (error) {
      try {
        const rollback = list.map(
          (w) => w.id === cardId ? { ...w, category: originalCategory, subcategoryId: originalGroupId } : w
        );
        await saveWebpages(rollback);
      } catch {
      }
      throw error;
    }
  }
  async function addTabToGroup(tab, targetCategoryId, targetGroupId, beforeId) {
    var _a;
    const url = normalizeUrl(tab.url);
    const title = cleanTitle(tab.title, url);
    const favicon = (_a = tab.favIconUrl) != null ? _a : "";
    const now = nowIso();
    try {
      const nowMs = Date.now();
      const last = recentlyAdded.get(url) || 0;
      if (nowMs - last < 1e3) {
        const cur = await storage.loadFromLocal();
        const exist = cur.find((w) => w.url === url);
        if (exist) return exist;
      }
      recentlyAdded.set(url, nowMs);
    } catch {
    }
    const list = await storage.loadFromLocal();
    let meta = void 0;
    try {
      const [cats, tmpls] = await Promise.all([
        storage.loadFromSync(),
        storage.loadTemplates()
      ]);
      const cat = cats.find((c) => c.id === targetCategoryId);
      const tpl = (cat == null ? void 0 : cat.defaultTemplateId) ? tmpls.find((t) => t.id === cat.defaultTemplateId) : null;
      if (tpl) {
        const { computeAutoMeta } = await __vitePreload(async () => {
          const { computeAutoMeta: computeAutoMeta2 } = await import("./newtab-CEENaU6l.js").then((n) => n.m);
          return { computeAutoMeta: computeAutoMeta2 };
        }, true ? __vite__mapDeps([0,1,2,3,4,5,6]) : void 0, import.meta.url);
        meta = computeAutoMeta(void 0, tpl.fields || [], {
          title,
          url,
          favicon
        });
        delete meta.title;
        delete meta.description;
        try {
          const fields = tpl.fields || [];
          const hasField = (k) => fields.some((f) => f.key === k);
          const want = ["siteName", "author"];
          if (want.some((k) => hasField(k))) {
            const { getCachedMeta } = await __vitePreload(async () => {
              const { getCachedMeta: getCachedMeta2 } = await import("./pageMeta-Cp1CNcZM.js");
              return { getCachedMeta: getCachedMeta2 };
            }, true ? __vite__mapDeps([7,5]) : void 0, import.meta.url);
            const cached = await getCachedMeta(url);
            if (cached) {
              meta = { ...meta || {} };
              for (const k of want) {
                const cur = meta[k];
                const val = cached[k];
                if (hasField(k) && (!cur || !cur.trim()) && val) meta[k] = val;
              }
            }
          }
        } catch {
        }
      }
    } catch {
    }
    const item = {
      id: genId(url),
      title,
      url,
      favicon,
      note: "",
      category: targetCategoryId,
      // @ts-expect-error: optional in interface during migration
      subcategoryId: targetGroupId,
      meta,
      createdAt: now,
      updatedAt: now
    };
    const next = [item, ...list];
    await saveWebpages(next);
    const currentIds = next.filter((w) => w.subcategoryId === targetGroupId).map((w) => w.id);
    const existing = await getGroupOrder(targetGroupId);
    const seen = /* @__PURE__ */ new Set();
    const base = [];
    for (const id of existing)
      if (currentIds.includes(id) && !seen.has(id)) {
        seen.add(id);
        base.push(id);
      }
    for (const id of currentIds)
      if (!seen.has(id)) {
        seen.add(id);
        base.push(id);
      }
    if (!beforeId || beforeId === "__END__") base.push(item.id);
    else {
      const idx = base.indexOf(beforeId);
      const insertAt = idx === -1 ? base.length : idx;
      base.splice(insertAt, 0, item.id);
    }
    await setGroupOrder(targetGroupId, base);
    try {
      const tid = tab == null ? void 0 : tab.id;
      if (typeof tid === "number") {
        void (async () => {
          try {
            const { waitForTabComplete, extractMetaForTab, queuePendingExtraction } = await __vitePreload(async () => {
              const { waitForTabComplete: waitForTabComplete2, extractMetaForTab: extractMetaForTab2, queuePendingExtraction: queuePendingExtraction2 } = await import("./pageMeta-Cp1CNcZM.js");
              return { waitForTabComplete: waitForTabComplete2, extractMetaForTab: extractMetaForTab2, queuePendingExtraction: queuePendingExtraction2 };
            }, true ? __vite__mapDeps([7,5]) : void 0, import.meta.url);
            try {
              await waitForTabComplete(tid);
            } catch {
            }
            const live = await extractMetaForTab(tid);
            if (!live) {
              queuePendingExtraction(tid, item.url, item.id);
            }
            try {
              const fresh = await storage.loadFromLocal();
              const cur = fresh.find((w) => w.id === item.id);
              if (cur && (!cur.note || !String(cur.note).trim())) {
                const desc = ((live == null ? void 0 : live.description) || "").trim();
                if (desc) {
                  await updateWebpage(item.id, { note: desc });
                }
              }
            } catch {
            }
            try {
              const [cats2, tmpls2] = await Promise.all([
                storage.loadFromSync(),
                storage.loadTemplates()
              ]);
              const cat2 = cats2.find((c) => c.id === targetCategoryId);
              const tpl2 = (cat2 == null ? void 0 : cat2.defaultTemplateId) ? tmpls2.find((t) => t.id === cat2.defaultTemplateId) : null;
              const fields = (tpl2 == null ? void 0 : tpl2.fields) || [];
              const hasField = (k) => fields.some((f) => f.key === k);
              if (fields.length) {
                const fresh = await storage.loadFromLocal();
                const cur = fresh.find((w) => w.id === item.id);
                const curMeta = { ...(cur == null ? void 0 : cur.meta) || {} };
                let changed = false;
                if (hasField("siteName")) {
                  const curVal = (curMeta.siteName || "").trim();
                  const val = ((live == null ? void 0 : live.siteName) || "").trim();
                  if (!curVal && val) {
                    curMeta.siteName = val;
                    changed = true;
                  }
                }
                if (hasField("author")) {
                  const curVal = (curMeta.author || "").trim();
                  const val = ((live == null ? void 0 : live.author) || "").trim();
                  if (!curVal && val) {
                    curMeta.author = val;
                    changed = true;
                  }
                }
                if (changed) {
                  await updateWebpage(item.id, { meta: curMeta });
                }
              }
            } catch {
            }
            try {
              const fresh2 = await storage.loadFromLocal();
              const cur2 = fresh2.find((w) => w.id === item.id);
              const curMeta2 = { ...(cur2 == null ? void 0 : cur2.meta) || {} };
              let changed2 = false;
              const setIfEmpty = (key, val) => {
                const v = (val != null ? val : "").toString().trim();
                if (!v) return;
                if (!(curMeta2[key] || "").toString().trim()) {
                  curMeta2[key] = v;
                  changed2 = true;
                }
              };
              setIfEmpty("bookTitle", live == null ? void 0 : live.bookTitle);
              setIfEmpty("serialStatus", live == null ? void 0 : live.serialStatus);
              setIfEmpty("genre", live == null ? void 0 : live.genre);
              setIfEmpty("wordCount", live == null ? void 0 : live.wordCount);
              setIfEmpty("latestChapter", live == null ? void 0 : live.latestChapter);
              setIfEmpty("coverImage", live == null ? void 0 : live.coverImage);
              setIfEmpty("bookUrl", live == null ? void 0 : live.bookUrl);
              setIfEmpty("lastUpdate", live == null ? void 0 : live.lastUpdate);
              if (changed2) {
                await updateWebpage(item.id, { meta: curMeta2 });
              }
            } catch {
            }
          } catch {
          }
        })();
      }
    } catch {
    }
    return item;
  }
  return {
    addWebpageFromTab,
    addTabToGroup,
    updateWebpage,
    deleteWebpage,
    loadWebpages,
    reorderWebpages,
    moveWebpageToEnd,
    moveCardToGroup
  };
}
const webpageService = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createWebpageService
}, Symbol.toStringTag, { value: "Module" }));
export {
  createWebpageService as a,
  createStorageService as c,
  storageService as s,
  webpageService as w
};
//# sourceMappingURL=webpageService-CB3FiJ-p.js.map

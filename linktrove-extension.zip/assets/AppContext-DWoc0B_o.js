import { r as reactExports, b as reactDomExports, R as React } from "./react-JydXHVGU.js";
import { setMeta } from "./db-DtOJvepX.js";
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = reactExports, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m$1 = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m$1.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
var client = {};
var m = reactDomExports;
{
  client.createRoot = m.createRoot;
  client.hydrateRoot = m.hydrateRoot;
}
const Ctx = reactExports.createContext(null);
const AppProvider = ({
  children
}) => {
  const [theme, setTheme] = reactExports.useState("dracula");
  React.useEffect(() => {
    var _a, _b, _c;
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { theme: "dracula" }, (r) => {
        let t = r == null ? void 0 : r.theme;
        if (t === "dark" || t === "light" || !t) t = "dracula";
        if (t !== "dracula" && t !== "gruvbox") t = "dracula";
        setTheme(t);
      });
    } catch {
    }
  }, []);
  React.useEffect(() => {
    var _a, _b, _c;
    const el = document.documentElement;
    el.classList.remove("theme-dracula", "theme-gruvbox", "dark");
    el.classList.add(theme === "dracula" ? "theme-dracula" : "theme-gruvbox");
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { theme });
    } catch {
    }
    try {
      setMeta("settings.theme", theme);
    } catch {
    }
  }, [theme]);
  const value = reactExports.useMemo(() => ({ theme, setTheme }), [theme]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Ctx.Provider, { value, children });
};
function useApp() {
  const v = reactExports.useContext(Ctx);
  if (!v) throw new Error("AppProvider missing");
  return v;
}
export {
  AppProvider as A,
  client as c,
  jsxRuntimeExports as j,
  useApp as u
};
//# sourceMappingURL=AppContext-DWoc0B_o.js.map

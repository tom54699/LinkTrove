const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./webpageService-CB3FiJ-p.js","./preload-helper-CQrtv1eE.js","./db-DtOJvepX.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-CQrtv1eE.js";
const CACHE_KEY = "pageMetaCache";
const TTL_MS = 7 * 24 * 60 * 60 * 1e3;
const pendingExtractions = /* @__PURE__ */ new Map();
const PENDING_TTL_MS = 30 * 60 * 1e3;
function hasChrome() {
  var _a;
  return typeof globalThis.chrome !== "undefined" && !!((_a = chrome.storage) == null ? void 0 : _a.local);
}
function normalizeUrlKey(raw) {
  try {
    const u = new URL(raw);
    const host = (u.hostname || "").toLowerCase().replace(/^www\./, "");
    let path = u.pathname || "/";
    if (path.length > 1 && path.endsWith("/")) path = path.slice(0, -1);
    return `${u.protocol}//${host}${path}`;
  } catch {
    return raw;
  }
}
function altSlashVariant(key) {
  try {
    const u = new URL(key);
    let path = u.pathname || "/";
    if (path.endsWith("/")) path = path.slice(0, -1);
    else path = path + "/";
    return `${u.protocol}//${u.hostname}${path}`;
  } catch {
    return key;
  }
}
async function getCachedMeta(url) {
  if (!hasChrome()) return void 0;
  return new Promise((resolve) => {
    chrome.storage.local.get({ [CACHE_KEY]: {} }, (res) => {
      const map = (res == null ? void 0 : res[CACHE_KEY]) || {};
      const exact = map[url];
      const norm = map[normalizeUrlKey(url)];
      const alt = map[altSlashVariant(normalizeUrlKey(url))];
      const ent = exact || norm || alt;
      if (!ent) return resolve(void 0);
      try {
        const ts = new Date(ent.collectedAt || ent.ts || 0).getTime();
        if (Number.isFinite(ts) && Date.now() - ts < TTL_MS)
          return resolve(ent);
      } catch {
      }
      resolve(void 0);
    });
  });
}
async function saveMetaCache(url, meta) {
  if (!hasChrome()) return;
  return new Promise((resolve) => {
    chrome.storage.local.get({ [CACHE_KEY]: {} }, (res) => {
      const map = (res == null ? void 0 : res[CACHE_KEY]) || {};
      const entry = {
        ...meta,
        url: meta.url || url,
        collectedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      map[url] = entry;
      map[normalizeUrlKey(url)] = entry;
      map[altSlashVariant(normalizeUrlKey(url))] = entry;
      chrome.storage.local.set({ [CACHE_KEY]: map }, () => resolve());
    });
  });
}
function pageExtractor() {
  var _a;
  function get(name, attr = "property") {
    var _a2, _b;
    return (_b = (_a2 = document.querySelector(
      `meta[${attr}="${name}"]`
    )) == null ? void 0 : _a2.content) == null ? void 0 : _b.trim();
  }
  function textOf(sel) {
    var _a2;
    const el = document.querySelector(sel);
    const txt = (_a2 = el == null ? void 0 : el.textContent) == null ? void 0 : _a2.trim();
    return txt || void 0;
  }
  function readJsonLdAuthor() {
    const scripts = Array.from(
      document.querySelectorAll('script[type="application/ld+json"]')
    );
    for (const s of scripts) {
      try {
        const data = JSON.parse(s.textContent || "null");
        const arr = Array.isArray(data) ? data : [data];
        for (const node of arr) {
          const a = node && (node.author || node.creator);
          if (!a) continue;
          if (typeof a === "string" && a.trim()) return a.trim();
          if (Array.isArray(a)) {
            for (const x of a) {
              const n = x && (x.name || x.fullName);
              if (n && n.trim()) return n.trim();
            }
          } else if (typeof a === "object") {
            const n = a.name || a.fullName;
            if (n && n.trim()) return n.trim();
          }
        }
      } catch {
      }
    }
    return void 0;
  }
  let title = get("og:title");
  if (!title) {
    const v = get("og:novel:book_name");
    if (v) {
      title = v;
    }
  }
  if (!title) {
    const v = get("twitter:title");
    if (v) {
      title = v;
    }
  }
  if (!title) {
    if (document.title && document.title.trim()) {
      title = document.title.trim();
    }
  }
  let description = get("description", "name");
  if (!description) {
    const v = get("og:description");
    if (v) {
      description = v;
    }
  }
  if (!description) {
    const v = get("twitter:description");
    if (v) {
      description = v;
    }
  }
  function deriveSiteNameFromTitle(t) {
    const s = (t || "").trim();
    if (!s) return void 0;
    const seps = [" - ", " – ", " — ", "｜", "|", "·", "•", "»", "：", ":"];
    for (const sep of seps) {
      if (s.includes(sep)) {
        const parts = s.split(sep).map((x) => x.trim()).filter(Boolean);
        if (parts.length >= 2) {
          const cand = parts[parts.length - 1];
          if (cand && cand.length <= 20) return cand;
          if (parts[0] && parts[0].length <= 20) return parts[0];
        }
      }
    }
    return void 0;
  }
  let siteName = get("og:site_name");
  if (!siteName) {
    const v = deriveSiteNameFromTitle(title);
    if (v) {
      siteName = v;
    }
  }
  if (!siteName) {
    siteName = location.hostname.replace(/^www\./, "");
  }
  let author = get("author", "name");
  if (!author) {
    const v = get("article:author");
    if (v) {
      author = v;
    }
  }
  if (!author) {
    const v = get("books:author");
    if (v) {
      author = v;
    }
  }
  if (!author) {
    const v = get("og:novel:author");
    if (v) {
      author = v;
    }
  }
  if (!author) {
    const v = (_a = document.querySelector('link[rel="author"]')) == null ? void 0 : _a.href;
    if (v) {
      author = v;
    }
  }
  if (!author) {
    const v = readJsonLdAuthor();
    if (v) {
      author = v;
    }
  }
  if (!author) {
    const v = textOf('[itemprop="author"]');
    if (v) {
      author = v;
    }
  }
  const finalSiteName = siteName && siteName.trim() ? siteName.trim() : void 0;
  const meta = { title, description, siteName: finalSiteName, author, url: location.href };
  const novelBookName = get("og:novel:book_name");
  const novelAuthor = get("og:novel:author");
  const novelCategory = get("og:novel:category");
  const novelStatus = get("og:novel:status");
  const novelWordCount = get("og:novel:word_count");
  const novelLatestChapter = get("og:novel:latest_chapter_name");
  const novelUpdateTime = get("og:novel:update_time");
  const coverImage = get("og:image");
  const bookUrl = get("og:url");
  function normalizeStatus(s) {
    const v = (s || "").trim().toLowerCase();
    if (!v) return void 0;
    if (["連載", "連載中", "serialize", "serializing", "ongoing"].some((k) => v.includes(k))) return "連載中";
    if (["完結", "完本", "已完結", "已完本", "completed", "finished", "完"].some((k) => v.includes(k))) return "已完結";
    if (["太監", "斷更", "停更", "棄坑", "dropped"].some((k) => v.includes(k))) return "太監";
    return void 0;
  }
  function normalizeWordCount(s) {
    const v = (s || "").trim();
    if (!v) return void 0;
    let numStr = v.replace(/[,，]/g, "");
    const wan = /([0-9]+(?:\.[0-9]+)?)\s*萬/.exec(numStr);
    if (wan) {
      const n = parseFloat(wan[1]);
      if (!isNaN(n)) return String(Math.round(n * 1e4));
    }
    const digits = numStr.match(/\d+/);
    return digits ? digits[0] : void 0;
  }
  function normalizeDate(s) {
    const v = (s || "").trim();
    if (!v) return void 0;
    const ts = Date.parse(v);
    if (!isNaN(ts)) return new Date(ts).toISOString();
    return v;
  }
  const bookTitle = novelBookName || title || void 0;
  const author2 = novelAuthor || author || void 0;
  const serialStatus = normalizeStatus(novelStatus);
  const genre = novelCategory || void 0;
  const wordCount = normalizeWordCount(novelWordCount);
  const latestChapter = novelLatestChapter || void 0;
  const lastUpdate = normalizeDate(novelUpdateTime);
  const extra = {
    bookTitle,
    author: author2,
    serialStatus,
    genre,
    wordCount,
    latestChapter,
    coverImage: coverImage || void 0,
    bookUrl: bookUrl || void 0,
    lastUpdate
  };
  return { ...meta, ...extra };
}
async function extractMetaForTab(tabId, retries = 2) {
  var _a;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      if (!hasChrome() || !((_a = chrome.scripting) == null ? void 0 : _a.executeScript)) {
        return void 0;
      }
      const tabInfo = await new Promise((resolve) => {
        chrome.tabs.get(tabId, (tab) => {
          if (chrome.runtime.lastError) {
            resolve(void 0);
          } else {
            resolve(tab);
          }
        });
      });
      if (!tabInfo) {
        continue;
      }
      if (tabInfo.discarded) {
        console.log(`[pageMeta] Tab ${tabId} is discarded/sleeping, attempting to reactivate...`);
        try {
          await new Promise((resolve) => {
            chrome.tabs.update(tabId, { active: true }, () => {
              resolve();
            });
          });
          await new Promise((resolve) => setTimeout(resolve, 500));
          console.log(`[pageMeta] Tab ${tabId} reactivated successfully`);
        } catch (e) {
          console.warn(`[pageMeta] Failed to reactivate tab ${tabId}:`, e);
        }
      }
      if (tabInfo.url && (tabInfo.url.startsWith("chrome://") || tabInfo.url.startsWith("chrome-extension://"))) {
        return void 0;
      }
      const [{ result }] = await chrome.scripting.executeScript({
        target: { tabId },
        func: pageExtractor
      });
      const meta = result || {};
      if (meta && meta.url) {
        await saveMetaCache(meta.url, meta);
      }
      return meta;
    } catch (error) {
      const errorMsg = (error == null ? void 0 : error.message) || String(error);
      console.warn(`[pageMeta] Attempt ${attempt + 1}/${retries} failed for tab ${tabId}:`, errorMsg);
      if (errorMsg.includes("Cannot access") || errorMsg.includes("Insufficient permissions") || errorMsg.includes("Extension context invalidated") || errorMsg.includes("No tab with id")) {
        console.log(`[pageMeta] Permanent error, skipping retries for tab ${tabId}`);
        break;
      }
      if (attempt < retries - 1) {
        const delayMs = Math.min(1e3 * Math.pow(2, attempt), 3e3);
        console.log(`[pageMeta] Retrying in ${delayMs}ms...`);
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      }
    }
  }
  return void 0;
}
async function waitForTabComplete(tabId, timeoutMs = 1e4) {
  return new Promise((resolve) => {
    let resolved = false;
    const safeResolve = () => {
      if (!resolved) {
        resolved = true;
        resolve();
      }
    };
    const timeoutId = setTimeout(() => {
      safeResolve();
    }, timeoutMs);
    try {
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) {
          clearTimeout(timeoutId);
          safeResolve();
          return;
        }
        if (!tab) {
          clearTimeout(timeoutId);
          safeResolve();
          return;
        }
        const status = tab.status;
        if (status === "complete" || !status) {
          clearTimeout(timeoutId);
          safeResolve();
          return;
        }
        const handler = (id, changeInfo, updatedTab) => {
          if (id !== tabId) return;
          const newStatus = changeInfo == null ? void 0 : changeInfo.status;
          if (newStatus === "complete") {
            setTimeout(() => {
              try {
                chrome.tabs.onUpdated.removeListener(handler);
              } catch {
              }
              clearTimeout(timeoutId);
              safeResolve();
            }, 1e3);
          }
        };
        chrome.tabs.onUpdated.addListener(handler);
        setTimeout(() => {
          try {
            chrome.tabs.onUpdated.removeListener(handler);
          } catch {
          }
        }, timeoutMs);
      });
    } catch (error) {
      clearTimeout(timeoutId);
      safeResolve();
    }
  });
}
function urlsRoughlyEqual(a, b) {
  try {
    return normalizeUrlKey(a) === normalizeUrlKey(b) || altSlashVariant(normalizeUrlKey(a)) === normalizeUrlKey(b) || normalizeUrlKey(a) === altSlashVariant(normalizeUrlKey(b));
  } catch {
    return a === b;
  }
}
function queuePendingExtraction(tabId, url, webpageId) {
  pendingExtractions.set(tabId, {
    tabId,
    url,
    webpageId,
    addedAt: Date.now()
  });
  console.log(`[pageMeta] Queued meta extraction for tab ${tabId} (sleeping page)`);
}
async function processPendingExtraction(tabId) {
  const pending = pendingExtractions.get(tabId);
  if (!pending) return;
  if (Date.now() - pending.addedAt > PENDING_TTL_MS) {
    pendingExtractions.delete(tabId);
    console.log(`[pageMeta] Pending extraction expired for tab ${tabId}`);
    return;
  }
  console.log(`[pageMeta] Processing pending extraction for tab ${tabId}`);
  try {
    await new Promise((resolve) => setTimeout(resolve, 1e3));
    const meta = await extractMetaForTab(tabId, 2);
    if (meta && meta.url) {
      const { updateWebpage } = await __vitePreload(async () => {
        const { updateWebpage: updateWebpage2 } = await import("./webpageService-CB3FiJ-p.js").then((n) => n.w);
        return { updateWebpage: updateWebpage2 };
      }, true ? __vite__mapDeps([0,1,2]) : void 0, import.meta.url);
      await updateWebpage(pending.webpageId, { meta });
      console.log(`[pageMeta] Successfully extracted meta for tab ${tabId} after wake-up`);
    }
    pendingExtractions.delete(tabId);
  } catch (error) {
    console.warn(`[pageMeta] Failed to process pending extraction for tab ${tabId}:`, error);
    pendingExtractions.delete(tabId);
  }
}
function initPendingExtractionListeners() {
  if (!hasChrome()) return;
  try {
    chrome.tabs.onActivated.addListener(async (activeInfo) => {
      await processPendingExtraction(activeInfo.tabId);
    });
    chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
      if (changeInfo.status === "complete" || changeInfo.discarded === false) {
        await processPendingExtraction(tabId);
      }
    });
    console.log("[pageMeta] Pending extraction listeners initialized");
  } catch (error) {
    console.warn("[pageMeta] Failed to initialize listeners:", error);
  }
  setInterval(() => {
    const now = Date.now();
    for (const [tabId, pending] of pendingExtractions.entries()) {
      if (now - pending.addedAt > PENDING_TTL_MS) {
        pendingExtractions.delete(tabId);
        console.log(`[pageMeta] Cleaned up expired pending extraction for tab ${tabId}`);
      }
    }
  }, 5 * 60 * 1e3);
}
export {
  extractMetaForTab,
  getCachedMeta,
  initPendingExtractionListeners,
  processPendingExtraction,
  queuePendingExtraction,
  saveMetaCache,
  urlsRoughlyEqual,
  waitForTabComplete
};
//# sourceMappingURL=pageMeta-Cp1CNcZM.js.map

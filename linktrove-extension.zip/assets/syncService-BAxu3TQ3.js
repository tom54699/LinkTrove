import { c as createExportImportService } from "./newtab-CEENaU6l.js";
import { c as createStorageService } from "./webpageService-CB3FiJ-p.js";
import { connect as connect$1, disconnect as disconnect$1, createOrUpdate, getFile, download } from "./googleDrive-CyCKFRry.js";
import "./AppContext-DWoc0B_o.js";
import "./react-JydXHVGU.js";
import "./db-DtOJvepX.js";
import "./preload-helper-CQrtv1eE.js";
function mergeByTimestamp(local, remote) {
  const merged = /* @__PURE__ */ new Map();
  const toTimestamp = (item) => {
    const updated = item.updatedAt;
    const created = item.createdAt;
    if (updated) {
      if (typeof updated === "string") {
        const parsed = Date.parse(updated);
        if (!isNaN(parsed)) return parsed;
      }
      if (typeof updated === "number") return updated;
    }
    if (created) {
      if (typeof created === "string") {
        const parsed = Date.parse(created);
        if (!isNaN(parsed)) return parsed;
      }
      if (typeof created === "number") return created;
    }
    return 0;
  };
  const getDeletedTime = (item) => {
    if (!item.deleted || !item.deletedAt) return 0;
    if (typeof item.deletedAt === "string") {
      const parsed = Date.parse(item.deletedAt);
      return isNaN(parsed) ? 0 : parsed;
    }
    if (typeof item.deletedAt === "number") return item.deletedAt;
    return 0;
  };
  for (const item of local) {
    merged.set(item.id, item);
  }
  for (const remoteItem of remote) {
    const localItem = merged.get(remoteItem.id);
    if (!localItem) {
      merged.set(remoteItem.id, remoteItem);
    } else {
      const localDeleted = localItem.deleted;
      const remoteDeleted = remoteItem.deleted;
      if (localDeleted && remoteDeleted) {
        const localDeletedTime = getDeletedTime(localItem);
        const remoteDeletedTime = getDeletedTime(remoteItem);
        if (remoteDeletedTime > localDeletedTime) {
          merged.set(remoteItem.id, remoteItem);
        }
      } else if (localDeleted) {
        const localDeletedTime = getDeletedTime(localItem);
        const remoteTime = toTimestamp(remoteItem);
        if (localDeletedTime > remoteTime) {
          merged.set(remoteItem.id, localItem);
        } else {
          merged.set(remoteItem.id, remoteItem);
        }
      } else if (remoteDeleted) {
        const remoteDeletedTime = getDeletedTime(remoteItem);
        const localTime = toTimestamp(localItem);
        if (remoteDeletedTime > localTime) {
          merged.set(remoteItem.id, remoteItem);
        }
      } else {
        const localTime = toTimestamp(localItem);
        const remoteTime = toTimestamp(remoteItem);
        if (remoteTime > localTime) {
          merged.set(remoteItem.id, remoteItem);
        }
      }
    }
  }
  return Array.from(merged.values()).filter((item) => !item.deleted);
}
function mergeCategories(local, remote) {
  const merged = /* @__PURE__ */ new Map();
  new Map(local.map((c) => [c.id, c]));
  new Map(remote.map((c) => [c.id, c]));
  for (const item of local) {
    merged.set(item.id, item);
  }
  for (const remoteItem of remote) {
    const localItem = merged.get(remoteItem.id);
    if (!localItem) {
      merged.set(remoteItem.id, remoteItem);
    } else {
      merged.set(remoteItem.id, remoteItem);
    }
  }
  return Array.from(merged.values());
}
function mergeTemplates(local, remote) {
  const merged = /* @__PURE__ */ new Map();
  for (const item of local) {
    merged.set(item.id, item);
  }
  for (const remoteItem of remote) {
    const localItem = merged.get(remoteItem.id);
    if (!localItem) {
      merged.set(remoteItem.id, remoteItem);
    } else {
      merged.set(remoteItem.id, remoteItem);
    }
  }
  return Array.from(merged.values());
}
function mergeOrders(localOrders, remoteOrders, localTime, remoteTime) {
  const merged = {};
  const allGroupIds = /* @__PURE__ */ new Set([
    ...Object.keys(localOrders),
    ...Object.keys(remoteOrders)
  ]);
  for (const gid of allGroupIds) {
    const localOrder = localOrders[gid];
    const remoteOrder = remoteOrders[gid];
    if (!remoteOrder) {
      merged[gid] = localOrder;
    } else if (!localOrder) {
      merged[gid] = remoteOrder;
    } else {
      if (remoteTime > localTime) {
        merged[gid] = remoteOrder;
      } else {
        merged[gid] = localOrder;
      }
    }
  }
  return merged;
}
function mergeLWW(local, remote) {
  var _a, _b;
  const localTime = local.exportedAt ? Date.parse(local.exportedAt) : 0;
  const remoteTime = remote.exportedAt ? Date.parse(remote.exportedAt) : 0;
  const webpages = mergeByTimestamp(local.webpages, remote.webpages);
  const subcategories = mergeByTimestamp(
    local.subcategories,
    remote.subcategories
  );
  const organizations = mergeByTimestamp(
    local.organizations,
    remote.organizations
  );
  const categories = mergeCategories(local.categories, remote.categories);
  const templates = mergeTemplates(local.templates, remote.templates);
  const orders = {
    subcategories: mergeOrders(
      ((_a = local.orders) == null ? void 0 : _a.subcategories) || {},
      ((_b = remote.orders) == null ? void 0 : _b.subcategories) || {},
      localTime,
      remoteTime
    )
  };
  const settings = remoteTime > localTime ? remote.settings : local.settings || remote.settings;
  return {
    webpages,
    categories,
    templates,
    subcategories,
    organizations,
    orders,
    settings,
    stats: {
      webpagesLocal: local.webpages.length,
      webpagesRemote: remote.webpages.length,
      webpagesMerged: webpages.length,
      categoriesLocal: local.categories.length,
      categoriesRemote: remote.categories.length,
      categoriesMerged: categories.length,
      templatesLocal: local.templates.length,
      templatesRemote: remote.templates.length,
      templatesMerged: templates.length
    }
  };
}
const AUTO_PUSH_DEBOUNCE_MS = 2e3;
let status = {
  connected: false,
  syncing: false,
  auto: false,
  pendingPush: false
};
let autoEnabled = false;
let pendingPush = false;
let pushTimer = null;
let pushing = false;
let restoring = false;
let storageListenerAttached = false;
function setLocalStatus(patch) {
  var _a, _b, _c;
  status = { ...status, ...patch };
  status.auto = autoEnabled;
  status.pendingPush = pendingPush;
  try {
    (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { "cloudSync.status": { ...status } });
  } catch {
  }
}
function getStatus() {
  return status;
}
function ensureStorageListener() {
  if (storageListenerAttached) return;
  try {
    const handleIdbChange = (e) => {
      var _a;
      if (!autoEnabled || !status.connected) return;
      if (restoring) return;
      const stores = ((_a = e.detail) == null ? void 0 : _a.stores) || [];
      const dataChanged = stores.some((s) => ["webpages", "categories", "templates", "subcategories", "organizations"].includes(s));
      if (dataChanged) scheduleAutoBackup();
    };
    window.addEventListener("idb:changed", handleIdbChange);
    storageListenerAttached = true;
  } catch {
    storageListenerAttached = true;
  }
}
async function bootstrapStatus() {
  try {
    const got = await new Promise((resolve) => {
      var _a, _b, _c;
      try {
        (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { "cloudSync.status": { ...status } }, resolve);
      } catch {
        resolve({});
      }
    });
    const stored = got == null ? void 0 : got["cloudSync.status"];
    if (stored && typeof stored === "object") {
      status = { ...status, ...stored };
      autoEnabled = !!stored.auto;
      pendingPush = !!stored.pendingPush;
      status.auto = autoEnabled;
      status.pendingPush = pendingPush;
      status.syncing = false;
      if (stored.connected) {
        try {
          await connect$1(false);
          status.connected = true;
        } catch {
          status.connected = false;
        }
      }
    }
  } catch {
  }
  ensureStorageListener();
  setLocalStatus({});
  if (autoEnabled && status.connected) {
    void ensureRemoteFreshness();
  }
}
void bootstrapStatus();
function scheduleAutoBackup() {
  if (!autoEnabled || !status.connected) return;
  pendingPush = true;
  setLocalStatus({});
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => {
    pushTimer = null;
    void runAutoBackup();
  }, AUTO_PUSH_DEBOUNCE_MS);
}
async function runAutoBackup() {
  if (!autoEnabled || !status.connected) return;
  if (pushing) {
    pendingPush = true;
    setLocalStatus({});
    return;
  }
  pendingPush = false;
  pushing = true;
  try {
    await backupNow();
  } catch {
    pendingPush = true;
    setLocalStatus({});
  } finally {
    pushing = false;
  }
}
function remoteIsNewer(info) {
  const remoteTime = info.modifiedTime ? Date.parse(info.modifiedTime) : NaN;
  const lastDownload = status.lastDownloadedAt ? Date.parse(status.lastDownloadedAt) : NaN;
  const lastUpload = status.lastUploadedAt ? Date.parse(status.lastUploadedAt) : NaN;
  const newestLocal = Math.max(isFinite(lastDownload) ? lastDownload : 0, isFinite(lastUpload) ? lastUpload : 0);
  const checksumChanged = info.md5Checksum && info.md5Checksum !== status.lastChecksum;
  return isFinite(remoteTime) && remoteTime > newestLocal || checksumChanged;
}
async function ensureRemoteFreshness() {
  if (!autoEnabled || !status.connected) return;
  try {
    const info = await getFile();
    if (!info) return;
    if (!remoteIsNewer(info)) return;
    await restoreNow(info, true);
  } catch (error) {
    const message = (error == null ? void 0 : error.message) || String(error);
    setLocalStatus({ error: message });
  }
}
function isAutoSyncEnabled() {
  return autoEnabled;
}
async function setAutoSync(enabled) {
  autoEnabled = enabled;
  if (!enabled) {
    pendingPush = false;
    if (pushTimer) {
      clearTimeout(pushTimer);
      pushTimer = null;
    }
    setLocalStatus({});
    return;
  }
  ensureStorageListener();
  setLocalStatus({});
  if (status.connected) {
    await ensureRemoteFreshness();
  }
}
async function connect() {
  await connect$1();
  setLocalStatus({ connected: true, error: void 0 });
  ensureStorageListener();
  if (!autoEnabled) {
    autoEnabled = true;
    setLocalStatus({});
  }
}
async function disconnect() {
  await disconnect$1();
  if (pushTimer) {
    clearTimeout(pushTimer);
    pushTimer = null;
  }
  pendingPush = false;
  setLocalStatus({ connected: false, syncing: false });
}
async function backupNow() {
  var _a;
  const storage = createStorageService();
  const ei = createExportImportService({ storage });
  setLocalStatus({ syncing: true, error: void 0 });
  try {
    const json = await ei.exportJson();
    const info = await createOrUpdate(json);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    pendingPush = false;
    setLocalStatus({
      syncing: false,
      lastSyncedAt: now,
      lastUploadedAt: now,
      lastChecksum: (_a = info == null ? void 0 : info.md5Checksum) != null ? _a : status.lastChecksum
    });
  } catch (e) {
    setLocalStatus({ syncing: false, error: String((e == null ? void 0 : e.message) || e) });
    throw e;
  }
}
async function restoreNow(info, merge = false) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s;
  const storage = createStorageService();
  setLocalStatus({ syncing: true, error: void 0 });
  restoring = true;
  try {
    const fileInfo = info != null ? info : await getFile();
    if (!fileInfo) throw new Error("雲端尚無備份");
    const remoteText = await download(fileInfo.fileId);
    if (merge) {
      const [localText, remoteData] = await Promise.all([
        storage.exportData(),
        Promise.resolve(remoteText)
      ]);
      const local = JSON.parse(localText);
      const remote = JSON.parse(remoteData);
      const merged = mergeLWW(local, remote);
      const mergedPayload = {
        schemaVersion: 1,
        webpages: merged.webpages,
        categories: merged.categories,
        templates: merged.templates,
        subcategories: merged.subcategories,
        organizations: merged.organizations,
        settings: merged.settings,
        orders: merged.orders,
        exportedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      await storage.importData(JSON.stringify(mergedPayload));
    } else {
      await storage.importData(remoteText);
    }
    try {
      const [pages, cats, tmpls, orgs] = await Promise.all([
        storage.loadFromLocal().catch(() => []),
        storage.loadFromSync().catch(() => []),
        (_c = (_a = storage.loadTemplates) == null ? void 0 : (_b = _a.call(storage)).catch) == null ? void 0 : _c.call(_b, () => []),
        (_f = (_d = storage.listOrganizations) == null ? void 0 : (_e = _d.call(storage)).catch) == null ? void 0 : _f.call(_e, () => [])
      ]);
      try {
        (_i = (_h = (_g = chrome.storage) == null ? void 0 : _g.local) == null ? void 0 : _h.set) == null ? void 0 : _i.call(_h, { webpages: pages });
      } catch {
      }
      try {
        (_l = (_k = (_j = chrome.storage) == null ? void 0 : _j.local) == null ? void 0 : _k.set) == null ? void 0 : _l.call(_k, { categories: cats });
      } catch {
      }
      if (Array.isArray(tmpls)) {
        try {
          (_o = (_n = (_m = chrome.storage) == null ? void 0 : _m.local) == null ? void 0 : _n.set) == null ? void 0 : _o.call(_n, { templates: tmpls });
        } catch {
        }
      }
      if (Array.isArray(orgs)) {
        try {
          (_r = (_q = (_p = chrome.storage) == null ? void 0 : _p.local) == null ? void 0 : _q.set) == null ? void 0 : _r.call(_q, { organizations: orgs });
        } catch {
        }
      }
      try {
        window.dispatchEvent(new CustomEvent("cloudsync:restored", {
          detail: {
            pagesCount: Array.isArray(pages) ? pages.length : void 0,
            categoriesCount: Array.isArray(cats) ? cats.length : void 0,
            templatesCount: Array.isArray(tmpls) ? tmpls.length : void 0,
            organizationsCount: Array.isArray(orgs) ? orgs.length : void 0
          }
        }));
      } catch {
      }
      try {
        window.dispatchEvent(new CustomEvent("groups:changed"));
      } catch {
      }
    } catch {
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    pendingPush = false;
    setLocalStatus({
      syncing: false,
      lastSyncedAt: now,
      lastDownloadedAt: now,
      lastChecksum: (_s = fileInfo.md5Checksum) != null ? _s : status.lastChecksum,
      error: void 0
    });
  } catch (e) {
    setLocalStatus({ syncing: false, error: String((e == null ? void 0 : e.message) || e) });
    throw e;
  } finally {
    restoring = false;
  }
}
async function syncNow() {
  await backupNow();
}
export {
  backupNow,
  connect,
  disconnect,
  getStatus,
  isAutoSyncEnabled,
  restoreNow,
  setAutoSync,
  syncNow
};
//# sourceMappingURL=syncService-BAxu3TQ3.js.map

import { _ as __vitePreload } from "./preload-helper-CQrtv1eE.js";
import { putAll, setMeta, getAll, tx } from "./db-DtOJvepX.js";
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function genId() {
  return "w_" + Math.random().toString(36).slice(2, 10);
}
function parseNetscapeAnchors(html) {
  const out = [];
  const src = html || "";
  const re = /<a\s+[^>]*href\s*=\s*"([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while (m = re.exec(src)) {
    const href = (m[1] || "").trim();
    const inner = (m[2] || "").replace(/<[^>]+>/g, "").trim();
    let desc;
    const after = src.slice(m.index + m[0].length);
    const ddMatch = /<dd>([\s\S]*?)(?=<dt|<\/dl|<a\s)/i.exec(after);
    if (ddMatch) {
      desc = (ddMatch[1] || "").replace(/<[^>]+>/g, "").trim();
      if (!desc) desc = void 0;
    }
    out.push({ url: href, title: inner, desc });
  }
  return out;
}
function parseNetscapeGroups(html) {
  const groups = /* @__PURE__ */ new Map();
  try {
    const doc = new DOMParser().parseFromString(html || "", "text/html");
    const norm = (s) => (s || "").trim();
    const walker = doc.createTreeWalker(doc.body || doc, NodeFilter.SHOW_ELEMENT);
    let currentGroup = "Imported";
    let lastAnchor = null;
    let node = walker.currentNode;
    while (node = walker.nextNode()) {
      const tag = (node.tagName || "").toLowerCase();
      if (tag === "h3") {
        const name = norm(node.textContent || "") || "Imported";
        currentGroup = name;
        lastAnchor = null;
        continue;
      }
      if (tag === "a") {
        const href = norm(node.getAttribute("href") || "");
        if (!href) continue;
        const title = norm((node.textContent || "").replace(/<[^>]+>/g, ""));
        if (!groups.has(currentGroup)) groups.set(currentGroup, []);
        groups.get(currentGroup).push({ url: href, title });
        lastAnchor = { url: href, title };
        continue;
      }
      if (tag === "dd" && lastAnchor) {
        const desc = norm(node.textContent || "");
        if (desc) {
          const arr = groups.get(currentGroup);
          const last = arr[arr.length - 1];
          if (last && last.url === lastAnchor.url && !last.desc) last.desc = desc;
        }
        continue;
      }
    }
  } catch {
  }
  if (groups.size === 0) {
    const arr = parseNetscapeAnchors(html);
    groups.set("Imported", arr);
  }
  return groups;
}
function cleanTitle(t, fallbackUrl) {
  const s = (t || "").trim();
  if (s) return s;
  try {
    const u = new URL(fallbackUrl);
    return u.hostname;
  } catch {
    return "Untitled";
  }
}
function guessFavicon(u) {
  try {
    const url = new URL(u);
    const host = url.hostname;
    return `https://icons.duckduckgo.com/ip3/${host}.ico`;
  } catch {
    return "";
  }
}
async function importNetscapeHtmlIntoGroup(groupId, categoryId, html) {
  const anchors = parseNetscapeAnchors(html);
  if (!anchors.length) return { pagesCreated: 0 };
  const now = nowIso();
  const pages = [];
  const idsInOrder = [];
  for (const a of anchors) {
    let url;
    try {
      url = new URL(a.url).toString();
    } catch {
      continue;
    }
    const id = genId();
    pages.push({
      id,
      title: cleanTitle(a.title, url),
      url,
      favicon: guessFavicon(url),
      note: a.desc || "",
      category: categoryId,
      subcategoryId: groupId,
      meta: void 0,
      createdAt: now,
      updatedAt: now
    });
    idsInOrder.push(id);
  }
  if (pages.length) await putAll("webpages", pages);
  try {
    const key = `order.subcat.${groupId}`;
    let base = [];
    try {
      const meta = await (await __vitePreload(async () => {
        const { getMeta } = await import("./db-DtOJvepX.js");
        return { getMeta };
      }, true ? [] : void 0, import.meta.url)).getMeta(key);
      base = Array.isArray(meta) ? meta : [];
    } catch {
    }
    await setMeta(key, [...base, ...idsInOrder]);
  } catch {
  }
  return { pagesCreated: pages.length };
}
async function importNetscapeHtmlIntoCategory(categoryId, html, opts) {
  var _a, _b;
  const groups = parseNetscapeGroups(html);
  let total = 0;
  groups.forEach((arr) => total += (arr == null ? void 0 : arr.length) || 0);
  const onProg = opts == null ? void 0 : opts.onProgress;
  let processed = 0;
  const existing = await getAll("subcategories").catch(() => []);
  const byCat = existing.filter((x) => x.categoryId === categoryId);
  const lowerToGroup = new Map(byCat.map((g) => [String(g.name || "").toLowerCase(), g]));
  const allPages = await getAll("webpages").catch(() => []);
  const knownUrls = new Set(
    (allPages || []).filter((p) => p.category === categoryId).map((p) => String(p.url || ""))
  );
  const toCreate = [];
  const ensureGroup = (name) => {
    const key = String(name || "Imported").toLowerCase();
    const got = lowerToGroup.get(key);
    if (got) return got;
    const now = Date.now();
    const sc = {
      id: "g_" + Math.random().toString(36).slice(2, 9),
      categoryId,
      name,
      order: byCat.length + toCreate.length,
      createdAt: now,
      updatedAt: now
    };
    lowerToGroup.set(key, sc);
    toCreate.push(sc);
    return sc;
  };
  if (toCreate.length) ;
  let pagesCreated = 0;
  for (const [name, items] of groups.entries()) {
    if (!items || items.length === 0) continue;
    const g = ensureGroup(name);
    if (toCreate.length) {
      await tx(["subcategories"], "readwrite", async (t) => {
        const s = t.objectStore("subcategories");
        for (const sc of toCreate) s.put(sc);
      });
      toCreate.length = 0;
    }
    const now = nowIso();
    const pages = [];
    const idsInOrder = [];
    for (const a of items) {
      let url;
      try {
        url = new URL(a.url).toString();
      } catch {
        continue;
      }
      if ((opts == null ? void 0 : opts.dedupSkip) && knownUrls.has(url)) continue;
      const id = genId();
      pages.push({
        id,
        title: cleanTitle(a.title, url),
        url,
        favicon: guessFavicon(url),
        note: a.desc || "",
        category: categoryId,
        subcategoryId: g.id,
        meta: void 0,
        createdAt: now,
        updatedAt: now
      });
      knownUrls.add(url);
      idsInOrder.push(id);
    }
    if (pages.length) {
      const bs = Math.max(1, (_a = opts == null ? void 0 : opts.batchSize) != null ? _a : 300);
      for (let i = 0; i < pages.length; i += bs) {
        if ((_b = opts == null ? void 0 : opts.signal) == null ? void 0 : _b.aborted) throw new Error("Aborted");
        const chunk = pages.slice(i, i + bs);
        await putAll("webpages", chunk);
        processed += chunk.length;
        pagesCreated += chunk.length;
        onProg == null ? void 0 : onProg({ total, processed, group: g.name });
      }
      try {
        const key = `order.subcat.${g.id}`;
        let base = [];
        try {
          const meta = await (await __vitePreload(async () => {
            const { getMeta } = await import("./db-DtOJvepX.js");
            return { getMeta };
          }, true ? [] : void 0, import.meta.url)).getMeta(key);
          base = Array.isArray(meta) ? meta : [];
        } catch {
        }
        await setMeta(key, [...base, ...idsInOrder]);
      } catch {
      }
    }
  }
  return { pagesCreated, groupsCreated: lowerToGroup.size - byCat.length };
}
async function importNetscapeHtmlAsNewCategory(html, opts) {
  var _a, _b;
  const groups = parseNetscapeGroups(html);
  let total = 0;
  groups.forEach((arr) => total += (arr == null ? void 0 : arr.length) || 0);
  const onProg = opts == null ? void 0 : opts.onProgress;
  let processed = 0;
  const firstGroup = Array.from(groups.keys())[0] || "Imported";
  const base = ((opts == null ? void 0 : opts.name) || firstGroup || "Imported").trim() || "Imported";
  const color = (opts == null ? void 0 : opts.color) || "#64748b";
  const cats = await getAll("categories");
  const lower = new Set(cats.map((c) => String(c.name || "").toLowerCase()));
  let name = base;
  let i = 2;
  while (lower.has(name.toLowerCase())) name = `${base} ${i++}`;
  const id = "c_" + Math.random().toString(36).slice(2, 9);
  const order = cats.length;
  await tx("categories", "readwrite", async (t) => {
    t.objectStore("categories").put({ id, name, color, order, organizationId: opts == null ? void 0 : opts.organizationId });
  });
  if ((opts == null ? void 0 : opts.mode) === "flat") {
    const flatName = (opts.flatGroupName || "Imported").trim() || "Imported";
    const now = Date.now();
    const g = { id: "g_" + Math.random().toString(36).slice(2, 9), categoryId: id, name: flatName, order: 0, createdAt: now, updatedAt: now };
    await tx(["subcategories"], "readwrite", async (t) => {
      t.objectStore("subcategories").put(g);
    });
    const seq = [];
    for (const arr of groups.values()) for (const it of arr) seq.push(it);
    const known = /* @__PURE__ */ new Set();
    const ids = [];
    const pages = [];
    for (const a of seq) {
      let url;
      try {
        url = new URL(a.url).toString();
      } catch {
        continue;
      }
      if ((opts == null ? void 0 : opts.dedupSkip) && known.has(url)) continue;
      const idw = genId();
      pages.push({ id: idw, title: cleanTitle(a.title, url), url, favicon: guessFavicon(url), note: a.desc || "", category: id, subcategoryId: g.id, meta: void 0, createdAt: nowIso(), updatedAt: nowIso() });
      ids.push(idw);
      known.add(url);
    }
    if (pages.length) {
      const bs = Math.max(1, (_a = opts == null ? void 0 : opts.batchSize) != null ? _a : 300);
      for (let i2 = 0; i2 < pages.length; i2 += bs) {
        if ((_b = opts == null ? void 0 : opts.signal) == null ? void 0 : _b.aborted) throw new Error("Aborted");
        const chunk = pages.slice(i2, i2 + bs);
        await putAll("webpages", chunk);
        processed += chunk.length;
        onProg == null ? void 0 : onProg({ total, processed, group: g.name });
      }
    }
    try {
      await setMeta(`order.subcat.${g.id}`, ids);
    } catch {
    }
    return { categoryId: id, categoryName: name, pagesCreated: pages.length, groupsCreated: 1 };
  } else {
    const res = await importNetscapeHtmlIntoCategory(id, html, { dedupSkip: opts == null ? void 0 : opts.dedupSkip, batchSize: opts == null ? void 0 : opts.batchSize, signal: opts == null ? void 0 : opts.signal, onProgress: opts == null ? void 0 : opts.onProgress });
    return { categoryId: id, categoryName: name, pagesCreated: res.pagesCreated, groupsCreated: res.groupsCreated };
  }
}
export {
  importNetscapeHtmlAsNewCategory,
  importNetscapeHtmlIntoCategory,
  importNetscapeHtmlIntoGroup,
  parseNetscapeAnchors,
  parseNetscapeGroups
};
//# sourceMappingURL=html-CSsQBkNy.js.map

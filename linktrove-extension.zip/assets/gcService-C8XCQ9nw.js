import { c as createStorageService } from "./webpageService-CB3FiJ-p.js";
import "./preload-helper-CQrtv1eE.js";
import "./db-DtOJvepX.js";
const GC_STORAGE_KEY = "cloudSync.lastGCTime";
const AUTO_GC_INTERVAL_DAYS = 7;
async function getGCStats() {
  createStorageService();
  const db = await openDB();
  const tx = db.transaction(["webpages", "categories", "subcategories", "templates", "organizations"], "readonly");
  const webpagesReq = tx.objectStore("webpages").getAll();
  const categoriesReq = tx.objectStore("categories").getAll();
  const subcategoriesReq = tx.objectStore("subcategories").getAll();
  const templatesReq = tx.objectStore("templates").getAll();
  const organizationsReq = tx.objectStore("organizations").getAll();
  await tx.done;
  const webpagesRaw = await webpagesReq;
  const categoriesRaw = await categoriesReq;
  const subcategoriesRaw = await subcategoriesReq;
  const templatesRaw = await templatesReq;
  const organizationsRaw = await organizationsReq;
  const webpages = Array.isArray(webpagesRaw) ? webpagesRaw : [];
  const categories = Array.isArray(categoriesRaw) ? categoriesRaw : [];
  const subcategories = Array.isArray(subcategoriesRaw) ? subcategoriesRaw : [];
  const templates = Array.isArray(templatesRaw) ? templatesRaw : [];
  const organizations = Array.isArray(organizationsRaw) ? organizationsRaw : [];
  const deletedWebpages = webpages.filter((w) => w.deleted);
  const deletedCategories = categories.filter((c) => c.deleted);
  const deletedSubcategories = subcategories.filter((s) => s.deleted);
  const deletedTemplates = templates.filter((t) => t.deleted);
  const deletedOrganizations = organizations.filter((o) => o.deleted);
  let oldestTime = Infinity;
  const allDeleted = [
    ...deletedWebpages.map((w) => w.deletedAt),
    ...deletedCategories.map((c) => c.deletedAt),
    ...deletedSubcategories.map((s) => s.deletedAt),
    ...deletedTemplates.map((t) => t.deletedAt),
    ...deletedOrganizations.map((o) => o.deletedAt)
  ];
  for (const deletedAt of allDeleted) {
    if (!deletedAt) continue;
    const time = typeof deletedAt === "string" ? Date.parse(deletedAt) : deletedAt;
    if (!isNaN(time) && time < oldestTime) {
      oldestTime = time;
    }
  }
  const totalTombstones = deletedWebpages.length + deletedCategories.length + deletedSubcategories.length + deletedTemplates.length + deletedOrganizations.length;
  return {
    totalTombstones,
    oldestTombstone: oldestTime < Infinity ? new Date(oldestTime).toISOString() : void 0,
    categories: {
      webpages: deletedWebpages.length,
      categories: deletedCategories.length,
      subcategories: deletedSubcategories.length,
      templates: deletedTemplates.length,
      organizations: deletedOrganizations.length
    }
  };
}
async function runGC(retentionDays = 30) {
  const cutoffTime = Date.now() - retentionDays * 24 * 60 * 60 * 1e3;
  const db = await openDB();
  const tx = db.transaction(["webpages", "categories", "subcategories", "templates", "organizations"], "readwrite");
  const stores = {
    webpages: tx.objectStore("webpages"),
    categories: tx.objectStore("categories"),
    subcategories: tx.objectStore("subcategories"),
    templates: tx.objectStore("templates"),
    organizations: tx.objectStore("organizations")
  };
  const result = {
    cleaned: 0,
    categories: {
      webpages: 0,
      categories: 0,
      subcategories: 0,
      templates: 0,
      organizations: 0
    }
  };
  const shouldClean = (item) => {
    if (!item.deleted || !item.deletedAt) return false;
    const deletedTime = typeof item.deletedAt === "string" ? Date.parse(item.deletedAt) : item.deletedAt;
    if (isNaN(deletedTime)) return false;
    return deletedTime < cutoffTime;
  };
  for (const [storeName, store] of Object.entries(stores)) {
    const allReq = store.getAll();
    const allRaw = await allReq;
    const all = Array.isArray(allRaw) ? allRaw : [];
    const toDelete = all.filter(shouldClean);
    for (const item of toDelete) {
      await store.delete(item.id);
    }
    result.categories[storeName] = toDelete.length;
    result.cleaned += toDelete.length;
  }
  await tx.done;
  await recordGCTime();
  return result;
}
async function shouldAutoGC() {
  try {
    const result = await new Promise((resolve) => {
      var _a, _b, _c;
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { [GC_STORAGE_KEY]: 0 }, resolve);
    });
    const lastGCTime = result[GC_STORAGE_KEY] || 0;
    const daysSinceLastGC = (Date.now() - lastGCTime) / (24 * 60 * 60 * 1e3);
    return daysSinceLastGC >= AUTO_GC_INTERVAL_DAYS;
  } catch {
    return false;
  }
}
async function recordGCTime() {
  try {
    await new Promise((resolve, reject) => {
      var _a, _b, _c;
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { [GC_STORAGE_KEY]: Date.now() }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
  } catch (e) {
    console.warn("Failed to record GC time:", e);
  }
}
async function getLastGCTime() {
  try {
    const result = await new Promise((resolve) => {
      var _a, _b, _c;
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { [GC_STORAGE_KEY]: 0 }, resolve);
    });
    const time = result[GC_STORAGE_KEY];
    return time > 0 ? time : void 0;
  } catch {
    return void 0;
  }
}
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("linktrove", 3);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
export {
  getGCStats,
  getLastGCTime,
  runGC,
  shouldAutoGC
};
//# sourceMappingURL=gcService-C8XCQ9nw.js.map

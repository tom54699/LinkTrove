import { c as createStorageService } from "./webpageService-CB3FiJ-p.js";
import "./preload-helper-CQrtv1eE.js";
import "./db-DtOJvepX.js";
const STORAGE_KEY = "cloudSync.snapshots";
const MAX_SNAPSHOTS = 3;
async function listSnapshots() {
  try {
    const result = await new Promise((resolve) => {
      var _a, _b, _c;
      try {
        (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { [STORAGE_KEY]: [] }, resolve);
      } catch {
        resolve({});
      }
    });
    return result[STORAGE_KEY] || [];
  } catch {
    return [];
  }
}
async function createSnapshot(reason) {
  const storage = createStorageService();
  const exportData = await storage.exportData();
  const payload = JSON.parse(exportData);
  const snapshot = {
    id: `snapshot-${Date.now()}`,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    reason,
    data: payload,
    summary: {
      webpages: Array.isArray(payload.webpages) ? payload.webpages.length : 0,
      categories: Array.isArray(payload.categories) ? payload.categories.length : 0,
      templates: Array.isArray(payload.templates) ? payload.templates.length : 0,
      subcategories: Array.isArray(payload.subcategories) ? payload.subcategories.length : 0,
      organizations: Array.isArray(payload.organizations) ? payload.organizations.length : 0
    }
  };
  const snapshots = await listSnapshots();
  snapshots.unshift(snapshot);
  const trimmed = snapshots.slice(0, MAX_SNAPSHOTS);
  await new Promise((resolve, reject) => {
    var _a, _b, _c;
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { [STORAGE_KEY]: trimmed }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    } catch (e) {
      reject(e);
    }
  });
  return snapshot;
}
async function restoreSnapshot(snapshotId) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r;
  const snapshots = await listSnapshots();
  const snapshot = snapshots.find((s) => s.id === snapshotId);
  if (!snapshot) {
    throw new Error("快照不存在");
  }
  const storage = createStorageService();
  const jsonData = JSON.stringify(snapshot.data);
  await storage.importData(jsonData);
  try {
    const [pages, cats, tmpls, orgs] = await Promise.all([
      storage.loadFromLocal().catch(() => []),
      storage.loadFromSync().catch(() => []),
      (_c = (_a = storage.loadTemplates) == null ? void 0 : (_b = _a.call(storage)).catch) == null ? void 0 : _c.call(_b, () => []),
      (_f = (_d = storage.listOrganizations) == null ? void 0 : (_e = _d.call(storage)).catch) == null ? void 0 : _f.call(_e, () => [])
    ]);
    try {
      (_i = (_h = (_g = chrome.storage) == null ? void 0 : _g.local) == null ? void 0 : _h.set) == null ? void 0 : _i.call(_h, { webpages: pages });
    } catch {
    }
    try {
      (_l = (_k = (_j = chrome.storage) == null ? void 0 : _j.local) == null ? void 0 : _k.set) == null ? void 0 : _l.call(_k, { categories: cats });
    } catch {
    }
    if (Array.isArray(tmpls)) {
      try {
        (_o = (_n = (_m = chrome.storage) == null ? void 0 : _m.local) == null ? void 0 : _n.set) == null ? void 0 : _o.call(_n, { templates: tmpls });
      } catch {
      }
    }
    if (Array.isArray(orgs)) {
      try {
        (_r = (_q = (_p = chrome.storage) == null ? void 0 : _p.local) == null ? void 0 : _q.set) == null ? void 0 : _r.call(_q, { organizations: orgs });
      } catch {
      }
    }
    try {
      window.dispatchEvent(new CustomEvent("snapshot:restored", {
        detail: {
          snapshotId,
          createdAt: snapshot.createdAt
        }
      }));
    } catch {
    }
    try {
      window.dispatchEvent(new CustomEvent("groups:changed"));
    } catch {
    }
  } catch {
  }
}
async function deleteSnapshot(snapshotId) {
  const snapshots = await listSnapshots();
  const filtered = snapshots.filter((s) => s.id !== snapshotId);
  await new Promise((resolve, reject) => {
    var _a, _b, _c;
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { [STORAGE_KEY]: filtered }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    } catch (e) {
      reject(e);
    }
  });
}
async function clearAllSnapshots() {
  await new Promise((resolve, reject) => {
    var _a, _b, _c;
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { [STORAGE_KEY]: [] }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    } catch (e) {
      reject(e);
    }
  });
}
export {
  clearAllSnapshots,
  createSnapshot,
  deleteSnapshot,
  listSnapshots,
  restoreSnapshot
};
//# sourceMappingURL=snapshotService-Dbi-XpZB.js.map

import { _ as __vitePreload } from "./preload-helper-CQrtv1eE.js";
import { getAll, tx, putAll, setMeta } from "./db-DtOJvepX.js";
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function genId(prefix) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}
function normalizeTitle(card) {
  const t = (card.customTitle || card.title || "").trim();
  if (t) return t;
  try {
    return new URL(card.url || "").hostname || "Untitled";
  } catch {
    return "Untitled";
  }
}
function normalizeUrl(raw) {
  if (!raw) return null;
  try {
    const u = new URL(raw);
    if (!/^https?:$/.test(u.protocol)) return null;
    return u.toString();
  } catch {
    return null;
  }
}
function guessFavicon(u) {
  try {
    const url = new URL(u);
    const host = url.hostname;
    return `https://icons.duckduckgo.com/ip3/${host}.ico`;
  } catch {
    return "";
  }
}
async function importTobyV3IntoGroup(groupId, categoryId, json, opts) {
  var _a, _b, _c;
  let parsed;
  try {
    parsed = JSON.parse(json);
  } catch {
    throw new Error("Invalid JSON");
  }
  let cards = [];
  if (Array.isArray(parsed == null ? void 0 : parsed.lists)) {
    for (const l of parsed.lists) if (Array.isArray(l == null ? void 0 : l.cards)) cards.push(...l.cards);
  } else if (Array.isArray(parsed == null ? void 0 : parsed.cards)) {
    cards = parsed.cards;
  } else if (Array.isArray(parsed == null ? void 0 : parsed.groups)) {
    for (const g of parsed.groups) {
      const ls = g == null ? void 0 : g.lists;
      if (Array.isArray(ls)) {
        for (const l of ls) if (Array.isArray(l == null ? void 0 : l.cards)) cards.push(...l.cards);
      }
    }
  } else {
    throw new Error("Unsupported Toby format");
  }
  const subcats = await getAll("subcategories").catch(() => []);
  const target = subcats.find((s) => s.id === groupId);
  if (!target || target.categoryId !== categoryId) throw new Error("Invalid target group");
  const allPages = await getAll("webpages").catch(() => []);
  const knownUrls = new Set(
    (allPages || []).filter((p) => p.category === categoryId).map((p) => String(p.url || ""))
  );
  const webpagesToPut = [];
  const newIds = [];
  const total = cards.length;
  let processed = 0;
  for (const card of cards) {
    const url = normalizeUrl(card.url);
    if (!url) continue;
    if ((opts == null ? void 0 : opts.dedupSkip) && knownUrls.has(url)) continue;
    const id = genId("w");
    webpagesToPut.push({
      id,
      title: normalizeTitle(card),
      url,
      favicon: (card.favIconUrl || "").trim() || guessFavicon(url),
      note: (card.customDescription || "").trim(),
      category: categoryId,
      subcategoryId: groupId,
      meta: void 0,
      createdAt: nowIso(),
      updatedAt: nowIso()
    });
    newIds.push(id);
    knownUrls.add(url);
  }
  if (webpagesToPut.length) {
    const bs = Math.max(1, (_a = opts == null ? void 0 : opts.batchSize) != null ? _a : 300);
    for (let i = 0; i < webpagesToPut.length; i += bs) {
      if ((_b = opts == null ? void 0 : opts.signal) == null ? void 0 : _b.aborted) throw new Error("Aborted");
      const chunk = webpagesToPut.slice(i, i + bs);
      await putAll("webpages", chunk);
      processed += chunk.length;
      (_c = opts == null ? void 0 : opts.onProgress) == null ? void 0 : _c.call(opts, { total, processed });
    }
  }
  try {
    const key = `order.subcat.${groupId}`;
    let base = [];
    try {
      const v = await (await __vitePreload(async () => {
        const { getMeta } = await import("./db-DtOJvepX.js");
        return { getMeta };
      }, true ? [] : void 0, import.meta.url)).getMeta(key);
      base = Array.isArray(v) ? v : [];
    } catch {
    }
    await setMeta(key, [...base, ...newIds]);
  } catch {
  }
  return { pagesCreated: webpagesToPut.length };
}
async function importTobyAsNewCategory(json, opts) {
  var _a, _b, _c, _d, _e, _f;
  let parsed;
  try {
    parsed = JSON.parse(json);
  } catch {
    throw new Error("Invalid JSON");
  }
  const lists = [];
  if (Array.isArray(parsed == null ? void 0 : parsed.lists)) {
    for (const l of parsed.lists) if (l && Array.isArray(l.cards)) lists.push(l);
  }
  if (Array.isArray(parsed == null ? void 0 : parsed.groups)) {
    for (const g of parsed.groups) {
      const ls = g == null ? void 0 : g.lists;
      if (Array.isArray(ls)) {
        for (const l of ls) if (l && Array.isArray(l.cards)) lists.push(l);
      }
    }
  }
  if (lists.length === 0) return { categoryId: "", categoryName: (opts == null ? void 0 : opts.name) || "Imported", pagesCreated: 0, groupsCreated: 0 };
  const base = ((opts == null ? void 0 : opts.name) || Array.isArray(parsed == null ? void 0 : parsed.groups) && ((_a = parsed.groups[0]) == null ? void 0 : _a.name) || "Imported").trim() || "Imported";
  const color = (opts == null ? void 0 : opts.color) || "#64748b";
  const cats = await getAll("categories");
  const lower = new Set(cats.map((c) => String(c.name || "").toLowerCase()));
  let name = base;
  let i = 2;
  while (lower.has(name.toLowerCase())) name = `${base} ${i++}`;
  const catId = "c_" + Math.random().toString(36).slice(2, 9);
  const order = cats.length;
  await tx("categories", "readwrite", async (t) => {
    t.objectStore("categories").put({ id: catId, name, color, order, organizationId: opts == null ? void 0 : opts.organizationId });
  });
  let pagesCreated = 0;
  let groupsCreated = 0;
  const bs = Math.max(1, (_b = opts == null ? void 0 : opts.batchSize) != null ? _b : 300);
  const total = lists.reduce((sum, l) => sum + (l.cards || []).length, 0);
  let processed = 0;
  if ((opts == null ? void 0 : opts.mode) === "flat") {
    const flatName = (opts.flatGroupName || "Imported").trim() || "Imported";
    const now = Date.now();
    const gid = "g_" + Math.random().toString(36).slice(2, 9);
    await tx("subcategories", "readwrite", async (t) => {
      t.objectStore("subcategories").put({ id: gid, categoryId: catId, name: flatName, order: 0, createdAt: now, updatedAt: now });
    });
    groupsCreated = 1;
    const pages = [];
    const idsInOrder = [];
    for (const l of lists) {
      for (const card of l.cards || []) {
        const url = normalizeUrl(card.url || "");
        if (!url) continue;
        const id = genId(url);
        pages.push({ id, title: normalizeTitle(card), url, favicon: (card.favIconUrl || "").trim() || guessFavicon(url), note: (card.customDescription || "").trim(), category: catId, subcategoryId: gid, meta: void 0, createdAt: nowIso(), updatedAt: nowIso() });
        idsInOrder.push(id);
      }
    }
    for (let i2 = 0; i2 < pages.length; i2 += bs) {
      if ((_c = opts == null ? void 0 : opts.signal) == null ? void 0 : _c.aborted) throw new Error("Aborted");
      const chunk = pages.slice(i2, i2 + bs);
      await putAll("webpages", chunk);
      pagesCreated += chunk.length;
      processed += chunk.length;
      (_d = opts == null ? void 0 : opts.onProgress) == null ? void 0 : _d.call(opts, { total, processed, group: flatName });
    }
    try {
      await setMeta(`order.subcat.${gid}`, idsInOrder);
    } catch {
    }
  } else {
    const existingGroups = await getAll("subcategories").catch(() => []);
    const lowerToGroup = new Map(existingGroups.filter((g) => g.categoryId === catId).map((g) => [String(g.name || "").toLowerCase(), g]));
    const ensureGroup = async (groupName) => {
      const key = String(groupName).toLowerCase();
      if (lowerToGroup.has(key)) return lowerToGroup.get(key);
      const now = Date.now();
      const sc = { id: "g_" + Math.random().toString(36).slice(2, 9), categoryId: catId, name: groupName || "Imported", order: lowerToGroup.size, createdAt: now, updatedAt: now };
      await tx("subcategories", "readwrite", async (t) => {
        t.objectStore("subcategories").put(sc);
      });
      lowerToGroup.set(key, sc);
      groupsCreated++;
      return sc;
    };
    for (const l of lists) {
      const g = await ensureGroup(l.title || "group");
      const idsInOrder = [];
      const pages = [];
      for (const card of l.cards || []) {
        const url = normalizeUrl(card.url || "");
        if (!url) continue;
        const id = genId(url);
        pages.push({ id, title: normalizeTitle(card), url, favicon: (card.favIconUrl || "").trim() || guessFavicon(url), note: (card.customDescription || "").trim(), category: catId, subcategoryId: g.id, meta: void 0, createdAt: nowIso(), updatedAt: nowIso() });
        idsInOrder.push(id);
      }
      for (let i2 = 0; i2 < pages.length; i2 += bs) {
        if ((_e = opts == null ? void 0 : opts.signal) == null ? void 0 : _e.aborted) throw new Error("Aborted");
        const chunk = pages.slice(i2, i2 + bs);
        await putAll("webpages", chunk);
        pagesCreated += chunk.length;
        processed += chunk.length;
        (_f = opts == null ? void 0 : opts.onProgress) == null ? void 0 : _f.call(opts, { total, processed, group: g.name });
      }
      try {
        const key = `order.subcat.${g.id}`;
        let base2 = [];
        try {
          const meta = await (await __vitePreload(async () => {
            const { getMeta } = await import("./db-DtOJvepX.js");
            return { getMeta };
          }, true ? [] : void 0, import.meta.url)).getMeta(key);
          base2 = Array.isArray(meta) ? meta : [];
        } catch {
        }
        await setMeta(key, [...base2, ...idsInOrder]);
      } catch {
      }
    }
  }
  return { categoryId: catId, categoryName: name, pagesCreated, groupsCreated };
}
async function importTobyV4WithOrganizations(json, opts) {
  var _a;
  let parsed;
  try {
    parsed = JSON.parse(json);
  } catch {
    throw new Error("Invalid JSON");
  }
  const createOrgs = (opts == null ? void 0 : opts.createOrganizations) !== false;
  const orgs = Array.isArray(parsed == null ? void 0 : parsed.organizations) ? parsed.organizations : [];
  const rootGroups = Array.isArray(parsed == null ? void 0 : parsed.groups) ? parsed.groups : [];
  if (orgs.length === 0 && rootGroups.length === 0 && Array.isArray(parsed == null ? void 0 : parsed.lists)) {
    rootGroups.push({ name: (parsed == null ? void 0 : parsed.name) || "Imported", lists: parsed.lists });
  }
  if (orgs.length === 0 && rootGroups.length === 0) {
    throw new Error("Unsupported Toby format");
  }
  let orgsCreated = 0;
  let categoriesCreated = 0;
  let groupsCreated = 0;
  let pagesCreated = 0;
  const organizationIds = [];
  function gen(prefix) {
    return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
  }
  async function ensureOrganization(name, color) {
    if (!createOrgs) {
      const t = ((opts == null ? void 0 : opts.targetOrganizationId) || "").trim();
      if (!t) throw new Error("Target organization required when createOrganizations is false");
      return t;
    }
    const id = gen("o");
    const row = { id, name: (name || "Imported").trim() || "Imported", color: color || "#64748b", order: 0 };
    const list = await getAll("organizations").catch(() => []);
    const max = list.reduce((m, o) => {
      var _a2;
      return Math.max(m, (_a2 = o == null ? void 0 : o.order) != null ? _a2 : 0);
    }, -1);
    row.order = max + 1;
    await tx("organizations", "readwrite", async (t) => {
      t.objectStore("organizations").put(row);
    });
    orgsCreated++;
    organizationIds.push(id);
    return id;
  }
  async function importGroupAsCategory(group, orgId) {
    var _a2;
    const catId = gen("c");
    const cat = { id: catId, name: (group == null ? void 0 : group.name) || "Imported", color: "#64748b", order: 0, organizationId: orgId };
    await tx("categories", "readwrite", async (t) => t.objectStore("categories").put(cat));
    categoriesCreated++;
    const lists = Array.isArray(group == null ? void 0 : group.lists) ? group.lists : [];
    for (const l of lists) {
      const gid = gen("g");
      const now = Date.now();
      const sc = { id: gid, categoryId: catId, name: (l == null ? void 0 : l.title) || "Default Group", order: 0, createdAt: now, updatedAt: now };
      await tx("subcategories", "readwrite", async (t) => t.objectStore("subcategories").put(sc));
      groupsCreated++;
      const idsInOrder = [];
      const cards = Array.isArray(l == null ? void 0 : l.cards) ? l.cards : [];
      for (const card of cards) {
        const url = normalizeUrl(card.url || "");
        if (!url) continue;
        const id = gen("w");
        const page = {
          id,
          title: normalizeTitle(card),
          url,
          favicon: (card.favIconUrl || "").trim() || guessFavicon(url),
          note: (card.customDescription || "").trim(),
          category: catId,
          subcategoryId: gid,
          meta: void 0,
          createdAt: nowIso(),
          updatedAt: nowIso()
        };
        await tx("webpages", "readwrite", async (t) => t.objectStore("webpages").put(page));
        idsInOrder.push(id);
        pagesCreated++;
        if ((_a2 = opts == null ? void 0 : opts.signal) == null ? void 0 : _a2.aborted) throw new Error("Aborted");
      }
      try {
        await setMeta(`order.subcat.${gid}`, idsInOrder);
      } catch {
      }
    }
  }
  if (orgs.length > 0) {
    for (const o of orgs) {
      const orgId = await ensureOrganization((o == null ? void 0 : o.name) || "Imported", o == null ? void 0 : o.color);
      const groups = Array.isArray(o == null ? void 0 : o.groups) ? o.groups : [];
      for (const g of groups) {
        const catId = gen("c");
        const cat = { id: catId, name: (g == null ? void 0 : g.name) || "Imported", color: "#64748b", order: 0, organizationId: orgId };
        await tx("categories", "readwrite", async (t) => t.objectStore("categories").put(cat));
        categoriesCreated++;
        const lists = Array.isArray(g == null ? void 0 : g.lists) ? g.lists : [];
        for (const l of lists) {
          const gid = gen("g");
          const now = Date.now();
          const sc = { id: gid, categoryId: catId, name: (l == null ? void 0 : l.title) || "Default Group", order: 0, createdAt: now, updatedAt: now };
          await tx("subcategories", "readwrite", async (t) => t.objectStore("subcategories").put(sc));
          groupsCreated++;
          const idsInOrder = [];
          const cards = Array.isArray(l == null ? void 0 : l.cards) ? l.cards : [];
          for (const card of cards) {
            const url = normalizeUrl(card.url || "");
            if (!url) continue;
            const id = gen("w");
            const page = {
              id,
              title: normalizeTitle(card),
              url,
              favicon: (card.favIconUrl || "").trim() || guessFavicon(url),
              note: (card.customDescription || "").trim(),
              category: catId,
              subcategoryId: gid,
              meta: void 0,
              createdAt: nowIso(),
              updatedAt: nowIso()
            };
            await tx("webpages", "readwrite", async (t) => t.objectStore("webpages").put(page));
            idsInOrder.push(id);
            pagesCreated++;
            if ((_a = opts == null ? void 0 : opts.signal) == null ? void 0 : _a.aborted) throw new Error("Aborted");
          }
          try {
            await setMeta(`order.subcat.${gid}`, idsInOrder);
          } catch {
          }
        }
      }
    }
  } else {
    const orgName = (opts == null ? void 0 : opts.organizationName) || "Imported";
    const orgId = await ensureOrganization(orgName);
    for (const g of rootGroups) await importGroupAsCategory(g, orgId);
  }
  return { orgsCreated, categoriesCreated, groupsCreated, pagesCreated, organizationIds };
}
export {
  importTobyAsNewCategory,
  importTobyV3IntoGroup,
  importTobyV4WithOrganizations
};
//# sourceMappingURL=toby-zdfvnhyM.js.map

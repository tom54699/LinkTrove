const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./pageMeta-Cp1CNcZM.js","./preload-helper-CQrtv1eE.js","./webpageService-CB3FiJ-p.js","./db-DtOJvepX.js","./snapshotService-Dbi-XpZB.js","./gcService-C8XCQ9nw.js","./syncService-BAxu3TQ3.js","./googleDrive-CyCKFRry.js","./AppContext-DWoc0B_o.js","./react-JydXHVGU.js","./AppContext-Dx35MhF5.css","./html-CSsQBkNy.js","./toby-zdfvnhyM.js"])))=>i.map(i=>d[i]);
import { j as jsxRuntimeExports, u as useApp, c as client, A as AppProvider } from "./AppContext-DWoc0B_o.js";
import { r as reactExports, R as React, O as Outlet, c as createHashRouter, a as RouterProvider, N as Navigate } from "./react-JydXHVGU.js";
import { _ as __vitePreload } from "./preload-helper-CQrtv1eE.js";
import { c as createStorageService, a as createWebpageService } from "./webpageService-CB3FiJ-p.js";
import { getAll, tx, setMeta, getMeta, clearStore, putAll } from "./db-DtOJvepX.js";
const FourColumnLayout = ({ organizationNav, sidebar, content, tabsPanel }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-full min-h-0", children: [
    organizationNav && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-shrink-0 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded bg-[var(--panel)] h-full min-h-0 overflow-hidden", children: organizationNav }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 grid grid-cols-1 md:grid-cols-[250px_minmax(0,1fr)_280px] gap-4 h-full min-h-0 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "aside",
        {
          "aria-label": "Collections Sidebar",
          className: "rounded p-4 bg-[var(--panel)] h-full min-h-0 overflow-visible",
          children: sidebar
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "main",
        {
          "aria-label": "Content Area",
          className: "rounded p-4 bg-[var(--panel)] h-full min-h-0 overflow-y-auto",
          children: content
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "aside",
        {
          "aria-label": "Tabs Panel",
          className: "rounded p-4 bg-[var(--panel)] h-full min-h-0 overflow-y-auto",
          children: tabsPanel
        }
      )
    ] })
  ] });
};
const Ctx$4 = reactExports.createContext(null);
const OpenTabsProvider = ({ children, initialTabs = [], expose }) => {
  const [allTabs, setTabsState] = reactExports.useState(initialTabs);
  const [activeWindowId, setActiveWindowId] = reactExports.useState(null);
  const [_windowIds, setWindowIds] = reactExports.useState([]);
  const [windowLabels, setWindowLabels] = reactExports.useState({});
  const sortByIndex = (arr) => [...arr].sort(
    (a, b) => {
      var _a, _b;
      return ((_a = a.index) != null ? _a : Number.MAX_SAFE_INTEGER) - ((_b = b.index) != null ? _b : Number.MAX_SAFE_INTEGER);
    }
  );
  const actions = reactExports.useMemo(
    () => ({
      setTabs: (t) => setTabsState(sortByIndex(t)),
      addTab: (tab) => setTabsState((prev) => {
        const exists = prev.some((p) => p.id === tab.id);
        return exists ? sortByIndex(
          prev.map((p) => p.id === tab.id ? { ...p, ...tab } : p)
        ) : sortByIndex([...prev, tab]);
      }),
      removeTab: (id) => setTabsState((prev) => prev.filter((t) => t.id !== id)),
      updateTab: (id, patch) => setTabsState(
        (prev) => sortByIndex(prev.map((t) => t.id === id ? { ...t, ...patch } : t))
      ),
      setActiveWindow: (wid) => setActiveWindowId(wid),
      setWindowLabel: (wid, name) => setWindowLabels((m) => ({ ...m, [wid]: name })),
      getWindowLabel: (wid) => windowLabels[wid]
    }),
    [windowLabels]
  );
  const tabs = reactExports.useMemo(() => {
    if (!activeWindowId) return sortByIndex(allTabs);
    const filtered = allTabs.filter((t) => t.windowId === activeWindowId);
    return sortByIndex(filtered);
  }, [allTabs, activeWindowId]);
  const value = reactExports.useMemo(
    () => ({ tabs, allTabs, activeWindowId, actions }),
    [tabs, allTabs, activeWindowId, actions]
  );
  React.useEffect(() => {
    expose == null ? void 0 : expose(value);
  }, [expose, value]);
  React.useEffect(() => {
    var _a, _b, _c;
    const st = (_b = (_a = globalThis == null ? void 0 : globalThis.chrome) == null ? void 0 : _a.storage) == null ? void 0 : _b.local;
    try {
      (_c = st == null ? void 0 : st.get) == null ? void 0 : _c.call(st, { windowLabels: {} }, (res) => {
        if (res && res.windowLabels) setWindowLabels(res.windowLabels);
      });
    } catch {
    }
  }, []);
  React.useEffect(() => {
    var _a, _b, _c;
    const st = (_b = (_a = globalThis == null ? void 0 : globalThis.chrome) == null ? void 0 : _a.storage) == null ? void 0 : _b.local;
    try {
      (_c = st == null ? void 0 : st.set) == null ? void 0 : _c.call(st, { windowLabels });
    } catch {
    }
  }, [windowLabels]);
  React.useEffect(() => {
    var _a;
    const rt = (_a = globalThis == null ? void 0 : globalThis.chrome) == null ? void 0 : _a.runtime;
    if (!(rt == null ? void 0 : rt.connect)) return;
    const port = rt.connect({ name: "openTabs" });
    const onMsg = (msg) => {
      if ((msg == null ? void 0 : msg.kind) === "init" && Array.isArray(msg.tabs)) {
        setTabsState(sortByIndex(msg.tabs));
        if (Array.isArray(msg.windowIds)) setWindowIds(msg.windowIds);
        if (typeof msg.activeWindowId === "number")
          setActiveWindowId(msg.activeWindowId);
      } else if ((msg == null ? void 0 : msg.kind) === "tab-event" && msg.evt) {
        const evt = msg.evt;
        if (evt.type === "created" && evt.payload) actions.addTab(evt.payload);
        else if (evt.type === "removed") actions.removeTab(evt.payload.tabId);
        else if (evt.type === "updated")
          actions.updateTab(evt.payload.tabId, evt.payload.changeInfo);
        else if (evt.type === "moved")
          actions.updateTab(evt.payload.tabId, {
            index: evt.payload.toIndex,
            windowId: evt.payload.windowId
          });
        else if (evt.type === "attached") {
          actions.updateTab(evt.payload.tabId, {
            index: evt.payload.newPosition,
            windowId: evt.payload.newWindowId
          });
          setWindowIds(
            (prev) => Array.from(/* @__PURE__ */ new Set([...prev || [], evt.payload.newWindowId]))
          );
        } else if (evt.type === "replaced")
          actions.removeTab(evt.payload.removedTabId);
      } else if ((msg == null ? void 0 : msg.kind) === "window-focus") {
        if (typeof msg.windowId === "number" && msg.windowId > 0)
          setActiveWindowId(msg.windowId);
      } else if ((msg == null ? void 0 : msg.kind) === "window-event" && msg.evt) {
        const e = msg.evt;
        if (e.type === "created" && typeof e.windowId === "number")
          setWindowIds((prev) => Array.from(/* @__PURE__ */ new Set([...prev, e.windowId])));
        else if (e.type === "removed" && typeof e.windowId === "number")
          setWindowIds((prev) => prev.filter((id) => id !== e.windowId));
      }
    };
    port.onMessage.addListener(onMsg);
    return () => {
      try {
        port.onMessage.removeListener(onMsg);
        port.disconnect();
      } catch {
      }
    };
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Ctx$4.Provider, { value, children });
};
function useOpenTabs() {
  const v = reactExports.useContext(Ctx$4);
  if (!v) throw new Error("OpenTabsProvider missing");
  return v;
}
const Ctx$3 = reactExports.createContext(null);
const TemplatesProvider = ({
  children
}) => {
  const svc = React.useMemo(() => createStorageService(), []);
  const [templates, setTemplates] = reactExports.useState([]);
  const loadTemplates = React.useCallback(async () => {
    var _a, _b, _c;
    try {
      const got = await new Promise((resolve) => {
        var _a2, _b2, _c2;
        try {
          (_c2 = (_b2 = (_a2 = chrome.storage) == null ? void 0 : _a2.local) == null ? void 0 : _b2.get) == null ? void 0 : _c2.call(_b2, { templates: [] }, resolve);
        } catch {
          resolve({});
        }
      });
      const localTpls = Array.isArray(got == null ? void 0 : got.templates) ? got.templates : [];
      if (localTpls.length > 0) {
        setTemplates(localTpls);
        try {
          await svc.saveTemplates(localTpls);
        } catch {
        }
      } else {
        const list = await svc.loadTemplates();
        setTemplates(list);
        try {
          (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { templates: list });
        } catch {
        }
      }
    } catch {
    }
  }, [svc]);
  React.useEffect(() => {
    void loadTemplates();
  }, [loadTemplates]);
  React.useEffect(() => {
    const onRestore = () => {
      void loadTemplates();
    };
    try {
      window.addEventListener("cloudsync:restored", onRestore);
    } catch {
    }
    return () => {
      try {
        window.removeEventListener("cloudsync:restored", onRestore);
      } catch {
      }
    };
  }, [loadTemplates]);
  const persist = async (list) => {
    var _a, _b, _c;
    setTemplates(list);
    try {
      await svc.saveTemplates(list);
    } catch {
    }
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { templates: list });
    } catch {
    }
  };
  function genId() {
    return "t_" + Math.random().toString(36).slice(2, 9);
  }
  const actions = reactExports.useMemo(
    () => ({
      async reload() {
        await loadTemplates();
      },
      async add(name) {
        const nn = (name || "").trim() || "Template";
        const exist = templates.find(
          (x) => (x.name || "").trim().toLowerCase() === nn.toLowerCase()
        );
        if (exist) return exist;
        const t = { id: genId(), name: nn, fields: [] };
        await persist([...templates, t]);
        return t;
      },
      async rename(id, name) {
        const cur = await svc.loadTemplates();
        const nn = (name || "").trim();
        if (!nn) return;
        const clash = cur.find(
          (x) => x.id !== id && (x.name || "").trim().toLowerCase() === nn.toLowerCase()
        );
        if (clash) throw new Error("Template name already exists");
        await persist(cur.map((t) => t.id === id ? { ...t, name: nn } : t));
      },
      async remove(id) {
        try {
          const cats = await svc.loadFromSync();
          const using = cats.some((c) => c.defaultTemplateId === id);
          if (using) throw new Error("Template is in use by collections");
        } catch {
        }
        const cur = await svc.loadTemplates();
        await persist(cur.filter((t) => t.id !== id));
      },
      async addField(id, field) {
        const latest = await svc.loadTemplates();
        const list = latest.map((t) => {
          if (t.id !== id) return t;
          const exists = (t.fields || []).some((f) => f.key === field.key);
          if (exists) throw new Error("Field key already exists");
          const newField = { ...field, type: field.type || "text" };
          const nextFields = t.fields && t.fields.length ? [...t.fields, newField] : [newField];
          return { ...t, fields: nextFields };
        });
        await persist(list);
      },
      async addFields(id, fields) {
        const latest = await svc.loadTemplates();
        const next = latest.map((t) => {
          if (t.id !== id) return t;
          const existingKeys = new Set((t.fields || []).map((f) => f.key));
          const seen = /* @__PURE__ */ new Set();
          const toAppend = fields.filter((f) => {
            const k = f.key;
            if (!k || existingKeys.has(k) || seen.has(k)) return false;
            seen.add(k);
            return true;
          }).map((f) => ({ ...f, type: f.type || "text" }));
          return { ...t, fields: (t.fields || []).concat(toAppend) };
        });
        await persist(next);
      },
      async updateField(id, key, patch) {
        const latest = await svc.loadTemplates();
        await persist(
          latest.map(
            (t) => t.id === id ? { ...t, fields: t.fields.map((f) => f.key === key ? { ...f, ...patch } : f) } : t
          )
        );
      },
      async updateFieldType(id, key, type) {
        const latest = await svc.loadTemplates();
        await persist(
          latest.map(
            (t) => t.id === id ? { ...t, fields: t.fields.map((f) => f.key === key ? { ...f, type } : f) } : t
          )
        );
      },
      async updateFieldOptions(id, key, options) {
        const latest = await svc.loadTemplates();
        await persist(
          latest.map(
            (t) => t.id === id ? { ...t, fields: t.fields.map((f) => f.key === key ? { ...f, options } : f) } : t
          )
        );
      },
      async updateFieldRequired(id, key, required) {
        const latest = await svc.loadTemplates();
        await persist(
          latest.map(
            (t) => t.id === id ? { ...t, fields: t.fields.map((f) => f.key === key ? { ...f, required } : f) } : t
          )
        );
      },
      async reorderField(id, fromKey, toKey) {
        const latest = await svc.loadTemplates();
        const list = latest.map((t) => {
          if (t.id !== id) return t;
          const idxFrom = t.fields.findIndex((f) => f.key === fromKey);
          const idxTo = t.fields.findIndex((f) => f.key === toKey);
          if (idxFrom === -1 || idxTo === -1) return t;
          const arr = [...t.fields];
          const [m] = arr.splice(idxFrom, 1);
          arr.splice(idxTo, 0, m);
          return { ...t, fields: arr };
        });
        await persist(list);
      },
      async removeField(id, key) {
        const latest = await svc.loadTemplates();
        await persist(
          latest.map(
            (t) => t.id === id ? { ...t, fields: t.fields.filter((f) => f.key !== key) } : t
          )
        );
      }
    }),
    [templates, loadTemplates, svc]
  );
  const value = reactExports.useMemo(
    () => ({ templates, actions }),
    [templates, actions]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Ctx$3.Provider, { value, children });
};
function useTemplates() {
  const v = reactExports.useContext(Ctx$3);
  if (!v) {
    return {
      templates: [],
      actions: {
        reload: async () => {
        },
        add: async (name) => ({ id: "t_" + Math.random().toString(36).slice(2, 9), name, fields: [] }),
        rename: async () => {
        },
        remove: async () => {
        },
        addField: async () => {
        },
        addFields: async () => {
        },
        updateField: async () => {
        },
        removeField: async () => {
        },
        updateFieldType: async () => {
        },
        updateFieldOptions: async () => {
        },
        updateFieldRequired: async () => {
        },
        reorderField: async () => {
        }
      }
    };
  }
  return v;
}
let current = null;
function setDragTab(tab) {
  current = tab;
}
function getDragTab() {
  return current;
}
let currentWebpage = null;
function setDragWebpage(card) {
  currentWebpage = card;
}
function getDragWebpage() {
  return currentWebpage;
}
function broadcastGhostActive(id) {
  try {
    const evt = new CustomEvent("lt:ghost-active", { detail: id });
    window.dispatchEvent(evt);
  } catch {
  }
}
const TabItem = ({ tab, ...rest }) => {
  const [dragging, setDragging] = React.useState(false);
  const onDragStart = (e) => {
    var _a;
    setDragging(true);
    try {
      e.dataTransfer.setData(
        "application/x-linktrove-tab",
        JSON.stringify(tab)
      );
      e.dataTransfer.effectAllowed = "move";
      setDragTab({
        id: tab.id,
        title: tab.title,
        url: tab.url,
        favIconUrl: tab.favIconUrl
      });
    } catch {
    }
    (_a = rest.onDragStart) == null ? void 0 : _a.call(rest, e);
  };
  const onDragEnd = (e) => {
    var _a;
    setDragging(false);
    setDragTab(null);
    (_a = rest.onDragEnd) == null ? void 0 : _a.call(rest, e);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `flex items-center gap-2 px-2 py-1 rounded hover:bg-slate-800 ${dragging ? "ring-2 ring-blue-500" : ""}`,
      draggable: true,
      "data-dragging": dragging || void 0,
      onDragStart,
      onDragEnd,
      ...rest,
      children: [
        tab.favIconUrl ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: tab.favIconUrl, alt: "", className: "w-4 h-4", draggable: false }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-4 h-4 bg-slate-600 rounded" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", title: tab.title || tab.url, children: tab.title || tab.url || "Untitled" })
      ]
    }
  );
};
const TabsPanel = () => {
  const { allTabs, activeWindowId, actions } = useOpenTabs();
  const [collapsed, setCollapsed] = React.useState({});
  const [editing, setEditing] = React.useState(null);
  const [editText, setEditText] = React.useState("");
  const groups = React.useMemo(() => {
    var _a;
    const byWin = /* @__PURE__ */ new Map();
    for (const t of allTabs) {
      const wid = (_a = t.windowId) != null ? _a : -1;
      if (!byWin.has(wid)) byWin.set(wid, []);
      byWin.get(wid).push(t);
    }
    const arr = Array.from(byWin.entries()).sort((a, b) => a[0] - b[0]);
    return arr.map(([id, tabs], idx) => ({
      id,
      label: actions.getWindowLabel(id) || `web${idx + 1}`,
      tabs: tabs.sort((a, b) => {
        var _a2, _b;
        return ((_a2 = a.index) != null ? _a2 : 0) - ((_b = b.index) != null ? _b : 0);
      })
    }));
  }, [allTabs, actions]);
  const toggle = (wid) => setCollapsed((m) => ({ ...m, [wid]: !m[wid] }));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm mb-3", children: "OPEN TABS" }),
    groups.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "opacity-60 text-sm", children: "No open tabs" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: groups.map((g) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border border-slate-700 rounded", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: `w-full flex items-center justify-between px-2 py-1 text-left bg-[var(--card)] ${activeWindowId === g.id ? "ring-1 ring-slate-500" : ""}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: "text-xs",
                  onClick: () => toggle(g.id),
                  "aria-label": "Toggle",
                  children: collapsed[g.id] ? "▸" : "▾"
                }
              ),
              editing === g.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  className: "text-xs rounded bg-slate-900 border border-slate-700 px-1 py-0.5",
                  value: editText,
                  autoFocus: true,
                  onChange: (e) => setEditText(e.target.value),
                  onBlur: () => {
                    actions.setWindowLabel(g.id, editText.trim() || g.label);
                    setEditing(null);
                  },
                  onKeyDown: (e) => {
                    if (e.key === "Enter") {
                      actions.setWindowLabel(
                        g.id,
                        editText.trim() || g.label
                      );
                      setEditing(null);
                    }
                    if (e.key === "Escape") {
                      setEditing(null);
                    }
                  }
                }
              ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs", children: [
                g.label,
                " ",
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "opacity-60", children: [
                  "(",
                  g.tabs.length,
                  ")"
                ] })
              ] })
            ] }),
            editing === g.id ? null : /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "text-xs opacity-80 hover:opacity-100",
                "aria-label": "Rename",
                onClick: () => {
                  setEditing(g.id);
                  setEditText(g.label);
                },
                children: "✎"
              }
            )
          ]
        }
      ),
      !collapsed[g.id] && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-1 space-y-2", children: [
        g.tabs.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          TabItem,
          {
            tab: t,
            className: "flex items-center bg-[var(--card)] px-2 py-2 rounded-md hover:bg-[#283069]",
            title: t.title || t.url
          },
          t.id
        )),
        g.tabs.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "opacity-60 text-sm px-2 pb-2", children: "No tabs" })
      ] })
    ] }, g.id)) })
  ] });
};
const OrgsCtx = reactExports.createContext(null);
const DEFAULT_ORGS = [
  { id: "o_default", name: "Personal", order: 0 }
];
const OrganizationsProvider = ({ children }) => {
  const [organizations, setOrganizations] = reactExports.useState(DEFAULT_ORGS);
  const [selectedOrgId, setSelectedOrgId] = reactExports.useState("o_default");
  React.useLayoutEffect(() => {
    (async () => {
      var _a, _b;
      try {
        const list = await getAll("organizations").catch(() => []);
        let orgs = Array.isArray(list) && list.length > 0 ? list : DEFAULT_ORGS;
        orgs = orgs.slice().sort((a, b) => {
          var _a2, _b2;
          return ((_a2 = a.order) != null ? _a2 : 0) - ((_b2 = b.order) != null ? _b2 : 0) || String(a.name).localeCompare(String(b.name));
        });
        setOrganizations(orgs);
        try {
          const got = await new Promise((resolve) => {
            var _a2, _b2, _c;
            try {
              (_c = (_b2 = (_a2 = chrome.storage) == null ? void 0 : _a2.local) == null ? void 0 : _b2.get) == null ? void 0 : _c.call(_b2, { selectedOrganizationId: "" }, resolve);
            } catch {
              resolve({});
            }
          });
          const sel = (got == null ? void 0 : got.selectedOrganizationId) || "";
          if (sel && orgs.some((o) => o.id === sel)) setSelectedOrgId(sel);
          else setSelectedOrgId(((_a = orgs[0]) == null ? void 0 : _a.id) || "o_default");
        } catch {
          setSelectedOrgId(((_b = orgs[0]) == null ? void 0 : _b.id) || "o_default");
        }
      } catch {
      }
    })();
  }, []);
  const actions = reactExports.useMemo(() => ({
    async reload() {
      var _a;
      try {
        const list = await getAll("organizations").catch(() => []);
        const orgs = Array.isArray(list) && list.length > 0 ? list : DEFAULT_ORGS;
        orgs.sort((a, b) => {
          var _a2, _b;
          return ((_a2 = a.order) != null ? _a2 : 0) - ((_b = b.order) != null ? _b : 0) || String(a.name).localeCompare(String(b.name));
        });
        setOrganizations(orgs);
        if (!orgs.some((o) => o.id === selectedOrgId)) setSelectedOrgId(((_a = orgs[0]) == null ? void 0 : _a.id) || "o_default");
      } catch {
      }
    },
    async add(name, color) {
      var _a;
      const nowList = organizations.slice();
      const order = nowList.length ? ((_a = nowList[nowList.length - 1].order) != null ? _a : nowList.length - 1) + 1 : 0;
      const next = { id: "o_" + Math.random().toString(36).slice(2, 9), name: name.trim() || "Org", color, order };
      setOrganizations([...nowList, next]);
      try {
        await tx("organizations", "readwrite", async (t) => t.objectStore("organizations").put(next));
      } catch {
      }
      return next;
    },
    async rename(id, name) {
      setOrganizations((prev) => prev.map((o) => o.id === id ? { ...o, name: name.trim() || o.name } : o));
      try {
        await tx("organizations", "readwrite", async (t) => {
          const s = t.objectStore("organizations");
          const cur = await new Promise((resolve, reject) => {
            const req = s.get(id);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
          });
          if (!cur) return;
          cur.name = name;
          s.put(cur);
        });
      } catch {
      }
    },
    async remove(id, reassignToId) {
      try {
        await tx(["categories", "organizations"], "readwrite", async (t) => {
          var _a;
          const cs = t.objectStore("categories");
          const os = t.objectStore("organizations");
          const catList = await new Promise((resolve, reject) => {
            const req = cs.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          const orgs = await new Promise((resolve, reject) => {
            const req = os.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          const target = reassignToId && orgs.find((o) => o.id === reassignToId) ? reassignToId : ((_a = orgs.find((o) => o.id !== id)) == null ? void 0 : _a.id) || "o_default";
          for (const c of catList) {
            if (c.organizationId === id) {
              c.organizationId = target;
              cs.put(c);
            }
          }
          os.delete(id);
        });
      } catch {
      }
      setOrganizations((prev) => prev.filter((o) => o.id !== id));
      if (selectedOrgId === id) setSelectedOrgId("o_default");
    },
    async reorder(orderedIds) {
      const byId = new Map(organizations.map((o) => [o.id, o]));
      const newList = [];
      let i = 0;
      for (const id of orderedIds) {
        const o = byId.get(id);
        if (!o) continue;
        newList.push({ ...o, order: i++ });
        byId.delete(id);
      }
      for (const o of byId.values()) newList.push({ ...o, order: i++ });
      setOrganizations(newList);
      try {
        await tx("organizations", "readwrite", async (t) => {
          const s = t.objectStore("organizations");
          for (const o of newList) s.put(o);
        });
      } catch {
      }
    }
  }), [organizations, selectedOrgId]);
  React.useEffect(() => {
    const onRestore = () => {
      void actions.reload();
    };
    try {
      window.addEventListener("cloudsync:restored", onRestore);
    } catch {
    }
    return () => {
      try {
        window.removeEventListener("cloudsync:restored", onRestore);
      } catch {
      }
    };
  }, [actions]);
  const setCurrentOrganization = (id) => {
    var _a, _b, _c;
    setSelectedOrgId(id);
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { selectedOrganizationId: id });
    } catch {
    }
    try {
      setMeta("settings.selectedOrganizationId", id);
    } catch {
    }
  };
  const value = reactExports.useMemo(() => ({ organizations, selectedOrgId, setCurrentOrganization, actions }), [organizations, selectedOrgId, actions]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(OrgsCtx.Provider, { value, children });
};
function useOrganizations() {
  const v = reactExports.useContext(OrgsCtx);
  if (!v) {
    return {
      organizations: DEFAULT_ORGS,
      selectedOrgId: "o_default",
      setCurrentOrganization: () => {
      },
      actions: {
        reload: async () => {
        },
        add: async (name, color) => ({ id: "o_default", name: name || "Personal", color, order: 0 }),
        rename: async () => {
        },
        remove: async () => {
        },
        reorder: async () => {
        }
      }
    };
  }
  return v;
}
const Ctx$2 = reactExports.createContext(null);
const DEFAULT_CATEGORIES = [
  { id: "default", name: "Default", color: "#64748b", order: 0 }
];
const CategoriesProvider = ({
  children
}) => {
  const [categories, setCategories] = reactExports.useState(DEFAULT_CATEGORIES);
  const [selectedId, setSelectedId] = reactExports.useState("default");
  const { selectedOrgId } = useOrganizations();
  const orgCtx = React.useContext(OrgsCtx);
  const hasOrgProvider = !!orgCtx;
  const [ready, setReady] = reactExports.useState(!hasOrgProvider);
  const [refreshTick, setRefreshTick] = reactExports.useState(0);
  const svc = React.useMemo(() => {
    return createStorageService();
  }, []);
  React.useEffect(() => {
    const onRestore = () => {
      setRefreshTick((tick) => tick + 1);
    };
    try {
      window.addEventListener("cloudsync:restored", onRestore);
    } catch {
    }
    return () => {
      try {
        window.removeEventListener("cloudsync:restored", onRestore);
      } catch {
      }
    };
  }, []);
  React.useLayoutEffect(() => {
    (async () => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      if (!svc) return;
      let list = await tx("categories", "readonly", async (t) => {
        const s = t.objectStore("categories");
        try {
          const idx = s.index("by_organizationId_order");
          const range = IDBKeyRange.bound([selectedOrgId, -Infinity], [selectedOrgId, Infinity]);
          const rows = await new Promise((resolve, reject) => {
            const req = idx.getAll(range);
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          return rows;
        } catch {
          const rows = await new Promise((resolve, reject) => {
            const req = s.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
          });
          return rows.filter((c) => c.organizationId === selectedOrgId);
        }
      });
      if (!Array.isArray(list) || list.length === 0) {
        try {
          await tx("categories", "readwrite", async (t) => {
            const s = t.objectStore("categories");
            const all = await new Promise((resolve, reject) => {
              const rq = s.getAll();
              rq.onsuccess = () => resolve(rq.result || []);
              rq.onerror = () => reject(rq.error);
            });
            let changed = false;
            for (const c of all) {
              if (!c.organizationId) {
                c.organizationId = "o_default";
                s.put(c);
                changed = true;
              }
            }
            if (changed) {
              try {
                const idx = s.index("by_organizationId_order");
                const range = IDBKeyRange.bound([selectedOrgId, -Infinity], [selectedOrgId, Infinity]);
                const rows = await new Promise((resolve, reject) => {
                  const req = idx.getAll(range);
                  req.onsuccess = () => resolve(req.result || []);
                  req.onerror = () => reject(req.error);
                });
                list = rows;
              } catch {
                list = all.filter((c) => c.organizationId === selectedOrgId);
              }
            }
          });
        } catch {
        }
      }
      if (!Array.isArray(list) || list.length === 0) {
        try {
          await tx("categories", "readwrite", async (t) => {
            const s = t.objectStore("categories");
            const all = await new Promise((resolve, reject) => {
              const rq = s.getAll();
              rq.onsuccess = () => resolve(rq.result || []);
              rq.onerror = () => reject(rq.error);
            });
            if ((all || []).length === 0) {
              s.put({ id: "default", name: "Default", color: "#64748b", order: 0, organizationId: selectedOrgId });
            }
          });
        } catch {
        }
        try {
          list = await tx("categories", "readonly", async (t) => {
            const s = t.objectStore("categories");
            try {
              const idx = s.index("by_organizationId_order");
              const range = IDBKeyRange.bound([selectedOrgId, -Infinity], [selectedOrgId, Infinity]);
              const rows = await new Promise((resolve, reject) => {
                const req = idx.getAll(range);
                req.onsuccess = () => resolve(req.result || []);
                req.onerror = () => reject(req.error);
              });
              return rows;
            } catch {
              const rows = await new Promise((resolve, reject) => {
                const req = s.getAll();
                req.onsuccess = () => resolve(req.result || []);
                req.onerror = () => reject(req.error);
              });
              return rows.filter((c) => c.organizationId === selectedOrgId);
            }
          });
        } catch {
        }
      }
      const ordered = list.slice().sort((a, b) => {
        var _a2, _b2;
        return ((_a2 = a.order) != null ? _a2 : 0) - ((_b2 = b.order) != null ? _b2 : 0) || String(a.name || "").localeCompare(String(b.name || ""));
      });
      setCategories(ordered);
      try {
        (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { categories: ordered });
      } catch {
      }
      try {
        for (const c of ordered) {
          const arr = await ((_d = svc.listSubcategories) == null ? void 0 : _d.call(svc, c.id)) || [];
          if (!Array.isArray(arr) || arr.length === 0) await ((_e = svc.createSubcategory) == null ? void 0 : _e.call(svc, c.id, "group"));
        }
        try {
          window.dispatchEvent(new CustomEvent("groups:changed"));
        } catch {
        }
      } catch {
      }
      try {
        let persisted;
        try {
          const got = await new Promise((resolve) => {
            var _a2, _b2, _c2;
            try {
              (_c2 = (_b2 = (_a2 = chrome.storage) == null ? void 0 : _a2.local) == null ? void 0 : _b2.get) == null ? void 0 : _c2.call(_b2, { selectedCategoryId: "" }, resolve);
            } catch {
              resolve({});
            }
          });
          if (got && typeof got.selectedCategoryId === "string") persisted = got.selectedCategoryId || void 0;
        } catch {
        }
        if (!persisted) {
          try {
            persisted = await getMeta("settings.selectedCategoryId") || void 0;
          } catch {
          }
        }
        const listInOrg = ordered;
        const has = (id) => !!id && listInOrg.some((c) => c.id === id);
        const want = has(persisted) ? persisted : has(selectedId) ? selectedId : ((_f = listInOrg[0]) == null ? void 0 : _f.id) || "default";
        setSelectedId(want);
        try {
          (_i = (_h = (_g = chrome.storage) == null ? void 0 : _g.local) == null ? void 0 : _h.set) == null ? void 0 : _i.call(_h, { selectedCategoryId: want });
        } catch {
        }
      } catch {
      }
      try {
        if (hasOrgProvider) setReady(true);
      } catch {
      }
    })();
  }, [svc, selectedOrgId, refreshTick]);
  const actions = React.useMemo(
    () => ({
      async reload() {
        try {
          const syncCats = await svc.loadFromSync();
          let localCats = [];
          try {
            const got = await new Promise((resolve) => {
              var _a, _b, _c;
              try {
                (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { categories: [] }, resolve);
              } catch {
                resolve({});
              }
            });
            localCats = Array.isArray(got == null ? void 0 : got.categories) ? got.categories : [];
          } catch {
          }
          const byId = /* @__PURE__ */ new Map();
          const merged = [];
          for (const c of syncCats) {
            if (!byId.has(c.id)) {
              byId.set(c.id, c);
              merged.push(c);
            }
          }
          for (const c of localCats) {
            if (!byId.has(c.id)) {
              byId.set(c.id, c);
              merged.push(c);
            }
          }
          const filtered = merged.filter((c) => c.organizationId === selectedOrgId);
          filtered.sort(
            (a, b) => {
              var _a, _b;
              return ((_a = a.order) != null ? _a : 0) - ((_b = b.order) != null ? _b : 0) || a.name.localeCompare(b.name);
            }
          );
          setCategories(filtered);
        } catch {
        }
      },
      async addCategory(name, color = "#64748b") {
        var _a, _b, _c, _d, _e, _f;
        const created = await ((_a = svc.addCategory) == null ? void 0 : _a.call(svc, name.trim() || "Untitled", color, selectedOrgId));
        const list = [...categories, { id: created.id, name: created.name, color: created.color, order: created.order, defaultTemplateId: created.defaultTemplateId }];
        list.sort((a, b) => {
          var _a2, _b2;
          return ((_a2 = a.order) != null ? _a2 : 0) - ((_b2 = b.order) != null ? _b2 : 0) || String(a.name).localeCompare(String(b.name));
        });
        setCategories(list);
        try {
          (_d = (_c = (_b = chrome.storage) == null ? void 0 : _b.local) == null ? void 0 : _c.set) == null ? void 0 : _d.call(_c, { categories: list });
        } catch {
        }
        try {
          const arr = await ((_e = svc.listSubcategories) == null ? void 0 : _e.call(svc, created.id)) || [];
          if (!Array.isArray(arr) || arr.length === 0) await ((_f = svc.createSubcategory) == null ? void 0 : _f.call(svc, created.id, "group"));
          try {
            window.dispatchEvent(new CustomEvent("groups:changed"));
          } catch {
          }
        } catch {
        }
        return created;
      },
      async renameCategory(id, name) {
        var _a, _b, _c;
        const list = categories.map((c) => c.id === id ? { ...c, name: name.trim() || c.name } : c);
        setCategories(list);
        try {
          await tx("categories", "readwrite", async (t) => {
            const s = t.objectStore("categories");
            const cur = await new Promise((resolve, reject) => {
              const req = s.get(id);
              req.onsuccess = () => resolve(req.result);
              req.onerror = () => reject(req.error);
            });
            if (!cur) return;
            cur.name = name.trim() || cur.name;
            s.put(cur);
          });
        } catch {
        }
        try {
          (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { categories: list });
        } catch {
        }
      },
      async updateColor(id, color) {
        var _a, _b, _c;
        const list = categories.map((c) => c.id === id ? { ...c, color: color || c.color } : c);
        setCategories(list);
        try {
          await tx("categories", "readwrite", async (t) => {
            const s = t.objectStore("categories");
            const cur = await new Promise((resolve, reject) => {
              const req = s.get(id);
              req.onsuccess = () => resolve(req.result);
              req.onerror = () => reject(req.error);
            });
            if (!cur) return;
            cur.color = color || cur.color;
            s.put(cur);
          });
        } catch {
        }
        try {
          (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { categories: list });
        } catch {
        }
      },
      async deleteCategory(id) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const next = categories.filter((c) => c.id !== id);
        setCategories(next);
        try {
          (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { categories: next });
        } catch {
        }
        if (selectedId === id) {
          const fallback = ((_d = next[0]) == null ? void 0 : _d.id) || "";
          setSelectedId(fallback);
          try {
            (_g = (_f = (_e = chrome.storage) == null ? void 0 : _e.local) == null ? void 0 : _f.set) == null ? void 0 : _g.call(_f, { selectedCategoryId: fallback });
          } catch {
          }
        }
        try {
          const pages = await (svc == null ? void 0 : svc.loadFromLocal());
          const filtered = (pages || []).filter(
            (p) => String(p.category || "") !== String(id)
          );
          await (svc == null ? void 0 : svc.saveToLocal(filtered));
        } catch {
        }
        try {
          await ((_h = svc == null ? void 0 : svc.deleteSubcategoriesByCategory) == null ? void 0 : _h.call(svc, id));
        } catch {
        }
        try {
          await tx("categories", "readwrite", async (t) => {
            t.objectStore("categories").delete(id);
          });
        } catch {
        }
      },
      async setDefaultTemplate(id, templateId) {
        var _a, _b, _c;
        setCategories((prev) => prev.map((c) => c.id === id ? { ...c, defaultTemplateId: templateId } : c));
        try {
          await tx("categories", "readwrite", async (t) => {
            const s = t.objectStore("categories");
            const cur = await new Promise((resolve, reject) => {
              const req = s.get(id);
              req.onsuccess = () => resolve(req.result);
              req.onerror = () => reject(req.error);
            });
            if (!cur) return;
            cur.defaultTemplateId = templateId;
            s.put(cur);
          });
        } catch {
        }
        try {
          (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { categories });
        } catch {
        }
      },
      async reorderCategories(orderIds) {
        var _a, _b, _c, _d;
        const byId = new Map(categories.map((c) => [c.id, c]));
        const newList = [];
        let i = 0;
        for (const id of orderIds) {
          const c = byId.get(id);
          if (!c) continue;
          newList.push({ ...c, order: i++ });
          byId.delete(id);
        }
        for (const c of byId.values()) newList.push({ ...c, order: i++ });
        setCategories(newList);
        try {
          await ((_a = svc.reorderCategories) == null ? void 0 : _a.call(svc, orderIds, selectedOrgId));
        } catch {
        }
        try {
          (_d = (_c = (_b = chrome.storage) == null ? void 0 : _b.local) == null ? void 0 : _c.set) == null ? void 0 : _d.call(_c, { categories: newList });
        } catch {
        }
      }
    }),
    [categories, svc, selectedId, selectedOrgId]
  );
  const setCurrentCategory = (id) => {
    var _a, _b, _c;
    setSelectedId(id);
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { selectedCategoryId: id });
    } catch {
    }
    try {
      setMeta("settings.selectedCategoryId", id);
    } catch {
    }
  };
  const value = reactExports.useMemo(() => ({ categories, selectedId, setCurrentCategory, actions }), [categories, selectedId, actions]);
  if (!ready) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Ctx$2.Provider, { value, children });
};
function useCategories() {
  const v = reactExports.useContext(Ctx$2);
  if (!v) {
    return {
      categories: DEFAULT_CATEGORIES,
      selectedId: "default",
      setCurrentCategory: () => {
      },
      actions: {
        addCategory: async () => DEFAULT_CATEGORIES[0],
        renameCategory: async () => {
        },
        updateColor: async () => {
        },
        deleteCategory: async () => {
        },
        setDefaultTemplate: async () => {
        },
        reorderCategories: async () => {
        }
      }
    };
  }
  return v;
}
function computeAutoMeta(current2, fields, page) {
  var _a;
  const meta = { ...current2 || {} };
  const f = fields || [];
  for (const field of f) {
    const cur = ((_a = meta[field.key]) != null ? _a : "").trim();
    if (!cur && field.defaultValue != null)
      meta[field.key] = String(field.defaultValue);
  }
  if (!page) return meta;
  try {
    const u = new URL(page.url);
    const title = (page.title || "").trim();
    const favicon = page.favicon || "";
    const hostname = u.hostname;
    const origin = u.origin;
    const pathname = u.pathname;
    const hasKey = (keyName) => f.some((x) => x.key === keyName);
    const maybeSet = (fieldKey, value) => {
      var _a2;
      if (!hasKey(fieldKey)) return;
      if (((_a2 = meta[fieldKey]) != null ? _a2 : "").trim()) return;
      meta[fieldKey] = value;
    };
    ["title", "name", "pageTitle"].forEach((key) => title && maybeSet(key, title));
    ["url", "link", "href"].forEach((key) => maybeSet(key, u.toString()));
    ["host", "hostname", "domain", "site"].forEach((key) => maybeSet(key, hostname));
    ["origin"].forEach((key) => maybeSet(key, origin));
    ["path", "pathname"].forEach((key) => maybeSet(key, pathname));
    ["favicon"].forEach((key) => favicon && maybeSet(key, favicon));
  } catch {
  }
  return meta;
}
const metaAutoFill = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  computeAutoMeta
}, Symbol.toStringTag, { value: "Module" }));
const Ctx$1 = React.createContext(null);
function toCard(d) {
  return {
    id: d.id,
    title: d.title,
    url: d.url,
    favicon: d.favicon,
    description: d.note,
    category: d.category,
    subcategoryId: d.subcategoryId,
    meta: d.meta,
    templateId: d.templateId,
    templateData: d.templateData
  };
}
const WebpagesProvider = ({ children, svc }) => {
  const service = React.useMemo(() => {
    if (svc) return svc;
    return createWebpageService();
  }, [svc]);
  const [items, setItems] = React.useState([]);
  const { selectedId } = useCategories();
  const selectedIdRef = React.useRef(selectedId);
  React.useEffect(() => {
    selectedIdRef.current = selectedId;
  }, [selectedId]);
  const load = React.useCallback(async () => {
    const list = await service.loadWebpages();
    setItems(list.map(toCard));
  }, [service]);
  const addFromTab = React.useCallback(
    async (tab) => {
      let created = await service.addWebpageFromTab(tab);
      let target = selectedIdRef.current;
      try {
        const got = await new Promise((resolve) => {
          var _a, _b, _c;
          try {
            (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { selectedCategoryId: "" }, resolve);
          } catch {
            resolve({});
          }
        });
        const persisted = got == null ? void 0 : got.selectedCategoryId;
        if (persisted && typeof persisted === "string") target = persisted;
      } catch {
      }
      try {
        if (target && target !== "all" && created.category !== target) {
          const updated = await service.updateWebpage(created.id, { category: target });
          created = updated;
        }
      } catch {
      }
      try {
        const newCard = toCard(created);
        setItems((prev) => [newCard, ...prev]);
      } catch {
      }
      try {
        if (typeof globalThis.chrome !== "undefined" && tab.id != null) {
          const { extractMetaForTab, waitForTabComplete } = await __vitePreload(async () => {
            const { extractMetaForTab: extractMetaForTab2, waitForTabComplete: waitForTabComplete2 } = await import("./pageMeta-Cp1CNcZM.js");
            return { extractMetaForTab: extractMetaForTab2, waitForTabComplete: waitForTabComplete2 };
          }, true ? __vite__mapDeps([0,1]) : void 0, import.meta.url);
          const tid = tab.id;
          const targetCategory = target;
          const enrichmentPromise = (async () => {
            try {
              await waitForTabComplete(tid, 15e3);
              await new Promise((resolve) => setTimeout(resolve, 2e3));
            } catch {
            }
            const meta = await extractMetaForTab(tid);
            if (!meta) {
              return;
            }
            try {
              const patch = {};
              if (meta.title && meta.title.trim())
                patch.title = meta.title.trim();
              const cur = created;
              if ((!cur.note || !cur.note.trim()) && meta.description && meta.description.trim()) {
                patch.note = meta.description.trim();
              }
              try {
                const curMeta = { ...(cur == null ? void 0 : cur.meta) || {} };
                let metaChanged = false;
                const setIfEmpty = (key, val) => {
                  const v = (val != null ? val : "").toString().trim();
                  if (!v) return;
                  const currentVal = (curMeta[key] || "").toString().trim();
                  if (!currentVal) {
                    curMeta[key] = v;
                    metaChanged = true;
                  }
                };
                setIfEmpty("siteName", meta == null ? void 0 : meta.siteName);
                setIfEmpty("author", meta == null ? void 0 : meta.author);
                setIfEmpty("bookTitle", meta == null ? void 0 : meta.bookTitle);
                setIfEmpty("serialStatus", meta == null ? void 0 : meta.serialStatus);
                setIfEmpty("genre", meta == null ? void 0 : meta.genre);
                setIfEmpty("wordCount", meta == null ? void 0 : meta.wordCount);
                setIfEmpty("latestChapter", meta == null ? void 0 : meta.latestChapter);
                setIfEmpty("coverImage", meta == null ? void 0 : meta.coverImage);
                setIfEmpty("bookUrl", meta == null ? void 0 : meta.bookUrl);
                setIfEmpty("lastUpdate", meta == null ? void 0 : meta.lastUpdate);
                if (metaChanged) {
                  patch.meta = curMeta;
                }
              } catch (error) {
              }
              if (Object.keys(patch).length > 0) {
                const updated = await service.updateWebpage(created.id, patch);
                setItems(
                  (prev) => prev.map((p) => p.id === created.id ? toCard(updated) : p)
                );
              }
            } catch {
            }
          })();
          if (service.loadFromSync && service.loadTemplates) {
            await enrichmentPromise;
          } else {
          }
        }
      } catch {
      }
      setItems((prev) => {
        if (prev.some((p) => p.id === created.id)) return prev;
        const card = toCard(created);
        return [card, ...prev];
      });
      return created.id;
    },
    [service, selectedId]
  );
  const deleteMany = React.useCallback(
    async (ids) => {
      for (const id of ids) await service.deleteWebpage(id);
      await load();
    },
    [service, load]
  );
  const deleteOne = React.useCallback(
    async (id) => {
      await service.deleteWebpage(id);
      setItems((prev) => prev.filter((p) => p.id != id));
    },
    [service, selectedId]
  );
  const updateNote = React.useCallback(
    async (id, note) => {
      const updated = await service.updateWebpage(id, { note });
      setItems((prev) => prev.map((p) => p.id === id ? toCard(updated) : p));
    },
    [service]
  );
  const updateDescription = React.useCallback(
    async (id, description) => {
      const updated = await service.updateWebpage(id, { note: description });
      setItems((prev) => prev.map((p) => p.id === id ? toCard(updated) : p));
    },
    [service]
  );
  const updateCard = React.useCallback(
    async (id, patch) => {
      const payload = {};
      if (patch.title !== void 0) payload.title = patch.title;
      if (patch.description !== void 0) payload.note = patch.description;
      if (patch.url !== void 0) payload.url = patch.url;
      if (patch.meta !== void 0) payload.meta = patch.meta;
      const updated = await service.updateWebpage(id, payload);
      setItems((prev) => prev.map((p) => p.id === id ? toCard(updated) : p));
    },
    [service]
  );
  const updateTitle = React.useCallback(
    async (id, title) => {
      const updated = await service.updateWebpage(id, { title });
      setItems((prev) => prev.map((p) => p.id === id ? toCard(updated) : p));
    },
    [service]
  );
  const updateUrl = React.useCallback(
    async (id, url) => {
      const updated = await service.updateWebpage(id, { url });
      setItems((prev) => prev.map((p) => p.id === id ? toCard(updated) : p));
    },
    [service]
  );
  const updateCategory = React.useCallback(
    async (id, category) => {
      var _a;
      let updates = { category };
      try {
        const { createStorageService: createStorageService2 } = await __vitePreload(async () => {
          const { createStorageService: createStorageService3 } = await import("./webpageService-CB3FiJ-p.js").then((n) => n.s);
          return { createStorageService: createStorageService3 };
        }, true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url);
        const s = createStorageService2();
        const [cats, tmpls] = await Promise.all([
          s.loadFromSync(),
          s.loadTemplates()
        ]);
        const cat = cats.find((c) => c.id === category);
        const tpl = (cat == null ? void 0 : cat.defaultTemplateId) ? tmpls.find((t) => t.id === cat.defaultTemplateId) : null;
        if (tpl) {
          const item = items.find((i) => i.id === id);
          let nextMeta = computeAutoMeta(
            item == null ? void 0 : item.meta,
            tpl.fields || [],
            item ? { title: item.title, url: item.url, favicon: item.favicon } : void 0
          );
          delete nextMeta.title;
          delete nextMeta.description;
          try {
            if (item) {
              const { getCachedMeta } = await __vitePreload(async () => {
                const { getCachedMeta: getCachedMeta2 } = await import("./pageMeta-Cp1CNcZM.js");
                return { getCachedMeta: getCachedMeta2 };
              }, true ? __vite__mapDeps([0,1]) : void 0, import.meta.url);
              let cached = await getCachedMeta(item.url);
              const needKeys = ["siteName", "author"];
              const missing = (m) => !m || needKeys.some((key) => !(m[key] || "").trim());
              if (missing(cached) && typeof globalThis.chrome !== "undefined") {
                try {
                  await new Promise((resolve) => {
                    chrome.tabs.query({}, async (tabs) => {
                      const {
                        urlsRoughlyEqual,
                        extractMetaForTab,
                        waitForTabComplete
                      } = await __vitePreload(async () => {
                        const {
                          urlsRoughlyEqual: urlsRoughlyEqual2,
                          extractMetaForTab: extractMetaForTab2,
                          waitForTabComplete: waitForTabComplete2
                        } = await import("./pageMeta-Cp1CNcZM.js");
                        return {
                          urlsRoughlyEqual: urlsRoughlyEqual2,
                          extractMetaForTab: extractMetaForTab2,
                          waitForTabComplete: waitForTabComplete2
                        };
                      }, true ? __vite__mapDeps([0,1]) : void 0, import.meta.url);
                      const match = (tabs || []).find(
                        (t) => t.url && urlsRoughlyEqual(t.url, item.url)
                      );
                      if (match && match.id != null) {
                        try {
                          try {
                            await waitForTabComplete(match.id);
                          } catch {
                          }
                          const live = await extractMetaForTab(
                            match.id
                          );
                          cached = {
                            ...cached || {},
                            ...live || {}
                          };
                        } catch {
                        }
                      }
                      resolve();
                    });
                  });
                } catch {
                }
              }
              const wantKeys = ["siteName", "author"];
              const fields = tpl.fields || [];
              const hasField = (key) => fields.some((f) => f.key === key);
              const merged = { ...nextMeta };
              for (const key of wantKeys) {
                const cur = ((_a = merged[key]) != null ? _a : "").trim();
                const val = cached == null ? void 0 : cached[key];
                if (!cur && val && hasField(key)) merged[key] = val;
              }
              nextMeta = merged;
            }
          } catch {
          }
          updates.meta = nextMeta;
        }
      } catch {
      }
      const updated = await service.updateWebpage(id, updates);
      setItems((prev) => prev.map((p) => p.id === id ? toCard(updated) : p));
      try {
        const fields = await (async () => {
          const { createStorageService: createStorageService2 } = await __vitePreload(async () => {
            const { createStorageService: createStorageService3 } = await import("./webpageService-CB3FiJ-p.js").then((n) => n.s);
            return { createStorageService: createStorageService3 };
          }, true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url);
          const s = createStorageService2();
          const [cats, tmpls] = await Promise.all([
            s.loadFromSync(),
            s.loadTemplates()
          ]);
          const cat = cats.find((c) => c.id === category);
          const tpl = (cat == null ? void 0 : cat.defaultTemplateId) ? tmpls.find((t) => t.id === cat.defaultTemplateId) : null;
          return (tpl == null ? void 0 : tpl.fields) || [];
        })();
        const hasSite = fields.some((f) => f.key === "siteName");
        const hasAuthor = fields.some((f) => f.key === "author");
        if (hasSite || hasAuthor) {
          setTimeout(async () => {
            try {
              const { getCachedMeta } = await __vitePreload(async () => {
                const { getCachedMeta: getCachedMeta2 } = await import("./pageMeta-Cp1CNcZM.js");
                return { getCachedMeta: getCachedMeta2 };
              }, true ? __vite__mapDeps([0,1]) : void 0, import.meta.url);
              const cached2 = await getCachedMeta(updated.url);
              if (!cached2) return;
              const curMeta = updated.meta || {};
              const patchMeta = { ...curMeta };
              let changed = false;
              if (hasSite && !(patchMeta.siteName || "").trim() && cached2.siteName) {
                patchMeta.siteName = String(cached2.siteName);
                changed = true;
              }
              if (hasAuthor && !(patchMeta.author || "").trim() && cached2.author) {
                patchMeta.author = String(cached2.author);
                changed = true;
              }
              if (changed) {
                const upd2 = await service.updateWebpage(id, {
                  meta: patchMeta
                });
                setItems(
                  (prev) => prev.map((p) => p.id === id ? toCard(upd2) : p)
                );
              }
            } catch {
            }
          }, 500);
        }
      } catch {
      }
    },
    [service]
  );
  const updateMeta = React.useCallback(
    async (id, meta) => {
      const updated = await service.updateWebpage(id, { meta });
      setItems((prev) => prev.map((p) => p.id === id ? toCard(updated) : p));
    },
    [service]
  );
  const reorder = React.useCallback(
    async (fromId, toId) => {
      const saved = await service.reorderWebpages(fromId, toId);
      setItems(saved.map(toCard));
      return saved;
    },
    [service]
  );
  const moveToEnd = React.useCallback(
    async (id) => {
      const saved = await service.moveWebpageToEnd(id);
      setItems(saved.map(toCard));
      return saved;
    },
    [service]
  );
  React.useEffect(() => {
    load().catch(() => {
    });
  }, [load]);
  React.useEffect(() => {
    var _a, _b, _c;
    let t = null;
    const onChanged = (changes, areaName) => {
      try {
        if (areaName !== "local") return;
        if (!changes || typeof changes !== "object") return;
        if (!("webpages" in changes)) return;
        if (t) clearTimeout(t);
        t = setTimeout(() => {
          load().catch(() => {
          });
        }, 200);
      } catch {
      }
    };
    try {
      (_c = (_b = (_a = chrome == null ? void 0 : chrome.storage) == null ? void 0 : _a.onChanged) == null ? void 0 : _b.addListener) == null ? void 0 : _c.call(_b, onChanged);
    } catch {
    }
    return () => {
      var _a2, _b2, _c2;
      try {
        (_c2 = (_b2 = (_a2 = chrome == null ? void 0 : chrome.storage) == null ? void 0 : _a2.onChanged) == null ? void 0 : _b2.removeListener) == null ? void 0 : _c2.call(_b2, onChanged);
      } catch {
      }
      if (t) clearTimeout(t);
    };
  }, [load]);
  const value = React.useMemo(
    () => ({
      items,
      actions: {
        load,
        addFromTab,
        deleteMany,
        deleteOne,
        updateNote,
        updateDescription,
        updateCard,
        updateTitle,
        updateUrl,
        updateCategory,
        updateMeta,
        reorder,
        moveToEnd
      }
    }),
    [
      items,
      load,
      addFromTab,
      deleteMany,
      deleteOne,
      updateNote,
      updateDescription,
      updateCard,
      updateTitle,
      updateUrl,
      updateCategory,
      updateMeta,
      reorder,
      moveToEnd
    ]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Ctx$1.Provider, { value, children });
};
function useWebpages() {
  const v = React.useContext(Ctx$1);
  if (!v) {
    return {
      items: [],
      actions: {
        load: async () => {
        },
        addFromTab: async () => "",
        deleteMany: async () => {
        },
        deleteOne: async () => {
        },
        updateNote: async () => {
        },
        updateDescription: async () => {
        },
        updateCard: async () => {
        },
        updateTitle: async () => {
        },
        updateUrl: async () => {
        },
        updateCategory: async () => {
        },
        updateMeta: async () => {
        },
        reorder: () => {
        },
        moveToEnd: () => {
        }
      }
    };
  }
  return v;
}
const SearchBox = ({ placeholder = "Search…", onNavigateTo, className, hotkey = true }) => {
  const { items } = useWebpages();
  const { setCurrentCategory, categories } = useCategories();
  const [q, setQ] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [activeIdx, setActiveIdx] = React.useState(0);
  const [showAll, setShowAll] = React.useState(false);
  const [groupNameMap, setGroupNameMap] = React.useState({});
  const rootRef = React.useRef(null);
  const inputRef = React.useRef(null);
  const results = React.useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return [];
    const orgCategoryIds = new Set((categories || []).map((c) => c.id));
    const scored = items.filter((it) => !it.category || orgCategoryIds.has(it.category)).map((it) => {
      const hay = `${it.title} ${it.url} ${it.description || ""}`.toLowerCase();
      const match = hay.indexOf(term);
      if (match === -1) return null;
      return { it, score: match };
    }).filter(Boolean);
    scored.sort((a, b) => a.score - b.score);
    return scored.slice(0, 10).map((s) => s.it);
  }, [q, items, categories]);
  React.useEffect(() => {
    const onDoc = (e) => {
      if (!rootRef.current) return;
      if (!rootRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);
  React.useEffect(() => {
    if (!hotkey) return;
    const onKey = (e) => {
      var _a;
      const key = (e.key || "").toLowerCase();
      const tgt = e.target;
      const tag = ((tgt == null ? void 0 : tgt.tagName) || "").toLowerCase();
      const isTyping = tag === "input" || tag === "textarea" || (tgt == null ? void 0 : tgt.isContentEditable);
      if (isTyping) return;
      if ((e.ctrlKey || e.metaKey) && key === "k") {
        e.preventDefault();
        (_a = inputRef.current) == null ? void 0 : _a.focus();
        setOpen(!!q);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [hotkey, q]);
  function navigateTo(id, categoryId) {
    setQ("");
    setOpen(false);
    setActiveIdx(0);
    if (onNavigateTo) return onNavigateTo(id, categoryId);
    setCurrentCategory(categoryId);
    const HIGHLIGHT_MS = 3e3;
    let tries = 0;
    const maxTries = 50;
    const findScrollParent = (node) => {
      let el = (node == null ? void 0 : node.parentElement) || null;
      while (el) {
        const style = window.getComputedStyle(el);
        const oy = style.overflowY;
        const canScroll = (oy === "auto" || oy === "scroll") && el.scrollHeight > el.clientHeight;
        if (canScroll) return el;
        el = el.parentElement;
      }
      return null;
    };
    const stickyOffsetPx = (container) => {
      let off = 0;
      const gh = document.querySelector("header");
      if (gh) off += gh.getBoundingClientRect().height;
      if (container) {
        const ch = container.querySelector(".toby-board-header");
        if (ch) off += ch.getBoundingClientRect().height;
      }
      return off;
    };
    const tick = () => {
      var _a;
      try {
        window.dispatchEvent(
          new CustomEvent("groups:collapse-all", {
            detail: { categoryId, collapsed: false }
          })
        );
      } catch {
      }
      const el = document.getElementById(`card-${id}`);
      if (el) {
        const container = findScrollParent(el) || document.querySelector('[aria-label="Content Area"]');
        const rect = el.getBoundingClientRect();
        if (container) {
          const crect = container.getBoundingClientRect();
          const current2 = container.scrollTop;
          const offset = rect.top - crect.top;
          const stickyOff = stickyOffsetPx(container);
          const targetTop = current2 + offset - Math.max(0, crect.height / 2 - rect.height / 2) - stickyOff * 0.6;
          try {
            container.scrollTo({ top: targetTop, behavior: "smooth" });
          } catch {
            container.scrollTop = targetTop;
          }
        } else {
          const stickyOff = stickyOffsetPx(null);
          const targetTop = window.scrollY + rect.top - stickyOff;
          try {
            window.scrollTo({ top: targetTop, behavior: "smooth" });
          } catch {
            window.scrollTo(0, targetTop);
          }
        }
        (_a = el.focus) == null ? void 0 : _a.call(el);
        el.classList.add("ring-2", "ring-emerald-500", "outline", "outline-2", "outline-emerald-500");
        setTimeout(() => {
          el.classList.remove("ring-2", "ring-emerald-500", "outline", "outline-2", "outline-emerald-500");
        }, HIGHLIGHT_MS);
        return;
      }
      if (tries++ < maxTries) setTimeout(tick, 100);
    };
    setTimeout(tick, 120);
  }
  async function prepareGroupNames(list) {
    var _a;
    try {
      const cats = Array.from(new Set(list.map((it) => it.category).filter(Boolean)));
      const svc = createStorageService();
      const map = {};
      for (const cid of cats) {
        try {
          const subs = await ((_a = svc.listSubcategories) == null ? void 0 : _a.call(svc, cid));
          for (const s of subs || []) map[s.id] = s.name || "group";
        } catch {
        }
      }
      setGroupNameMap(map);
    } catch {
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref: rootRef, className: `relative ${className || ""}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          ref: inputRef,
          "aria-label": "Search",
          className: `text-sm rounded bg-slate-900 border border-slate-700 px-2 py-1 outline-none focus:border-slate-500 ${(className == null ? void 0 : className.includes("w-")) ? "" : "w-64"} ${className || ""}`,
          placeholder,
          value: q,
          onChange: (e) => {
            setQ(e.target.value);
            setOpen(true);
            setActiveIdx(0);
          },
          onFocus: () => q && setOpen(true),
          onKeyDown: (e) => {
            if (!open && (e.key === "ArrowDown" || e.key === "Enter"))
              setOpen(true);
            if (!results.length) return;
            if (e.key === "ArrowDown") {
              e.preventDefault();
              setActiveIdx((i) => Math.min(i + 1, results.length - 1));
            } else if (e.key === "ArrowUp") {
              e.preventDefault();
              setActiveIdx((i) => Math.max(i - 1, 0));
            } else if (e.key === "Enter") {
              const pick = results[activeIdx] || results[0];
              if (pick) {
                navigateTo(pick.id, pick.category || "default");
                setOpen(false);
              }
            } else if (e.key === "Escape") {
              setOpen(false);
            }
          }
        }
      ),
      open && results.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute z-[9999] mt-1 w-96 left-0 rounded border border-slate-700 bg-[var(--bg)] shadow-lg", children: [
        results.map((it, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: `block w-full text-left px-3 py-2 text-sm hover:bg-slate-800 ${idx === activeIdx ? "bg-slate-800" : ""}`,
            onMouseEnter: () => setActiveIdx(idx),
            onClick: () => {
              navigateTo(it.id, it.category || "default");
              setOpen(false);
            },
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              it.favicon ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: it.favicon, alt: "", className: "w-3 h-3" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-3 h-3 bg-slate-600 rounded" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: it.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "opacity-60 truncate", children: it.url }),
              it.category && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-auto text-[11px] px-1 py-0.5 rounded bg-slate-800 border border-slate-700 opacity-80", children: (() => {
                const cid = String(it.category);
                const c = (categories || []).find(
                  (x) => x.id === cid
                );
                return (c == null ? void 0 : c.name) || cid;
              })() })
            ] })
          },
          it.id
        )),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2 border-t border-slate-700 text-xs opacity-80", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "hover:text-white", onClick: async () => {
          setOpen(false);
          await prepareGroupNames(results);
          setShowAll(true);
        }, children: "顯示全部結果…" }) })
      ] }),
      open && q && results.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute z-[9999] mt-1 w-96 left-0 rounded border border-slate-700 bg-[var(--bg)] shadow-lg px-3 py-2 text-sm opacity-80", children: "No results" })
    ] }),
    showAll && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-4", onClick: () => setShowAll(false), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded border border-slate-700 bg-[var(--bg)] w-[900px] max-w-[95vw] max-h-[85vh] overflow-auto", onClick: (e) => e.stopPropagation(), role: "dialog", "aria-label": "Search Results", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 border-b border-slate-700 flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm opacity-80", children: [
          results.length,
          " results"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "text-sm px-2 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: () => setShowAll(false), children: "關閉" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3", children: (() => {
        const byCat = {};
        for (const it of results) {
          const cid = String(it.category || "");
          (byCat[cid] || (byCat[cid] = [])).push(it);
        }
        const catEntries = Object.entries(byCat);
        return catEntries.map(([cid, arr]) => {
          const cat = (categories || []).find((c) => c.id === cid);
          const catName = (cat == null ? void 0 : cat.name) || cid || "Unknown";
          const bySub = {};
          for (const it of arr) {
            const gid = String(it.subcategoryId || "__none__");
            (bySub[gid] || (bySub[gid] = [])).push(it);
          }
          const subEntries = Object.entries(bySub);
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium mb-1", children: catName }),
            subEntries.map(([gid, list]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs opacity-80 mb-1", children: [
                groupNameMap[gid] || "group",
                " ",
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "opacity-60", children: [
                  "(",
                  list.length,
                  ")"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1", children: list.map((it) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: "block w-full text-left px-3 py-2 text-sm rounded hover:bg-slate-800 border border-transparent hover:border-slate-700",
                  onClick: () => {
                    setShowAll(false);
                    navigateTo(it.id, it.category || "default");
                  },
                  children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    it.favicon ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: it.favicon, alt: "", className: "w-3 h-3" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-3 h-3 bg-slate-600 rounded" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "truncate", children: it.title }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "opacity-60 truncate", children: it.url })
                  ] })
                },
                it.id
              )) })
            ] }, gid))
          ] }, cid);
        });
      })() })
    ] }) })
  ] });
};
const Sidebar = () => {
  var _a;
  const {
    categories,
    selectedId,
    setCurrentCategory,
    actions: catActions
  } = useCategories();
  const { organizations, selectedOrgId, setCurrentOrganization } = useOrganizations();
  const { templates } = useTemplates();
  const [editing, setEditing] = React.useState(null);
  const [editName, setEditName] = React.useState("");
  const [editColor, setEditColor] = React.useState("#64748b");
  const [editTpl, setEditTpl] = React.useState("");
  const [confirmDelete, setConfirmDelete] = React.useState(false);
  function openEditor(cat) {
    setEditing(cat);
    setEditName(cat.name || "");
    setEditColor(cat.color || "#64748b");
    setEditTpl(cat.defaultTemplateId || "");
  }
  const { actions } = useWebpages();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-[13px] h-full flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 text-lg font-semibold", children: ((_a = organizations.find((o) => o.id === selectedOrgId)) == null ? void 0 : _a.name) || "Organization" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6 relative overflow-visible", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      SearchBox,
      {
        placeholder: "Search...",
        className: "w-full"
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[11px] uppercase text-[var(--muted)] font-semibold tracking-wider", children: "COLLECTIONS" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "text-red-400 hover:text-red-300 text-lg font-semibold",
          title: "Add new collection",
          onClick: () => {
            try {
              window.dispatchEvent(new CustomEvent("collections:add-new"));
            } catch {
            }
          },
          children: "+"
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { "aria-label": "Categories", className: "space-y-1 h-full overflow-y-auto pr-1", children: categories.map((c, _idx) => {
      const active = selectedId === c.id;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: `w-full px-2 py-1 rounded border border-slate-700 transition-colors flex items-center gap-2 ${active ? "bg-[var(--card)]" : "hover:bg-slate-800/40"}
            `,
          "data-active": active ? "true" : void 0,
          draggable: true,
          onDragStart: (e) => {
            try {
              e.dataTransfer.setData(
                "application/x-linktrove-category",
                c.id
              );
              e.dataTransfer.effectAllowed = "move";
            } catch {
            }
          },
          onDragOver: (e) => {
            e.preventDefault();
          },
          onDragEnter: (e) => {
            e.currentTarget.setAttribute(
              "data-drop",
              "true"
            );
          },
          onDragLeave: (e) => {
            e.currentTarget.removeAttribute("data-drop");
          },
          onDrop: (e) => {
            e.preventDefault();
            try {
              const catId = e.dataTransfer.getData(
                "application/x-linktrove-category"
              );
              if (catId) {
                const ids = categories.map((x) => x.id).filter(Boolean);
                const fromIdx = ids.indexOf(catId);
                const toIdx = ids.indexOf(c.id);
                if (fromIdx !== -1 && toIdx !== -1 && fromIdx !== toIdx) {
                  const arr = [...ids];
                  const [m] = arr.splice(fromIdx, 1);
                  arr.splice(toIdx, 0, m);
                  void catActions.reorderCategories(arr);
                }
              } else {
              }
            } catch {
            }
            e.currentTarget.removeAttribute("data-drop");
          },
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                className: "flex-1 text-left",
                "data-active": active ? "true" : void 0,
                onClick: () => setCurrentCategory(c.id),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "span",
                    {
                      className: "inline-block w-2 h-2 mr-2 rounded align-middle",
                      style: { backgroundColor: c.color || "#94a3b8" },
                      "aria-hidden": true
                    }
                  ),
                  c.name
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                className: "text-xs px-1 py-0.5 rounded border border-slate-600 hover:bg-slate-800",
                title: "Edit category",
                onClick: (e) => {
                  e.stopPropagation();
                  openEditor(c);
                },
                children: "⚙︎"
              }
            )
          ]
        },
        c.id
      );
    }) }) }),
    editing && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3",
        onClick: () => {
          setEditing(null);
          setConfirmDelete(false);
        },
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--panel)] w-[560px] max-w-[95vw]",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "Edit Category",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-slate-700", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold", children: "Edit Category" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-70", children: "Update name, color, and default template" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "Name" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: editName,
                      onChange: (e) => setEditName(e.target.value)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "Color" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "span",
                      {
                        className: "inline-block w-3 h-3 rounded",
                        style: { backgroundColor: editColor }
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "color",
                        className: "rounded border border-slate-700 bg-slate-900 p-1",
                        value: editColor,
                        onChange: (e) => setEditColor(e.target.value)
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        className: "flex-1 rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                        value: editColor,
                        onChange: (e) => setEditColor(e.target.value)
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:col-span-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "Default Template" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "select",
                    {
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: editTpl,
                      onChange: (e) => setEditTpl(e.target.value),
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "None" }),
                        templates.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: t.id, children: t.name }, t.id))
                      ]
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3 border-t border-slate-700 flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: !confirmDelete ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "text-xs px-2 py-1 rounded border border-red-600 text-red-300 hover:bg-red-950/30",
                    onClick: () => setConfirmDelete(true),
                    children: "Delete category…"
                  }
                ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-red-300", children: "Confirm deletion?" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      className: "px-2 py-1 rounded border border-slate-600 hover:bg-slate-800",
                      onClick: () => setConfirmDelete(false),
                      children: "Cancel"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      className: "px-2 py-1 rounded border border-red-600 text-red-300 hover:bg-red-950/30",
                      onClick: async () => {
                        try {
                          if (!editing) return;
                          await catActions.deleteCategory(editing.id);
                          setEditing(null);
                          setConfirmDelete(false);
                        } catch {
                        }
                      },
                      children: "Delete"
                    }
                  )
                ] }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                      onClick: () => {
                        setEditing(null);
                        setConfirmDelete(false);
                      },
                      children: "Cancel"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      className: "px-3 py-1 rounded border border-emerald-600 text-emerald-300 hover:bg-emerald-950/30",
                      onClick: async () => {
                        var _a2;
                        try {
                          const id = editing.id;
                          if (editName.trim() && editName.trim() !== editing.name)
                            await catActions.renameCategory(id, editName.trim());
                          if ((editColor || "") !== (editing.color || ""))
                            await ((_a2 = catActions.updateColor) == null ? void 0 : _a2.call(
                              catActions,
                              id,
                              editColor || "#64748b"
                            ));
                          if ((editTpl || "") !== (editing.defaultTemplateId || ""))
                            await catActions.setDefaultTemplate(
                              id,
                              editTpl || void 0
                            );
                          setEditing(null);
                          setConfirmDelete(false);
                        } catch {
                        }
                      },
                      children: "Save"
                    }
                  )
                ] })
              ] })
            ]
          }
        )
      }
    )
  ] });
};
const OrganizationNav = () => {
  const { organizations, selectedOrgId, setCurrentOrganization } = useOrganizations();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-16 flex flex-col items-center py-4 h-full", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 flex-1", children: [
      organizations.map((org, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: `w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold text-sm transition-all hover:scale-105 ${selectedOrgId === org.id ? "ring-2 ring-blue-400 shadow-lg" : "hover:ring-2 hover:ring-slate-400"}`,
          style: { backgroundColor: org.color || "#64748b" },
          onClick: () => setCurrentOrganization(org.id),
          title: org.name,
          children: org.name.slice(0, 2).toUpperCase()
        },
        org.id
      )),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "w-12 h-12 rounded-full border-2 border-dashed border-slate-500 flex items-center justify-center text-slate-400 hover:border-slate-300 hover:text-slate-300 transition-colors",
          onClick: () => {
            try {
              window.dispatchEvent(new CustomEvent("organizations:add-new"));
            } catch {
            }
          },
          title: "Add new organization",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-6 h-6", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 6v6m0 0v6m0-6h6m-6 0H6" }) })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 mt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-slate-300 hover:bg-slate-700 transition-colors",
          title: "App Settings",
          onClick: () => {
            try {
              window.dispatchEvent(new CustomEvent("app:open-settings"));
            } catch {
            }
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "12", cy: "12", r: "2.2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M12 3.8v1.4M12 18.8v1.4M4.75 6.35l.99.99M18.26 19.86l.99.99M3.8 12h1.4M18.8 12h1.4M4.75 17.65l.99-.99M18.26 4.14l.99-.99" })
          ] })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-slate-300 hover:bg-slate-700 transition-colors",
          title: "Toggle Theme",
          onClick: () => {
            try {
              window.dispatchEvent(new CustomEvent("app:toggle-theme"));
            } catch {
            }
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5 text-violet-300", fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M21 12.79A9 9 0 1111.21 3c.03 0 .06 0 .09 0a7 7 0 109.7 9.7c0 .03 0 .06 0 .09z" }) })
        }
      )
    ] })
  ] });
};
const Ctx = reactExports.createContext(null);
const FeedbackProvider = ({
  children
}) => {
  const [toasts, setToasts] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(false);
  const showToast = (message, kind = "info") => {
    const id = Math.random().toString(36).slice(2, 9);
    const toast = { id, message, kind };
    setToasts((t) => [...t, toast]);
    setTimeout(() => {
      setToasts((t) => t.filter((x) => x.id !== id));
    }, 3e3);
  };
  const value = reactExports.useMemo(() => ({ showToast, setLoading }), []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Ctx.Provider, { value, children: [
    children,
    loading && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        role: "status",
        "aria-live": "polite",
        className: "fixed inset-0 z-[60] flex items-center justify-center bg-black/40",
        onClick: () => setLoading(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded border border-slate-700 bg-[var(--bg)] px-4 py-2", children: "Loading..." })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed bottom-4 right-4 z-[70] space-y-2", children: toasts.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `rounded border px-3 py-2 text-sm shadow ${t.kind === "success" ? "border-emerald-500 bg-emerald-950/30" : t.kind === "error" ? "border-red-600 bg-red-950/30" : "border-slate-700 bg-slate-900"}`,
        children: t.message
      },
      t.id
    )) })
  ] });
};
function useFeedback() {
  const v = reactExports.useContext(Ctx);
  if (!v) {
    return {
      showToast: () => {
      },
      setLoading: () => {
      }
    };
  }
  return v;
}
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(err) {
    return { hasError: true, message: err == null ? void 0 : err.message };
  }
  componentDidCatch(err) {
    console.error(err);
  }
  render() {
    if (this.state.hasError) {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded border border-red-600 bg-red-950/30", children: [
        "Something went wrong.",
        this.state.message && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-sm opacity-80", children: this.state.message })
      ] });
    }
    return this.props.children;
  }
}
function isWebpage(x) {
  return x && typeof x.id === "string" && typeof x.url === "string" && typeof x.title === "string";
}
function isCategory(x) {
  return x && typeof x.id === "string" && typeof x.name === "string";
}
function isTemplate(x) {
  return x && typeof x.id === "string" && typeof x.name === "string" && Array.isArray(x.fields);
}
function createExportImportService(deps) {
  const { storage } = deps;
  async function exportJson() {
    return storage.exportData();
  }
  async function importJsonMerge(jsonData) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
    let parsed;
    try {
      parsed = JSON.parse(jsonData);
    } catch {
      throw new Error("Invalid JSON");
    }
    const incomingPages = Array.isArray(parsed == null ? void 0 : parsed.webpages) ? parsed.webpages : [];
    const incomingCats = Array.isArray(parsed == null ? void 0 : parsed.categories) ? parsed.categories : [];
    const incomingTpls = Array.isArray(parsed == null ? void 0 : parsed.templates) ? parsed.templates : [];
    const incomingSubcats = Array.isArray(parsed == null ? void 0 : parsed.subcategories) ? parsed.subcategories : [];
    if (!incomingPages.every(isWebpage))
      throw new Error("Invalid webpages payload");
    if (!incomingCats.every(isCategory))
      throw new Error("Invalid categories payload");
    if (!incomingTpls.every(isTemplate))
      throw new Error("Invalid templates payload");
    const prevPages = await storage.loadFromLocal().catch(() => []);
    const prevCats = await storage.loadFromSync().catch(() => []);
    const existingPageIds = new Set(prevPages.map((p) => String(p.id)));
    const existingPageUrls = new Set(prevPages.map((p) => String(p.url)));
    const existingCatIds = new Set(prevCats.map((c) => String(c.id)));
    const addedPages = incomingPages.filter((p) => !existingPageIds.has(String(p.id)) && !existingPageUrls.has(String(p.url))).length;
    const addedCategories = incomingCats.filter((c) => !existingCatIds.has(String(c.id))).length;
    try {
      await Promise.all([
        clearStore("webpages"),
        clearStore("categories"),
        clearStore("templates"),
        clearStore("subcategories").catch(() => {
        })
      ]);
    } catch {
    }
    const byCat = {};
    const subcatsToWrite = [];
    if (Array.isArray(incomingSubcats)) {
      for (const s of incomingSubcats) {
        if (s && typeof s.id === "string" && typeof s.categoryId === "string") {
          (byCat[_a = s.categoryId] || (byCat[_a] = [])).push(s);
          subcatsToWrite.push(s);
        }
      }
    }
    const defaults = {};
    function ensureDefault(catId) {
      var _a2, _b2;
      if (!defaults[catId]) {
        const sc = {
          id: "g_" + Math.random().toString(36).slice(2, 9),
          categoryId: catId,
          name: "group",
          order: (_b2 = (_a2 = byCat[catId]) == null ? void 0 : _a2.length) != null ? _b2 : 0,
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        defaults[catId] = sc;
        (byCat[catId] || (byCat[catId] = [])).push(sc);
        subcatsToWrite.push(sc);
      }
      return defaults[catId];
    }
    for (const c of incomingCats) {
      if (!byCat[c.id] || byCat[c.id].length === 0) ensureDefault(c.id);
    }
    const subcatIndex = {};
    for (const s of subcatsToWrite) subcatIndex[s.id] = s;
    for (const p of incomingPages) {
      const valid = p.subcategoryId && subcatIndex[p.subcategoryId];
      if (!valid || subcatIndex[p.subcategoryId].categoryId !== p.category) {
        const def = ensureDefault(p.category);
        p.subcategoryId = def.id;
      }
    }
    try {
      if (subcatsToWrite.length)
        await putAll("subcategories", subcatsToWrite);
    } catch {
    }
    await Promise.all([
      storage.saveToLocal(incomingPages),
      storage.saveToSync(incomingCats),
      // templates 可選：若儲存層未提供 saveTemplates，則略過
      typeof storage.saveTemplates === "function" ? storage.saveTemplates(incomingTpls) : Promise.resolve()
    ]);
    try {
      (_d = (_c = (_b = chrome.storage) == null ? void 0 : _b.local) == null ? void 0 : _c.set) == null ? void 0 : _d.call(_c, { categories: incomingCats });
    } catch {
    }
    try {
      (_g = (_f = (_e = chrome.storage) == null ? void 0 : _e.local) == null ? void 0 : _f.set) == null ? void 0 : _g.call(_f, { templates: incomingTpls });
    } catch {
    }
    const settings = (parsed == null ? void 0 : parsed.settings) || {};
    try {
      if (settings.theme) {
        let t = settings.theme;
        if (t === "dark" || t === "light") t = "dracula";
        if (t === "dracula" || t === "gruvbox") {
          (_j = (_i = (_h = chrome.storage) == null ? void 0 : _h.local) == null ? void 0 : _i.set) == null ? void 0 : _j.call(_i, { theme: t });
          try {
            await setMeta("settings.theme", t);
          } catch {
          }
        }
      }
      if (typeof settings.selectedCategoryId === "string" && settings.selectedCategoryId) {
        (_m = (_l = (_k = chrome.storage) == null ? void 0 : _k.local) == null ? void 0 : _l.set) == null ? void 0 : _m.call(_l, {
          selectedCategoryId: settings.selectedCategoryId
        });
        try {
          await setMeta(
            "settings.selectedCategoryId",
            settings.selectedCategoryId
          );
        } catch {
        }
      }
    } catch {
    }
    return {
      addedPages,
      addedCategories,
      addedTemplates: incomingTpls.length
    };
  }
  return { exportJson, importJsonMerge };
}
const TemplatesManager$1 = () => {
  const { templates, actions } = useTemplates();
  const { showToast } = useFeedback();
  const [usageMap, setUsageMap] = React.useState({});
  const [usageDetails, setUsageDetails] = React.useState({});
  const [modal, setModal] = React.useState(null);
  const { categories, actions: catActions } = useCategories();
  const [name, setName] = React.useState("");
  const [newField, setNewField] = React.useState({});
  const [collapsed, setCollapsed] = React.useState({});
  const [commonAdd, setCommonAdd] = React.useState({});
  React.useEffect(() => {
    (async () => {
      try {
        const s = createStorageService();
        const cats = await s.loadFromSync();
        const count = {};
        const detail = {};
        for (const c of cats || []) {
          const tid = c.defaultTemplateId;
          if (!tid) continue;
          count[tid] = (count[tid] || 0) + 1;
          if (!detail[tid]) detail[tid] = [];
          detail[tid].push(c.name || c.id);
        }
        setUsageMap(count);
        setUsageDetails(detail);
      } catch {
      }
    })();
  }, [templates]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-bold mb-2", children: "Templates" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-400", children: "管理書籤卡片的欄位模板，定義不同類型網頁的資料結構" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-slate-500", children: [
          "共 ",
          templates.length,
          " 個模板"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-r from-slate-900/40 to-slate-800/40 rounded-xl p-6 mb-8 border border-slate-700/50", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-shrink-0 w-10 h-10 rounded-lg bg-[var(--accent)]/10 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5 text-[var(--accent)]", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 6v6m0 0v6m0-6h6m-6 0H6" }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-lg", children: "新增模板" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-400", children: "創建新的欄位模板或使用預設模板快速開始" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: "flex-1 max-w-md rounded-lg bg-slate-900/80 border border-slate-600 px-4 py-3 text-sm placeholder:text-slate-500 focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)] focus:outline-none transition-colors",
              placeholder: "輸入模板名稱（例如：文章模板、產品模板）",
              value: name,
              onChange: (e) => setName(e.target.value)
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              className: "px-6 py-3 rounded-lg bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] font-medium transition-colors flex items-center gap-2 shadow-lg",
              onClick: async () => {
                const nn = (name || "").trim();
                if (!nn) return;
                const dup = templates.find((t) => (t.name || "").trim().toLowerCase() === nn.toLowerCase());
                if (dup) {
                  setModal({ title: "名稱已存在", content: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    "已存在同名模板「",
                    nn,
                    "」，請改用其他名稱。"
                  ] }) });
                  return;
                }
                await actions.add(nn);
                setName("");
              },
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 6v6m0 0v6m0-6h6m-6 0H6" }) }),
                "新增模板"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-700/50 pt-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-slate-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13 10V3L4 14h7v7l9-11h-7z" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-slate-300", children: "快速創建預設模板" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 flex-wrap", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "flex items-center gap-2 px-4 py-2.5 rounded-lg border border-blue-500/50 text-blue-300 bg-blue-950/20 hover:bg-blue-950/40 transition-colors text-sm font-medium shadow-sm",
                onClick: async () => {
                  const templateName = "書籍模板";
                  const nn = templateName.trim();
                  const dup = templates.find((t) => (t.name || "").trim().toLowerCase() === nn.toLowerCase());
                  if (dup) {
                    setModal({ title: "名稱已存在", content: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      "已存在同名模板「",
                      nn,
                      "」。如需另建，請先改名稱避免混淆。"
                    ] }) });
                    return;
                  }
                  const newTemplate = await actions.add(templateName);
                  if (newTemplate == null ? void 0 : newTemplate.id) {
                    await actions.addFields(newTemplate.id, [
                      // 依序：書名 作者 連載狀態 類型 字數 評分 站名 最後更新時間
                      { key: "bookTitle", label: "書名", type: "text" },
                      { key: "author", label: "作者", type: "text" },
                      { key: "serialStatus", label: "連載狀態", type: "select", options: ["連載中", "已完結", "太監"] },
                      { key: "genre", label: "類型", type: "text" },
                      { key: "wordCount", label: "字數", type: "number" },
                      { key: "rating", label: "評分", type: "rating" },
                      { key: "siteName", label: "站名", type: "text" },
                      { key: "lastUpdate", label: "最後更新時間", type: "date" }
                    ]);
                  }
                },
                children: "📚 書籍模板"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "flex items-center gap-2 px-4 py-2.5 rounded-lg border border-purple-500/50 text-purple-300 bg-purple-950/20 hover:bg-purple-950/40 transition-colors text-sm font-medium shadow-sm",
                onClick: async () => {
                  const templateName = "工具模板";
                  const newTemplate = await actions.add(templateName);
                  if (newTemplate == null ? void 0 : newTemplate.id) {
                    await actions.addFields(newTemplate.id, [
                      { key: "rating", label: "評分", type: "rating" },
                      { key: "tags", label: "標籤", type: "tags" },
                      { key: "description", label: "功能描述", type: "text" },
                      { key: "platform", label: "平台", type: "select", options: ["Web", "Desktop", "Mobile", "CLI", "跨平台"] },
                      { key: "price", label: "價格", type: "select", options: ["免費", "免費增值", "付費", "訂閱制"] },
                      { key: "used", label: "使用狀態", type: "select", options: ["在用", "試過", "想試", "不推薦"] }
                    ]);
                  }
                },
                children: "🔧 工具模板"
              }
            )
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        templates.map((t) => {
          var _a, _b, _c, _d, _e, _f, _g, _h;
          const fieldCount = (t.fields || []).length;
          const isUsed = usageMap[t.id] > 0;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-slate-700/50 bg-gradient-to-br from-slate-900/40 to-slate-800/40 shadow-lg hover:shadow-xl transition-all duration-300", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: `flex items-center justify-between px-6 py-4 ${!collapsed[t.id] ? "border-b border-slate-700/50" : ""}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 flex-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        "aria-label": "Toggle",
                        className: "flex items-center justify-center w-8 h-8 rounded-lg bg-slate-800/50 hover:bg-slate-700/50 transition-colors group",
                        onClick: () => setCollapsed((m) => ({ ...m, [t.id]: !m[t.id] })),
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "svg",
                          {
                            className: `w-4 h-4 text-slate-400 transition-transform duration-200 ${!collapsed[t.id] ? "rotate-180" : ""}`,
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M19 9l-7 7-7-7" })
                          }
                        )
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1", children: collapsed[t.id] ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-lg text-slate-200", children: t.name }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800/60 text-slate-300 border border-slate-600/50", children: [
                          fieldCount,
                          " 欄位"
                        ] }),
                        isUsed && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-green-900/40 text-green-300 border border-green-500/30", children: [
                          "使用中：",
                          usageMap[t.id]
                        ] })
                      ] })
                    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "input",
                        {
                          className: "text-lg font-semibold bg-transparent border-0 border-b-2 border-transparent hover:border-slate-600 focus:border-[var(--accent)] focus:outline-none transition-colors text-slate-200 pb-1 mb-2",
                          value: t.name,
                          onChange: async (e) => {
                            const v = e.target.value;
                            try {
                              await actions.rename(t.id, v);
                            } catch {
                              showToast("名稱已存在", "error");
                            }
                          }
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-3 text-sm text-slate-400", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                        "共 ",
                        fieldCount,
                        " 個欄位"
                      ] }) })
                    ] }) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-3", children: !isUsed ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      className: "flex items-center gap-2 px-3 py-2 rounded-lg border border-red-500/50 text-red-300 bg-red-950/20 hover:bg-red-950/40 transition-colors text-sm group",
                      onClick: async () => {
                        try {
                          await actions.remove(t.id);
                        } catch {
                          setModal({ title: "無法刪除模板", content: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "此模板正在被使用。" }) });
                        }
                      },
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 group-hover:scale-110 transition-transform", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" }) }),
                        "刪除"
                      ]
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 px-3 py-2 text-sm text-slate-400 bg-slate-800/30 rounded-lg border border-slate-600/30", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" }) }),
                    "使用中，無法刪除"
                  ] }) })
                ]
              }
            ),
            !collapsed[t.id] && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 pb-6", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5 text-slate-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-medium text-slate-300", children: "欄位設定" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-slate-800/40 rounded-lg p-4 mb-4 border border-slate-700/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-12 gap-4 text-sm font-medium text-slate-400 mb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-1" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-3", children: "欄位鍵" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-3", children: "顯示名稱" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-2", children: "型別" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-1", children: "必填" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-2", children: "操作" })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3 mb-8", children: (t.fields || []).map((f) => {
                const LOCKED = /* @__PURE__ */ new Set([
                  "bookTitle",
                  "author",
                  "serialStatus",
                  "genre",
                  "wordCount",
                  "rating",
                  "siteName",
                  "lastUpdate"
                ]);
                const isLocked = LOCKED.has(f.key);
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "div",
                  {
                    className: "bg-slate-900/40 rounded-lg p-4 border border-slate-700/50 hover:border-slate-600/50 transition-all duration-200 group",
                    draggable: true,
                    onDragStart: (e) => {
                      e.dataTransfer.setData(
                        "application/x-linktrove-field-key",
                        f.key
                      );
                      e.dataTransfer.effectAllowed = "move";
                    },
                    onDragOver: (e) => {
                      e.preventDefault();
                    },
                    onDrop: (e) => {
                      e.preventDefault();
                      const fromKey = e.dataTransfer.getData(
                        "application/x-linktrove-field-key"
                      );
                      if (fromKey && fromKey !== f.key)
                        actions.reorderField(t.id, fromKey, f.key);
                    },
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-12 gap-4 items-center", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-1 flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-lg bg-slate-800/50 hover:bg-slate-700/50 flex items-center justify-center cursor-move transition-colors group-hover:bg-slate-700/70", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-slate-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M8 9l4-4 4 4m0 6l-4 4-4-4" }) }) }) }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              className: `w-full rounded-lg px-3 py-2 text-sm transition-colors ${isLocked ? "bg-slate-800/60 text-slate-400 border border-slate-600/50 cursor-not-allowed" : "bg-slate-800/80 border border-slate-600 hover:border-slate-500 focus:border-[var(--accent)] focus:outline-none"}`,
                              value: f.key,
                              disabled: true,
                              title: isLocked ? "固定欄位鍵已鎖定" : "鍵不可變更"
                            }
                          ),
                          isLocked && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-2 top-1/2 -translate-y-1/2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-slate-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" }) }) })
                        ] }) }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "input",
                          {
                            className: "w-full rounded-lg bg-slate-800/80 border border-slate-600 hover:border-slate-500 focus:border-[var(--accent)] focus:outline-none px-3 py-2 text-sm transition-colors",
                            value: f.label,
                            onChange: (e) => actions.updateField(t.id, f.key, {
                              label: e.target.value
                            }),
                            placeholder: "輸入顯示名稱"
                          }
                        ) }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "select",
                          {
                            className: `w-full rounded-lg px-3 py-2 text-sm transition-colors ${isLocked ? "bg-slate-800/60 text-slate-400 border border-slate-600/50 cursor-not-allowed" : "bg-slate-800/80 border border-slate-600 hover:border-slate-500 focus:border-[var(--accent)] focus:outline-none"}`,
                            value: f.type || "text",
                            onChange: (e) => actions.updateFieldType(
                              t.id,
                              f.key,
                              e.target.value
                            ),
                            disabled: isLocked,
                            title: isLocked ? "固定欄位型別已鎖定" : void 0,
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "text", children: "text" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "number", children: "number" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "date", children: "date" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "url", children: "url" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "select", children: "select" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "rating", children: "rating" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "tags", children: "tags" })
                            ]
                          }
                        ) }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-1 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "flex items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                          "input",
                          {
                            type: "checkbox",
                            className: "w-4 h-4 text-[var(--accent)] bg-slate-800 border-slate-600 rounded focus:ring-[var(--accent)] focus:ring-2 transition-colors",
                            checked: !!f.required,
                            onChange: (e) => actions.updateFieldRequired(
                              t.id,
                              f.key,
                              e.target.checked
                            )
                          }
                        ) }) }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-2 flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                          "button",
                          {
                            className: "flex items-center gap-1 px-2 py-1 rounded-lg border border-red-500/50 text-red-300 bg-red-950/20 hover:bg-red-950/40 transition-colors text-xs group",
                            onClick: () => actions.removeField(t.id, f.key),
                            children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-3 h-3 group-hover:scale-110 transition-transform", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" }) }),
                              "刪除"
                            ]
                          }
                        ) })
                      ] }),
                      f.type === "select" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 pt-3 border-t border-slate-700/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-12 gap-4", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-1" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "col-span-11", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-400 mb-2", children: "選項設定（用逗號分隔）" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              className: "w-full rounded-lg bg-slate-800/80 border border-slate-600 hover:border-slate-500 focus:border-[var(--accent)] focus:outline-none px-3 py-2 text-sm transition-colors",
                              placeholder: "例如：選項1, 選項2, 選項3",
                              defaultValue: (f.options || []).join(", "),
                              onBlur: (e) => actions.updateFieldOptions(
                                t.id,
                                f.key,
                                e.target.value.split(",").map((s) => s.trim()).filter(Boolean)
                              )
                            }
                          )
                        ] }) })
                      ] }) })
                    ]
                  },
                  f.key
                );
              }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 bg-slate-800/30 rounded-lg p-6 border border-slate-700/50", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5 text-[var(--accent)]", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 6v6m0 0v6m0-6h6m-6 0H6" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h5", { className: "font-medium text-slate-300", children: "新增欄位" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-12 gap-4 mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-400 mb-2", children: "欄位鍵" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        className: "w-full rounded-lg bg-slate-800/80 border border-slate-600 hover:border-slate-500 focus:border-[var(--accent)] focus:outline-none px-3 py-2 text-sm transition-colors",
                        placeholder: "例如：author",
                        value: ((_a = newField[t.id]) == null ? void 0 : _a.key) || "",
                        onChange: (e) => setNewField({
                          ...newField,
                          [t.id]: {
                            ...newField[t.id] || { label: "" },
                            key: e.target.value
                          }
                        })
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-400 mb-2", children: "顯示名稱" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        className: "w-full rounded-lg bg-slate-800/80 border border-slate-600 hover:border-slate-500 focus:border-[var(--accent)] focus:outline-none px-3 py-2 text-sm transition-colors",
                        placeholder: "輸入顯示名稱",
                        value: ((_b = newField[t.id]) == null ? void 0 : _b.label) || "",
                        onChange: (e) => setNewField({
                          ...newField,
                          [t.id]: {
                            ...newField[t.id] || { key: "" },
                            label: e.target.value
                          }
                        })
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-400 mb-2", children: "型別" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "select",
                      {
                        className: "w-full rounded-lg bg-slate-800/80 border border-slate-600 hover:border-slate-500 focus:border-[var(--accent)] focus:outline-none px-3 py-2 text-sm transition-colors",
                        value: ((_c = newField[t.id]) == null ? void 0 : _c.type) || "text",
                        onChange: (e) => setNewField({
                          ...newField,
                          [t.id]: {
                            ...newField[t.id] || {
                              key: "",
                              label: ""
                            },
                            type: e.target.value
                          }
                        }),
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "text", children: "text" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "number", children: "number" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "date", children: "date" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "url", children: "url" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "select", children: "select" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "rating", children: "rating" }),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "tags", children: "tags" })
                        ]
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-1 flex flex-col", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-400 mb-2", children: "必填" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center h-[42px]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "input",
                      {
                        type: "checkbox",
                        className: "w-4 h-4 text-[var(--accent)] bg-slate-800 border-slate-600 rounded focus:ring-[var(--accent)] focus:ring-2 transition-colors",
                        checked: !!((_d = newField[t.id]) == null ? void 0 : _d.required),
                        onChange: (e) => setNewField({
                          ...newField,
                          [t.id]: {
                            ...newField[t.id] || {
                              key: "",
                              label: ""
                            },
                            required: e.target.checked
                          }
                        })
                      }
                    ) })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "col-span-3 flex flex-col", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-400 mb-2", children: " " }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "button",
                      {
                        className: "h-[42px] px-4 py-2 rounded-lg bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] font-medium transition-colors flex items-center justify-center gap-2 shadow-lg",
                        onClick: async () => {
                          const nf = newField[t.id] || {
                            key: "",
                            label: "",
                            type: "text"
                          };
                          const key = nf.key.trim();
                          const label = nf.label.trim();
                          if (!key || !label) {
                            setNewField({
                              ...newField,
                              [t.id]: { ...nf, err: "欄位鍵和顯示名稱為必填" }
                            });
                            return;
                          }
                          try {
                            const payload = {
                              key,
                              label,
                              type: nf.type || "text"
                            };
                            if (nf.type === "select" && (nf.options || "").trim()) {
                              payload.options = (nf.options || "").split(",").map((s) => s.trim()).filter(Boolean);
                            }
                            if (nf.required) payload.required = true;
                            await actions.addField(t.id, payload);
                            setNewField({
                              ...newField,
                              [t.id]: {
                                key: "",
                                label: "",
                                type: "text",
                                options: "",
                                required: false,
                                err: ""
                              }
                            });
                          } catch (e) {
                            setNewField({
                              ...newField,
                              [t.id]: {
                                ...nf,
                                err: (e == null ? void 0 : e.message) || "新增失敗"
                              }
                            });
                          }
                        },
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 6v6m0 0v6m0-6h6m-6 0H6" }) }),
                          "新增欄位"
                        ]
                      }
                    )
                  ] })
                ] }),
                ((_e = newField[t.id]) == null ? void 0 : _e.type) === "select" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-slate-400 mb-2", children: "選項設定（用逗號分隔）" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      className: "w-full rounded-lg bg-slate-800/80 border border-slate-600 hover:border-slate-500 focus:border-[var(--accent)] focus:outline-none px-3 py-2 text-sm transition-colors",
                      placeholder: "例如：選颅1, 選颅2, 選颅3",
                      value: ((_f = newField[t.id]) == null ? void 0 : _f.options) || "",
                      onChange: (e) => setNewField({
                        ...newField,
                        [t.id]: {
                          ...newField[t.id] || {
                            key: "",
                            label: ""
                          },
                          options: e.target.value
                        }
                      })
                    }
                  )
                ] }),
                ((_g = newField[t.id]) == null ? void 0 : _g.err) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3 rounded-lg bg-red-950/20 border border-red-500/30 text-red-300 text-sm", children: (_h = newField[t.id]) == null ? void 0 : _h.err })
              ] })
            ] })
          ] }, t.id);
        }),
        templates.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-12 text-slate-400", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-12 h-12 mx-auto mb-4 opacity-50", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 1.5, d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-medium mb-1", children: "還沒有模板" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", children: "創建第一個模板來開始管理你的書籤欄位" })
        ] })
      ] })
    ] }),
    modal && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3",
        onClick: () => setModal(null),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--panel)] w-[420px] max-w-[95vw] p-5",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": modal.title,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold mb-3", children: modal.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm mb-4", children: modal.content }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                  onClick: () => setModal(null),
                  children: "知道了"
                }
              ) })
            ]
          }
        )
      }
    )
  ] });
};
function detectConflict(local, remote) {
  const localCounts = {
    webpages: (local.webpages || []).length,
    categories: (local.categories || []).length,
    subcategories: (local.subcategories || []).length,
    templates: (local.templates || []).length,
    organizations: (local.organizations || []).length
  };
  const remoteCounts = {
    webpages: (remote.webpages || []).length,
    categories: (remote.categories || []).length,
    subcategories: (remote.subcategories || []).length,
    templates: (remote.templates || []).length,
    organizations: (remote.organizations || []).length
  };
  const diff = {
    webpages: localCounts.webpages - remoteCounts.webpages,
    categories: localCounts.categories - remoteCounts.categories,
    subcategories: localCounts.subcategories - remoteCounts.subcategories,
    templates: localCounts.templates - remoteCounts.templates,
    organizations: localCounts.organizations - remoteCounts.organizations
  };
  const hasConflict = Object.values(diff).some((d) => d !== 0);
  const maxWebpages = Math.max(localCounts.webpages, remoteCounts.webpages);
  const percentDiff = maxWebpages > 0 ? Math.abs(diff.webpages) / maxWebpages * 100 : 0;
  let severity = "none";
  if (hasConflict) {
    const webpageDiff = Math.abs(diff.webpages);
    if (webpageDiff > 0) {
      if (webpageDiff > 10 || percentDiff >= 20) {
        severity = "major";
      } else {
        severity = "minor";
      }
    }
  }
  return {
    hasConflict,
    severity,
    local: localCounts,
    remote: remoteCounts,
    diff,
    percentDiff
  };
}
function formatConflictMessage(info) {
  if (!info.hasConflict) {
    return "本地與雲端資料一致";
  }
  const lines = [];
  if (info.diff.webpages !== 0) {
    const dir = info.diff.webpages > 0 ? "多" : "少";
    lines.push(`網頁：本地 ${dir} ${Math.abs(info.diff.webpages)} 個`);
  }
  if (info.diff.categories !== 0) {
    const dir = info.diff.categories > 0 ? "多" : "少";
    lines.push(`分類：本地 ${dir} ${Math.abs(info.diff.categories)} 個`);
  }
  if (info.diff.subcategories !== 0) {
    const dir = info.diff.subcategories > 0 ? "多" : "少";
    lines.push(`群組：本地 ${dir} ${Math.abs(info.diff.subcategories)} 個`);
  }
  if (info.diff.templates !== 0) {
    const dir = info.diff.templates > 0 ? "多" : "少";
    lines.push(`模板：本地 ${dir} ${Math.abs(info.diff.templates)} 個`);
  }
  if (info.diff.organizations !== 0) {
    const dir = info.diff.organizations > 0 ? "多" : "少";
    lines.push(`組織：本地 ${dir} ${Math.abs(info.diff.organizations)} 個`);
  }
  return lines.join("\n");
}
const conflictDetection = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  detectConflict,
  formatConflictMessage
}, Symbol.toStringTag, { value: "Module" }));
const ConflictDialog = ({
  conflict,
  operation,
  onConfirm,
  onCancel,
  onBackupFirst
}) => {
  const isAutoSync = operation === "auto-sync";
  const severityColor = conflict.severity === "major" ? "text-red-400" : conflict.severity === "minor" ? "text-yellow-400" : "text-green-400";
  const severityLabel = conflict.severity === "major" ? "⚠️ 重大差異" : conflict.severity === "minor" ? "⚠ 輕微差異" : "✓ 無差異";
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-800 border border-slate-700 rounded-lg shadow-xl max-w-md w-full mx-4 p-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-xl font-bold ${severityColor}`, children: severityLabel }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold text-white", children: isAutoSync ? "啟用 Auto Sync" : "合併雲端資料" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-300 mb-2", children: "檢測到本地與雲端資料存在差異：" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-slate-900/50 border border-slate-700 rounded p-3 mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-2 text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-400", children: "項目" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-400 text-center", children: "本地" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-400 text-center", children: "雲端" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-300", children: "網頁" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: `text-center ${conflict.diff.webpages > 0 ? "text-green-400" : conflict.diff.webpages < 0 ? "text-red-400" : ""}`,
            children: conflict.local.webpages
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: `text-center ${conflict.diff.webpages < 0 ? "text-green-400" : conflict.diff.webpages > 0 ? "text-red-400" : ""}`,
            children: conflict.remote.webpages
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-300", children: "分類" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center", children: conflict.local.categories }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center", children: conflict.remote.categories }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-300", children: "群組" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center", children: conflict.local.subcategories }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center", children: conflict.remote.subcategories })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-slate-300 whitespace-pre-line", children: formatConflictMessage(conflict) })
    ] }),
    conflict.severity === "major" && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 px-3 py-2 rounded bg-red-900/20 border border-red-700/50 text-xs text-red-200", children: "⚠️ 差異較大，建議先備份本地資料後再繼續操作" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6 text-xs text-slate-400", children: isAutoSync ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "啟用 Auto Sync 後，每次本地變更將自動上傳至雲端。",
      /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
      "使用 LWW 合併策略：保留本地與雲端較新的版本。"
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: "合併操作將使用 LWW 策略：比較本地與雲端的時間戳記，保留較新的版本。" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: onConfirm,
          className: "w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium transition-colors",
          children: isAutoSync ? "確定啟用" : "確定合併"
        }
      ),
      onBackupFirst && conflict.severity === "major" && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: onBackupFirst,
          className: "w-full px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-medium transition-colors",
          children: "先備份本地資料"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: onCancel,
          className: "w-full px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded font-medium transition-colors",
          children: "取消"
        }
      )
    ] })
  ] }) });
};
const SettingsModal = ({ open, onClose }) => {
  const [section, setSection] = React.useState("data");
  if (!open) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-4", onClick: onClose, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "rounded border border-slate-700 bg-[var(--panel)] w-[960px] max-w-[95vw] max-h-[90vh] overflow-hidden",
      onClick: (e) => e.stopPropagation(),
      role: "dialog",
      "aria-label": "Settings",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex h-[70vh]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: "w-56 border-r border-slate-700 p-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold mb-3", children: "Settings" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "flex flex-col gap-1", "aria-label": "Settings Sections", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: `text-left px-2 py-1 rounded ${section === "data" ? "bg-slate-800" : "hover:bg-slate-800/60"}`,
                  onClick: () => setSection("data"),
                  children: "匯出/匯入"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: `text-left px-2 py-1 rounded ${section === "cloud" ? "bg-slate-800" : "hover:bg-slate-800/60"}`,
                  onClick: () => setSection("cloud"),
                  children: "Cloud Sync"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: `text-left px-2 py-1 rounded ${section === "templates" ? "bg-slate-800" : "hover:bg-slate-800/60"}`,
                  onClick: () => setSection("templates"),
                  children: "Templates"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1 p-4 overflow-auto", children: section === "data" ? /* @__PURE__ */ jsxRuntimeExports.jsx(DataPanel, {}) : section === "cloud" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CloudSyncPanel, {}) : /* @__PURE__ */ jsxRuntimeExports.jsx(TemplatesManager$1, {}) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 py-2 border-t border-slate-700 flex items-center justify-end", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: onClose, children: "關閉" }) })
      ]
    }
  ) });
};
const DataPanel = () => {
  const { showToast, setLoading } = useFeedback();
  const { actions: pagesActions } = useWebpages();
  const { actions: catActions } = useCategories();
  const { actions: tplActions } = useTemplates();
  const svc = React.useMemo(() => createExportImportService({ storage: createStorageService() }), []);
  const [file, setFile] = React.useState(null);
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [inlineMsg, setInlineMsg] = React.useState(null);
  const performImport = async () => {
    var _a, _b;
    setConfirmOpen(false);
    setLoading(true);
    try {
      const text = await file.text();
      let pagesCount = 0;
      let catsCount = 0;
      try {
        const parsed = JSON.parse(text);
        pagesCount = Array.isArray(parsed == null ? void 0 : parsed.webpages) ? parsed.webpages.length : 0;
        catsCount = Array.isArray(parsed == null ? void 0 : parsed.categories) ? parsed.categories.length : 0;
      } catch {
      }
      const storage = createStorageService();
      await storage.importData(text);
      try {
        await pagesActions.load();
      } catch {
      }
      try {
        await ((_a = catActions == null ? void 0 : catActions.reload) == null ? void 0 : _a.call(catActions));
      } catch {
      }
      try {
        await ((_b = tplActions == null ? void 0 : tplActions.reload) == null ? void 0 : _b.call(tplActions));
      } catch {
      }
      const summary = `Imported: ${pagesCount} pages, ${catsCount} categories`;
      setInlineMsg({ kind: "success", text: summary });
      showToast("Import success", "success");
    } catch (e) {
      const msg = (e == null ? void 0 : e.message) || "Import failed";
      setInlineMsg({ kind: "error", text: msg });
      showToast(msg, "error");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-2 text-lg font-semibold", children: "專案備份與還原（僅本專案）" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm opacity-80 mb-4", children: "匯出/匯入本專案格式 JSON。此匯入將取代現有資料，建議先匯出備份。" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium mb-2", children: "匯出備份" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "text-sm px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
              onClick: async () => {
                setLoading(true);
                try {
                  const json = await svc.exportJson();
                  const blob = new Blob([json], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = "linktrove-export.json";
                  a.click();
                  URL.revokeObjectURL(url);
                  showToast("Export ready", "success");
                } catch {
                  showToast("Export failed", "error");
                } finally {
                  setLoading(false);
                }
              },
              children: "Export JSON"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-700 pt-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium mb-2", children: "還原（取代現有資料）" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "rounded border-2 border-dashed border-slate-600 hover:border-[var(--accent)] hover:bg-[var(--accent-hover)] p-3 text-sm",
              onDragOver: (e) => e.preventDefault(),
              onDrop: async (e) => {
                var _a;
                e.preventDefault();
                const f = (_a = e.dataTransfer.files) == null ? void 0 : _a[0];
                if (f) {
                  setFile(f);
                  try {
                    JSON.parse(await f.text());
                  } catch {
                    showToast("Invalid JSON", "error");
                  }
                }
              },
              children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 flex-wrap", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    id: "import-json-file-modal",
                    "aria-label": "Import JSON file",
                    type: "file",
                    accept: "application/json,.json",
                    className: "text-sm",
                    onChange: async (e) => {
                      var _a, _b;
                      const f = (_b = (_a = e.currentTarget.files) == null ? void 0 : _a[0]) != null ? _b : null;
                      setFile(f);
                      if (f) {
                        try {
                          JSON.parse(await f.text());
                        } catch {
                          showToast("Invalid JSON", "error");
                        }
                      }
                    },
                    onClick: (e) => {
                      e.currentTarget.value = "";
                    }
                  }
                ),
                file && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-80", children: file.name }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "ml-auto text-sm px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
                    disabled: !file,
                    onClick: () => setConfirmOpen(true),
                    children: "Import JSON"
                  }
                )
              ] })
            }
          )
        ] })
      ] }),
      inlineMsg && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: `mt-3 text-sm px-3 py-2 rounded border ${inlineMsg.kind === "success" ? "bg-[var(--accent-hover)] border-[var(--accent)]/60" : "bg-red-900/30 border-red-700"}`,
          children: inlineMsg.text
        }
      )
    ] }),
    confirmOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[10000] bg-black/60 flex items-center justify-center p-3", onClick: () => setConfirmOpen(false), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded border border-slate-700 bg-[var(--panel)] w-[520px] max-w-[95vw]", onClick: (e) => e.stopPropagation(), role: "dialog", "aria-label": "Confirm Import", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-slate-700", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold", children: "確認匯入" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-80 mt-1", children: "將取代現有資料。" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3 flex items-center justify-end gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: () => setConfirmOpen(false), children: "取消" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)]", onClick: performImport, children: "確認匯入" })
      ] })
    ] }) })
  ] });
};
const CloudSyncPanel = () => {
  const { actions: pagesActions } = useWebpages();
  const { actions: catActions } = useCategories();
  const { actions: tplActions } = useTemplates();
  const [connected, setConnected] = React.useState(false);
  const [last, setLast] = React.useState(void 0);
  const [syncing, setSyncing] = React.useState(false);
  const [error, setError] = React.useState(void 0);
  const [autoEnabled, setAutoEnabled] = React.useState(false);
  const [pendingPush, setPendingPush] = React.useState(false);
  const [lastDownloaded, setLastDownloaded] = React.useState(void 0);
  const [lastUploaded, setLastUploaded] = React.useState(void 0);
  const [conflictInfo, setConflictInfo] = React.useState(null);
  const [conflictOperation, setConflictOperation] = React.useState(null);
  const [snapshots, setSnapshots] = React.useState([]);
  const [loadingSnapshots, setLoadingSnapshots] = React.useState(false);
  const [gcStats, setGcStats] = React.useState(null);
  const [loadingGC, setLoadingGC] = React.useState(false);
  const [gcResult, setGcResult] = React.useState(null);
  const [confirmDialog, setConfirmDialog] = React.useState(null);
  const loadSyncStatus = React.useCallback(async () => {
    try {
      const got = await new Promise((resolve) => {
        var _a, _b, _c;
        try {
          (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { "cloudSync.status": {} }, resolve);
        } catch {
          resolve({});
        }
      });
      const st = (got == null ? void 0 : got["cloudSync.status"]) || {};
      setConnected(!!st.connected);
      setLast(st.lastSyncedAt);
      setSyncing(!!st.syncing);
      setError(st.error);
      setAutoEnabled(!!st.auto);
      setPendingPush(!!st.pendingPush);
      setLastDownloaded(st.lastDownloadedAt);
      setLastUploaded(st.lastUploadedAt);
    } catch {
    }
  }, []);
  React.useEffect(() => {
    var _a, _b, _c;
    loadSyncStatus();
    loadSnapshotsList();
    loadGCStats();
    const listener = (changes, areaName) => {
      if (areaName === "local") {
        if (changes["cloudSync.status"]) {
          loadSyncStatus();
        }
        if (changes["cloudSync.snapshots"]) {
          loadSnapshotsList();
        }
      }
    };
    try {
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.onChanged) == null ? void 0 : _b.addListener) == null ? void 0 : _c.call(_b, listener);
    } catch {
    }
    return () => {
      var _a2, _b2, _c2;
      try {
        (_c2 = (_b2 = (_a2 = chrome.storage) == null ? void 0 : _a2.onChanged) == null ? void 0 : _b2.removeListener) == null ? void 0 : _c2.call(_b2, listener);
      } catch {
      }
    };
  }, [loadSyncStatus]);
  async function loadSnapshotsList() {
    try {
      const snapshotModule = await __vitePreload(() => import("./snapshotService-Dbi-XpZB.js"), true ? __vite__mapDeps([4,2,1,3]) : void 0, import.meta.url);
      const list = await snapshotModule.listSnapshots();
      setSnapshots(list);
    } catch {
      setSnapshots([]);
    }
  }
  async function doRestoreSnapshot(snapshotId) {
    var _a, _b;
    setLoadingSnapshots(true);
    setError(void 0);
    setConfirmDialog(null);
    try {
      const snapshotModule = await __vitePreload(() => import("./snapshotService-Dbi-XpZB.js"), true ? __vite__mapDeps([4,2,1,3]) : void 0, import.meta.url);
      await snapshotModule.restoreSnapshot(snapshotId);
      try {
        await pagesActions.load();
      } catch {
      }
      try {
        await ((_a = catActions == null ? void 0 : catActions.reload) == null ? void 0 : _a.call(catActions));
      } catch {
      }
      try {
        await ((_b = tplActions == null ? void 0 : tplActions.reload) == null ? void 0 : _b.call(tplActions));
      } catch {
      }
      await loadSnapshotsList();
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
    } finally {
      setLoadingSnapshots(false);
    }
  }
  async function doDeleteSnapshot(snapshotId) {
    setConfirmDialog(null);
    try {
      const snapshotModule = await __vitePreload(() => import("./snapshotService-Dbi-XpZB.js"), true ? __vite__mapDeps([4,2,1,3]) : void 0, import.meta.url);
      await snapshotModule.deleteSnapshot(snapshotId);
      await loadSnapshotsList();
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
    }
  }
  async function loadGCStats() {
    try {
      const gcModule = await __vitePreload(() => import("./gcService-C8XCQ9nw.js"), true ? __vite__mapDeps([5,2,1,3]) : void 0, import.meta.url);
      const stats = await gcModule.getGCStats();
      setGcStats(stats);
    } catch {
      setGcStats(null);
    }
  }
  async function doRunGC() {
    setLoadingGC(true);
    setError(void 0);
    setGcResult(null);
    setConfirmDialog(null);
    try {
      const gcModule = await __vitePreload(() => import("./gcService-C8XCQ9nw.js"), true ? __vite__mapDeps([5,2,1,3]) : void 0, import.meta.url);
      const result = await gcModule.runGC(30);
      const msg = `已清理 ${result.cleaned} 個項目（網頁 ${result.categories.webpages}, 分類 ${result.categories.categories}, 子分類 ${result.categories.subcategories}, 模板 ${result.categories.templates}, 組織 ${result.categories.organizations}）`;
      setGcResult(msg);
      await loadGCStats();
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
    } finally {
      setLoadingGC(false);
    }
  }
  async function doConnect() {
    setError(void 0);
    try {
      const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
      await mod.connect();
      setConnected(true);
      const refreshed = mod.getStatus();
      setLast(refreshed.lastSyncedAt);
      setAutoEnabled(!!refreshed.auto);
      setPendingPush(!!refreshed.pendingPush);
      setLastDownloaded(refreshed.lastDownloadedAt);
      setLastUploaded(refreshed.lastUploadedAt);
      if (refreshed.auto) {
        try {
          const [storageModule, driveModule, conflictModule] = await Promise.all([
            __vitePreload(() => import("./webpageService-CB3FiJ-p.js").then((n) => n.s), true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url),
            __vitePreload(() => import("./googleDrive-CyCKFRry.js"), true ? [] : void 0, import.meta.url),
            __vitePreload(() => Promise.resolve().then(() => conflictDetection), true ? void 0 : void 0, import.meta.url)
          ]);
          const fileInfo = await driveModule.getFile();
          if (!fileInfo) {
            return;
          }
          const storage = storageModule.createStorageService();
          const localData = await storage.exportData();
          const localPayload = JSON.parse(localData);
          const remoteText = await driveModule.download(fileInfo.fileId);
          const remotePayload = JSON.parse(remoteText);
          const conflict = conflictModule.detectConflict(localPayload, remotePayload);
          if (conflict.hasConflict) {
            setConflictInfo(conflict);
            setConflictOperation("auto-sync");
          }
        } catch (conflictError) {
          console.warn("Conflict detection failed:", conflictError);
        }
      }
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
    }
  }
  async function doBackup() {
    setSyncing(true);
    setError(void 0);
    try {
      const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
      await mod.backupNow();
      const refreshed = mod.getStatus();
      setLast(refreshed.lastSyncedAt);
      setLastUploaded(refreshed.lastUploadedAt);
      setPendingPush(!!refreshed.pendingPush);
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
    } finally {
      setSyncing(false);
    }
  }
  async function doRestore(merge = true) {
    if (!merge) {
      setSyncing(true);
      setError(void 0);
      try {
        try {
          const snapshotModule = await __vitePreload(() => import("./snapshotService-Dbi-XpZB.js"), true ? __vite__mapDeps([4,2,1,3]) : void 0, import.meta.url);
          await snapshotModule.createSnapshot("before-restore");
        } catch (snapshotError) {
          console.warn("Failed to create snapshot:", snapshotError);
        }
        const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
        await mod.restoreNow(void 0, false);
        const refreshed = mod.getStatus();
        setLast(refreshed.lastSyncedAt);
        setLastDownloaded(refreshed.lastDownloadedAt);
        setPendingPush(!!refreshed.pendingPush);
      } catch (e) {
        setError(String((e == null ? void 0 : e.message) || e));
      } finally {
        setSyncing(false);
      }
      return;
    }
    setError(void 0);
    try {
      const [storageModule, driveModule, conflictModule] = await Promise.all([
        __vitePreload(() => import("./webpageService-CB3FiJ-p.js").then((n) => n.s), true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url),
        __vitePreload(() => import("./googleDrive-CyCKFRry.js"), true ? [] : void 0, import.meta.url),
        __vitePreload(() => Promise.resolve().then(() => conflictDetection), true ? void 0 : void 0, import.meta.url)
      ]);
      const storage = storageModule.createStorageService();
      const localData = await storage.exportData();
      const localPayload = JSON.parse(localData);
      const fileInfo = await driveModule.getFile();
      if (!fileInfo) {
        throw new Error("雲端尚無備份");
      }
      const remoteText = await driveModule.download(fileInfo.fileId);
      const remotePayload = JSON.parse(remoteText);
      const conflict = conflictModule.detectConflict(localPayload, remotePayload);
      if (!conflict.hasConflict) {
        setSyncing(true);
        const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
        await mod.restoreNow(void 0, true);
        const refreshed = mod.getStatus();
        setLast(refreshed.lastSyncedAt);
        setLastDownloaded(refreshed.lastDownloadedAt);
        setPendingPush(!!refreshed.pendingPush);
        setSyncing(false);
      } else {
        setConflictInfo(conflict);
        setConflictOperation("manual-merge");
      }
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
    }
  }
  async function confirmManualMerge() {
    setSyncing(true);
    setError(void 0);
    try {
      try {
        const snapshotModule = await __vitePreload(() => import("./snapshotService-Dbi-XpZB.js"), true ? __vite__mapDeps([4,2,1,3]) : void 0, import.meta.url);
        await snapshotModule.createSnapshot("before-merge");
      } catch (snapshotError) {
        console.warn("Failed to create snapshot:", snapshotError);
      }
      const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
      await mod.restoreNow(void 0, true);
      const refreshed = mod.getStatus();
      setLast(refreshed.lastSyncedAt);
      setLastDownloaded(refreshed.lastDownloadedAt);
      setPendingPush(!!refreshed.pendingPush);
      setConflictInfo(null);
      setConflictOperation(null);
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
      setConflictInfo(null);
      setConflictOperation(null);
    } finally {
      setSyncing(false);
    }
  }
  async function backupAndConfirmMerge() {
    try {
      await doBackup();
      await confirmManualMerge();
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
      setConflictInfo(null);
      setConflictOperation(null);
    }
  }
  async function doDisconnect() {
    setError(void 0);
    try {
      const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
      await mod.disconnect();
      setConnected(false);
      setPendingPush(false);
      setAutoEnabled(false);
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
    }
  }
  async function toggleAutoSync(next) {
    setError(void 0);
    if (!next) {
      try {
        const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
        await mod.setAutoSync(false);
        setAutoEnabled(false);
      } catch (e) {
        setError(String((e == null ? void 0 : e.message) || e));
      }
      return;
    }
    try {
      const [storageModule, driveModule, conflictModule] = await Promise.all([
        __vitePreload(() => import("./webpageService-CB3FiJ-p.js").then((n) => n.s), true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url),
        __vitePreload(() => import("./googleDrive-CyCKFRry.js"), true ? [] : void 0, import.meta.url),
        __vitePreload(() => Promise.resolve().then(() => conflictDetection), true ? void 0 : void 0, import.meta.url)
      ]);
      const storage = storageModule.createStorageService();
      const localData = await storage.exportData();
      const localPayload = JSON.parse(localData);
      const fileInfo = await driveModule.getFile();
      if (!fileInfo) {
        const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
        await mod.setAutoSync(true);
        setAutoEnabled(true);
        const refreshed = mod.getStatus();
        setPendingPush(!!refreshed.pendingPush);
        setLast(refreshed.lastSyncedAt);
        return;
      }
      const remoteText = await driveModule.download(fileInfo.fileId);
      const remotePayload = JSON.parse(remoteText);
      const conflict = conflictModule.detectConflict(localPayload, remotePayload);
      if (!conflict.hasConflict) {
        const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
        await mod.setAutoSync(true);
        setAutoEnabled(true);
        const refreshed = mod.getStatus();
        setPendingPush(!!refreshed.pendingPush);
        setLast(refreshed.lastSyncedAt);
      } else {
        setConflictInfo(conflict);
        setConflictOperation("auto-sync");
      }
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
    }
  }
  async function confirmAutoSync() {
    try {
      const mod = await __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url);
      await mod.setAutoSync(true);
      setAutoEnabled(true);
      const refreshed = mod.getStatus();
      setPendingPush(!!refreshed.pendingPush);
      setLastDownloaded(refreshed.lastDownloadedAt);
      setLastUploaded(refreshed.lastUploadedAt);
      setLast(refreshed.lastSyncedAt);
      setConflictInfo(null);
      setConflictOperation(null);
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
      setConflictInfo(null);
      setConflictOperation(null);
    }
  }
  async function backupAndConfirmAutoSync() {
    try {
      await doBackup();
      await confirmAutoSync();
    } catch (e) {
      setError(String((e == null ? void 0 : e.message) || e));
      setConflictInfo(null);
      setConflictOperation(null);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold mb-2", children: "Google Drive 雲端同步" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm opacity-80 mb-3", children: "使用 Google Drive appDataFolder 儲存備份（私有、不顯示於雲端硬碟）" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      connected ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 text-xs rounded bg-emerald-900/40 border border-emerald-700 text-emerald-200", children: "已連線" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "text-sm px-2 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: doDisconnect, children: "中斷連線" })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "text-sm px-3 py-1.5 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)]", onClick: doConnect, children: "連線 Google Drive" }),
      syncing && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs opacity-70 animate-pulse", children: "同步中…" }),
      pendingPush && !syncing && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs opacity-70", children: "待上傳…" })
    ] }),
    connected && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-700 pt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium mb-2", children: "手動操作" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "text-sm px-3 py-1.5 rounded border border-slate-600 hover:bg-slate-800 disabled:opacity-50",
            disabled: !connected || syncing,
            onClick: doBackup,
            children: "立即備份"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "text-sm px-3 py-1.5 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
            disabled: !connected || syncing,
            onClick: () => doRestore(true),
            title: "合併雲端資料到本地（保留兩邊較新的版本）",
            children: "合併雲端資料"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            className: "text-sm px-3 py-1.5 rounded border border-slate-600 hover:bg-slate-800 disabled:opacity-50",
            disabled: !connected || syncing,
            onClick: () => doRestore(false),
            title: "完全覆蓋本地資料（謹慎使用）",
            children: "完全還原"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-60 mt-2", children: "備份：上傳本地到雲端（覆蓋） / 合併：保留兩邊較新的版本 / 完全還原：雲端覆蓋本地" })
    ] }),
    connected && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-700 pt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-start gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "checkbox",
            checked: autoEnabled,
            onChange: (e) => toggleAutoSync(e.target.checked),
            className: "h-4 w-4 rounded border border-slate-600 mt-0.5"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium", children: "自動同步" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-70 mt-1", children: "啟用後，本地變更會自動上傳；啟動時若雲端較新會自動下載" })
        ] })
      ] }),
      autoEnabled && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 px-3 py-2 rounded bg-emerald-900/20 border border-emerald-700/50 text-xs text-emerald-200", children: "✓ 已啟用 LWW 合併：自動保留本地與雲端較新的版本，降低資料衝突風險" })
    ] }),
    connected && last && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs opacity-60 border-t border-slate-700 pt-3", children: [
      "最後同步：",
      new Date(last).toLocaleString("zh-TW", { hour12: false })
    ] }),
    error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-red-400 bg-red-900/20 border border-red-700/50 rounded px-3 py-2", children: [
      "錯誤：",
      error
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-700 pt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium mb-2", children: "垃圾回收 (GC)" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-70 mb-3", children: "清理超過 30 天的已刪除項目，減少儲存空間並提升同步效能" }),
      gcStats && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2 bg-slate-800/30 rounded border border-slate-700 mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "opacity-70", children: "已刪除項目：" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium", children: [
            gcStats.totalTombstones,
            " 個"
          ] })
        ] }),
        gcStats.oldestTombstone && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mt-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "opacity-70", children: "最舊項目：" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs opacity-60", children: new Date(gcStats.oldestTombstone).toLocaleDateString("zh-TW") })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          className: "text-sm px-3 py-1.5 rounded border border-slate-600 hover:bg-slate-800 disabled:opacity-50",
          disabled: loadingGC || (gcStats == null ? void 0 : gcStats.totalTombstones) === 0,
          onClick: () => setConfirmDialog({ type: "gc" }),
          children: loadingGC ? "清理中…" : "執行 GC"
        }
      ),
      gcResult && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 px-3 py-2 rounded bg-emerald-900/20 border border-emerald-700/50 text-xs text-emerald-200", children: [
        "✓ ",
        gcResult
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-700 pt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium mb-2", children: "本地快照" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-70 mb-3", children: "在執行危險操作（完全還原/合併）前自動建立快照，可用於回復誤操作" }),
      snapshots.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-60 px-3 py-2 bg-slate-800/30 rounded border border-slate-700", children: "尚無快照" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: snapshots.map((snapshot) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2 bg-slate-800/30 rounded border border-slate-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs font-medium", children: new Date(snapshot.createdAt).toLocaleString("zh-TW", { hour12: false }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs opacity-60 mt-1", children: [
            snapshot.reason === "before-restore" && "完全還原前",
            snapshot.reason === "before-merge" && "合併前",
            snapshot.reason === "manual" && "手動建立",
            " · ",
            snapshot.summary.webpages,
            " 網頁, ",
            snapshot.summary.categories,
            " 分類"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "text-xs px-2 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
              disabled: loadingSnapshots,
              onClick: () => setConfirmDialog({ type: "restore-snapshot", snapshotId: snapshot.id }),
              children: "恢復"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "text-xs px-2 py-1 rounded border border-slate-600 hover:bg-slate-800 disabled:opacity-50",
              disabled: loadingSnapshots,
              onClick: () => setConfirmDialog({ type: "delete-snapshot", snapshotId: snapshot.id }),
              children: "刪除"
            }
          )
        ] })
      ] }) }, snapshot.id)) })
    ] }),
    conflictInfo && conflictOperation && /* @__PURE__ */ jsxRuntimeExports.jsx(
      ConflictDialog,
      {
        conflict: conflictInfo,
        operation: conflictOperation,
        onConfirm: () => {
          if (conflictOperation === "auto-sync") {
            confirmAutoSync();
          } else if (conflictOperation === "manual-merge") {
            confirmManualMerge();
          }
        },
        onCancel: () => {
          setConflictInfo(null);
          setConflictOperation(null);
        },
        onBackupFirst: () => {
          if (conflictOperation === "auto-sync") {
            backupAndConfirmAutoSync();
          } else if (conflictOperation === "manual-merge") {
            backupAndConfirmMerge();
          }
        }
      }
    ),
    confirmDialog && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[10001] bg-black/60 flex items-center justify-center p-4",
        onClick: () => setConfirmDialog(null),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--panel)] w-[460px] max-w-[95vw]",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "Confirm Action",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 py-3 border-b border-slate-700", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-base font-semibold", children: [
                confirmDialog.type === "gc" && "確認執行 GC",
                confirmDialog.type === "restore-snapshot" && "確認恢復快照",
                confirmDialog.type === "delete-snapshot" && "確認刪除快照"
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-4 text-sm opacity-90", children: [
                confirmDialog.type === "gc" && "確定要清理超過 30 天的已刪除項目？此操作不可回復。",
                confirmDialog.type === "restore-snapshot" && "確定要恢復此快照？當前資料將被替換。",
                confirmDialog.type === "delete-snapshot" && "確定要刪除此快照？"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 border-t border-slate-700 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1.5 rounded text-sm border border-slate-600 hover:bg-slate-800",
                    onClick: () => setConfirmDialog(null),
                    children: "取消"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1.5 rounded text-sm border border-red-600 text-red-400 hover:bg-red-900/30",
                    onClick: () => {
                      if (confirmDialog.type === "gc") {
                        doRunGC();
                      } else if (confirmDialog.type === "restore-snapshot" && confirmDialog.snapshotId) {
                        doRestoreSnapshot(confirmDialog.snapshotId);
                      } else if (confirmDialog.type === "delete-snapshot" && confirmDialog.snapshotId) {
                        doDeleteSnapshot(confirmDialog.snapshotId);
                      }
                    },
                    children: "確認"
                  }
                )
              ] })
            ]
          }
        )
      }
    )
  ] });
};
const ContextMenu = ({ x, y, items, onClose }) => {
  React.useEffect(() => {
    const onDoc = () => onClose();
    document.addEventListener("click", onDoc);
    return () => document.removeEventListener("click", onDoc);
  }, [onClose]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      role: "menu",
      className: "fixed z-[9990] min-w-[160px] rounded border border-slate-700 bg-[var(--bg)] shadow-lg",
      style: { left: x, top: y },
      onClick: (e) => e.stopPropagation(),
      children: items.map((it) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          role: "menuitem",
          className: "block w-full text-left px-3 py-2 hover:bg-[var(--accent-hover)] hover:text-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]/60",
          onClick: () => {
            it.onSelect();
          },
          children: it.label
        },
        it.key
      ))
    }
  );
};
const TobyLikeCard = ({
  title,
  description,
  faviconText: _faviconText = "WW",
  faviconUrl,
  url,
  categoryId,
  meta,
  selectMode,
  selected,
  onToggleSelect,
  onOpen,
  onDelete,
  onUpdateTitle,
  onUpdateUrl,
  onUpdateDescription,
  onUpdateMeta,
  onMoveToCategory,
  onModalOpenChange,
  onSave,
  ghost
}) => {
  const [confirming, setConfirming] = React.useState(false);
  const [showModal, setShowModal] = React.useState(false);
  const [titleValue, setTitleValue] = React.useState(title);
  const [urlValue, setUrlValue] = React.useState("");
  const [descValue, setDescValue] = React.useState(description || "");
  const [moveMenuPos, setMoveMenuPos] = React.useState(null);
  const { categories } = useCategories();
  const [metaValue, setMetaValue] = React.useState({
    ...meta || {}
  });
  const autoSaveTimeoutRef = React.useRef(null);
  function validateUrl(raw) {
    const v = (raw || "").trim();
    if (!v) return { error: "URL is required" };
    try {
      const u = new URL(v);
      if (!/^https?:$/.test(u.protocol))
        return { error: "Only http/https supported" };
      return { value: u.toString() };
    } catch {
      return { error: "Invalid URL" };
    }
  }
  const performAutoSave = React.useCallback(() => {
    if (!showModal) return;
    const patch = {
      title: titleValue.trim(),
      description: descValue
    };
    const norm = urlValue.trim() ? validateUrl(urlValue) : void 0;
    if (norm == null ? void 0 : norm.error) return;
    if (norm == null ? void 0 : norm.value) patch.url = norm.value;
    patch.meta = metaValue;
    if (onSave) {
      onSave(patch);
    } else {
      if (onUpdateTitle) onUpdateTitle(patch.title);
      if (patch.url && onUpdateUrl) onUpdateUrl(patch.url);
      if (onUpdateDescription) onUpdateDescription(patch.description);
      if (onUpdateMeta) onUpdateMeta(patch.meta);
    }
  }, [showModal, titleValue, descValue, urlValue, metaValue, onSave, onUpdateTitle, onUpdateUrl, onUpdateDescription, onUpdateMeta]);
  const triggerAutoSave = React.useCallback(() => {
    if (autoSaveTimeoutRef.current) {
      clearTimeout(autoSaveTimeoutRef.current);
    }
    autoSaveTimeoutRef.current = setTimeout(() => {
      performAutoSave();
    }, 500);
  }, [performAutoSave]);
  React.useEffect(() => {
    return () => {
      if (autoSaveTimeoutRef.current) {
        clearTimeout(autoSaveTimeoutRef.current);
      }
    };
  }, []);
  React.useEffect(() => {
    if (showModal) {
      setTitleValue(title);
      setDescValue(description || "");
      setUrlValue(url || "");
      setMetaValue({ ...meta || {} });
      (async () => {
        try {
          if (!url) return;
          const mod = await __vitePreload(() => import("./pageMeta-Cp1CNcZM.js"), true ? __vite__mapDeps([0,1]) : void 0, import.meta.url);
          const cached = await mod.getCachedMeta(url);
          if (cached) {
            const next = { ...meta || {}, ...metaValue || {} };
            if (!String(next.siteName || "").trim() && cached.siteName) {
              next.siteName = String(cached.siteName);
            }
            if (!String(next.author || "").trim() && cached.author) {
              next.author = String(cached.author);
            }
            setMetaValue(next);
          }
        } catch {
        }
      })();
    }
  }, [showModal, title, description, url, meta]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "tobylike", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        className: "card",
        "data-select": selectMode ? "true" : void 0,
        onClick: onOpen,
        style: {
          background: "var(--card)",
          ...ghost ? { opacity: 0.5, pointerEvents: "none" } : {}
        },
        "data-testid": ghost ? "ghost-card" : void 0,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "card-content", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "block-a", style: { width: "100%" }, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "div",
                {
                  className: "icon-container",
                  style: { background: faviconUrl ? "transparent" : void 0 },
                  children: [
                    (() => {
                      const defaultIconUrl = (() => {
                        var _a, _b;
                        try {
                          return ((_b = (_a = chrome == null ? void 0 : chrome.runtime) == null ? void 0 : _a.getURL) == null ? void 0 : _b.call(
                            _a,
                            "icons/default-favicon.png"
                          )) || "/icons/default-favicon.png";
                        } catch {
                          return "/icons/default-favicon.png";
                        }
                      })();
                      const src = faviconUrl || defaultIconUrl;
                      return /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "img",
                        {
                          src,
                          alt: "",
                          style: { width: 32, height: 32, objectFit: "cover" },
                          draggable: false
                        }
                      );
                    })(),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "label",
                      {
                        className: "checkbox-overlay",
                        onClick: (e) => {
                          e.stopPropagation();
                          const others = (() => {
                            try {
                              return document.querySelectorAll('input[aria-label="Select"]').length > 1;
                            } catch {
                              return false;
                            }
                          })();
                          if (selectMode || others) onToggleSelect == null ? void 0 : onToggleSelect();
                        },
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "input",
                            {
                              type: "checkbox",
                              "aria-label": "Select",
                              className: "sr-only",
                              checked: !!selected,
                              onClick: () => {
                                const others = (() => {
                                  try {
                                    return document.querySelectorAll('input[aria-label="Select"]').length > 1;
                                  } catch {
                                    return false;
                                  }
                                })();
                                if (selectMode || others) onToggleSelect == null ? void 0 : onToggleSelect();
                              },
                              onChange: () => {
                                const others = (() => {
                                  try {
                                    return document.querySelectorAll('input[aria-label="Select"]').length > 1;
                                  } catch {
                                    return false;
                                  }
                                })();
                                if (selectMode || others) onToggleSelect == null ? void 0 : onToggleSelect();
                              }
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `checkbox ${selected ? "checked" : ""}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "svg",
                            {
                              xmlns: "http://www.w3.org/2000/svg",
                              viewBox: "0 0 24 24",
                              fill: "none",
                              stroke: "currentColor",
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              children: /* @__PURE__ */ jsxRuntimeExports.jsx("polyline", { points: "20,6 9,17 4,12" })
                            }
                          ) })
                        ]
                      }
                    )
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "title-box", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "title", title, children: title }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sep" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "block-b", style: { width: "100%" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "description", title: description, children: description || "" }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              className: "delete-btn",
              title: "刪除",
              onClick: (e) => {
                e.stopPropagation();
                setConfirming(true);
              },
              children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "svg",
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  style: { width: 14, height: 14 },
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M18 6 L6 18" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M6 6 L18 18" })
                  ]
                }
              )
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "actions", onClick: (e) => e.stopPropagation(), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "action-btn",
                title: "編輯",
                "aria-label": "編輯",
                onClick: () => {
                  setTitleValue(title);
                  setDescValue(description || "");
                  setShowModal(true);
                  onModalOpenChange == null ? void 0 : onModalOpenChange(true);
                },
                children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "svg",
                  {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M13.5 6.5l4 4" })
                    ]
                  }
                )
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "action-btn",
                title: "移動",
                "aria-label": "移動",
                onClick: (e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  setMoveMenuPos({ x: r.left, y: r.bottom + 8 });
                },
                children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  "svg",
                  {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 24 24",
                    fill: "none",
                    stroke: "currentColor",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M9 15l6 -6" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M11 6l.463 -.536a5 5 0 0 1 7.071 7.072l-.534 .464" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M13 18l-.397 .534a5.068 5.068 0 0 1 -7.127 0a4.972 4.972 0 0 1 0 -7.071l.524 -.463" })
                    ]
                  }
                )
              }
            )
          ] })
        ]
      }
    ),
    confirming && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/60",
        onClick: () => setConfirming(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--bg)] p-4",
            role: "dialog",
            "aria-label": "Confirm Delete",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3 font-medium", children: "Confirm Delete" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 justify-end", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => setConfirming(false),
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-red-600 text-red-300 hover:bg-red-950/30",
                    onClick: () => {
                      setConfirming(false);
                      onDelete == null ? void 0 : onDelete();
                    },
                    children: "Delete"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    showModal && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 p-4",
        onClick: () => {
          setShowModal(false);
          onModalOpenChange == null ? void 0 : onModalOpenChange(false);
        },
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "relative rounded border border-slate-700 bg-[var(--panel)] w-[560px] max-w-[95vw] max-h-[90vh] overflow-y-auto hide-scrollbar p-5",
            role: "dialog",
            "aria-label": "Edit Card",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  "aria-label": "Close",
                  title: "Close",
                  className: "absolute right-2 top-2 text-slate-300 hover:text-white z-10",
                  onClick: () => {
                    setShowModal(false);
                    onModalOpenChange == null ? void 0 : onModalOpenChange(false);
                  },
                  children: "✕"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-medium pr-6 mb-4", children: "編輯卡片" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", htmlFor: "edit-title", children: "Title" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      id: "edit-title",
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: titleValue,
                      onChange: (e) => {
                        setTitleValue(e.target.value);
                        triggerAutoSave();
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", htmlFor: "edit-desc", children: "Description" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      id: "edit-desc",
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: descValue,
                      onChange: (e) => {
                        setDescValue(e.target.value);
                        triggerAutoSave();
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", htmlFor: "edit-url", children: "URL" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      id: "edit-url",
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: urlValue,
                      onChange: (e) => {
                        setUrlValue(e.target.value);
                        triggerAutoSave();
                      },
                      placeholder: "https://example.com"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  TemplateFields,
                  {
                    categoryId: categoryId || "default",
                    meta: metaValue,
                    onChange: (newMeta) => {
                      setMetaValue(newMeta);
                      triggerAutoSave();
                    }
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => {
                      setShowModal(false);
                      onModalOpenChange == null ? void 0 : onModalOpenChange(false);
                    },
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)]",
                    onClick: () => {
                      var _a;
                      const patch = {
                        title: titleValue.trim(),
                        description: descValue
                      };
                      const norm = urlValue.trim() ? validateUrl(urlValue) : void 0;
                      if (!norm || !norm.error) patch.url = (_a = norm == null ? void 0 : norm.value) != null ? _a : urlValue;
                      patch.meta = metaValue;
                      if (onSave) {
                        onSave(patch);
                      } else {
                        if (onUpdateTitle) onUpdateTitle(patch.title);
                        if (patch.url && onUpdateUrl) onUpdateUrl(patch.url);
                        if (onUpdateDescription)
                          onUpdateDescription(patch.description);
                        if (onUpdateMeta) onUpdateMeta(patch.meta);
                      }
                      setShowModal(false);
                      onModalOpenChange == null ? void 0 : onModalOpenChange(false);
                    },
                    children: "Save"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    moveMenuPos && /* @__PURE__ */ jsxRuntimeExports.jsx(
      ContextMenu,
      {
        x: moveMenuPos.x,
        y: moveMenuPos.y,
        onClose: () => setMoveMenuPos(null),
        items: categories.map((c) => ({
          key: c.id,
          label: c.name,
          onSelect: () => {
            onMoveToCategory == null ? void 0 : onMoveToCategory(c.id);
            setMoveMenuPos(null);
          }
        }))
      }
    )
  ] });
};
const TemplateFields = ({ categoryId, meta, onChange }) => {
  const { categories } = useCategories();
  const { templates } = useTemplates();
  const cat = categories.find((c) => c.id === categoryId);
  const tpl = templates.find(
    (t) => t.id === ((cat == null ? void 0 : cat.defaultTemplateId) || "")
  );
  if (!tpl || !tpl.fields || tpl.fields.length === 0) return null;
  const hasRequiredError = tpl.fields.some(
    (f) => {
      var _a;
      return f.required && !((_a = meta[f.key]) != null ? _a : "").trim();
    }
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
    tpl.fields.map((f) => {
      var _a;
      const val = (_a = meta[f.key]) != null ? _a : "";
      const set = (v) => onChange({ ...meta, [f.key]: v });
      const baseCls = `w-full rounded bg-slate-900 border p-2 text-sm ${f.required && !val ? "border-red-600" : "border-slate-700"}`;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-sm mb-1", children: [
          f.label,
          " ",
          f.required && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-red-400", children: "*" })
        ] }),
        f.type === "select" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            className: baseCls,
            value: val,
            onChange: (e) => set(e.target.value),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: f.defaultValue || "Select..." }),
              (f.options || []).map((op) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: op, children: op }, op))
            ]
          }
        ) : f.type === "number" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            className: baseCls,
            type: "number",
            value: val,
            placeholder: f.defaultValue || "",
            onChange: (e) => set(e.target.value)
          }
        ) : f.type === "date" ? (() => {
          const toDateInput = (s) => {
            if (!s) return "";
            const d = new Date(s);
            if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
            return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : "";
          };
          const dateVal = toDateInput(String(val || ""));
          return /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              className: baseCls,
              type: "date",
              value: dateVal,
              onChange: (e) => set(e.target.value)
            }
          );
        })() : f.type === "url" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            className: baseCls,
            type: "url",
            value: val,
            placeholder: f.defaultValue || "",
            onChange: (e) => set(e.target.value)
          }
        ) : f.type === "rating" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
          [1, 2, 3, 4, 5].map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              "aria-label": `Rate ${n}`,
              className: `text-lg ${Number(val) >= n ? "text-yellow-400" : "text-slate-600"} hover:text-yellow-300`,
              onClick: () => set(String(n)),
              children: Number(val) >= n ? "★" : "☆"
            },
            n
          )),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              className: "ml-2 text-xs text-slate-400 hover:text-slate-200",
              onClick: () => set(""),
              children: "Clear"
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            className: baseCls,
            value: val,
            placeholder: f.defaultValue || "",
            onChange: (e) => set(e.target.value)
          }
        )
      ] }, f.key);
    }),
    hasRequiredError && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-red-400", children: "請填寫所有必填欄位" })
  ] });
};
function isDebug(key = "dnd") {
  try {
    return localStorage.getItem(`lt:${key}:debug`) === "1";
  } catch {
    return false;
  }
}
function dbg(key = "dnd", ...args) {
  if (isDebug(key)) {
    try {
      console.debug(`[lt:${key}]`, ...args);
    } catch {
    }
  }
}
const CardGrid = ({
  items = [],
  onDropTab,
  onDeleteMany,
  onDeleteOne,
  onEditDescription,
  onSave,
  density = "cozy",
  collapsed = false,
  onReorder,
  onDropExistingCard,
  onUpdateTitle,
  onUpdateUrl,
  onUpdateCategory,
  onUpdateMeta
}) => {
  const [isOver, setIsOver] = React.useState(false);
  const { showToast } = useFeedback();
  const [selectMode, setSelectMode] = React.useState(false);
  const [selected, setSelected] = React.useState({});
  const selectedCount = Object.values(selected).filter(Boolean).length;
  const toggleSelect = (id) => setSelected((s) => ({ ...s, [id]: !s[id] }));
  const clearSelection = () => setSelected({});
  const [confirming, setConfirming] = React.useState(false);
  const [dragDisabled, setDragDisabled] = React.useState(false);
  const [ghostTab, setGhostTab] = React.useState(null);
  const [ghostType, setGhostType] = React.useState(null);
  const [ghostIndex, setGhostIndex] = React.useState(null);
  const prevGiRef = React.useRef(null);
  const ghostBeforeRef = React.useRef(null);
  const [draggingCardId, setDraggingCardId] = React.useState(null);
  const [hiddenCardId, setHiddenCardId] = React.useState(null);
  const zoneRef = React.useRef(null);
  const [lastDropTitle, setLastDropTitle] = React.useState(null);
  const computeGhostIndex = React.useCallback(
    (clientX, clientY, target) => {
      const zone = zoneRef.current;
      if (!zone) return null;
      let wrappers = Array.from(
        zone.querySelectorAll(".toby-card-flex")
      );
      wrappers = wrappers.filter(
        (el) => !el.querySelector('[data-testid="ghost-card"]') && el.getAttribute("data-hidden") !== "true"
      );
      if (!wrappers.length) return 0;
      if ((clientX == null || clientY == null) && target) {
        const wrap = target.closest(".toby-card-flex");
        if (wrap) {
          const idx = wrappers.indexOf(wrap);
          return Math.max(0, idx);
        }
      }
      if (clientX == null || clientY == null) return wrappers.length;
      const rows = [];
      const tol = 8;
      const sorted = wrappers.map((el, idx) => ({ idx, rect: el.getBoundingClientRect() })).sort((a, b) => a.rect.top - b.rect.top || a.rect.left - b.rect.left);
      for (const it of sorted) {
        const row2 = rows.find((r) => Math.abs(r.top - it.rect.top) <= tol);
        if (row2) {
          row2.items.push(it);
          row2.bottom = Math.max(row2.bottom, it.rect.bottom);
        } else {
          rows.push({
            start: it.idx,
            items: [it],
            top: it.rect.top,
            bottom: it.rect.bottom
          });
        }
      }
      for (const r of rows) r.items.sort((a, b) => a.rect.left - b.rect.left);
      let rowIndex = rows.findIndex(
        (r) => clientY >= r.top && clientY <= r.bottom
      );
      if (rowIndex === -1) {
        if (clientY < rows[0].top) rowIndex = 0;
        else rowIndex = rows.length - 1;
      }
      const row = rows[rowIndex];
      if (rowIndex === rows.length - 1) {
        const last = row.items[row.items.length - 1];
        const midYLast = (last.rect.top + last.rect.bottom) / 2;
        const midXLast = (last.rect.left + last.rect.right) / 2;
        const inLastHoriz = clientX >= last.rect.left && clientX <= last.rect.right;
        const inLastVert = clientY >= last.rect.top && clientY <= last.rect.bottom;
        if (inLastHoriz && inLastVert && clientY > midYLast)
          return wrappers.length;
        if (clientX > midXLast) return wrappers.length;
        if (clientY > (row.top + row.bottom) / 2) return wrappers.length;
      }
      for (let i = 0; i < row.items.length; i++) {
        const it = row.items[i];
        const midX = (it.rect.left + it.rect.right) / 2;
        if (clientX <= midX) {
          return it.idx;
        }
      }
      const lastInRow = row.items[row.items.length - 1].idx;
      return Math.min(wrappers.length, lastInRow + 1);
    },
    []
  );
  React.useEffect(() => {
    const onGhost = (e) => {
      var _a;
      const id = (_a = e == null ? void 0 : e.detail) != null ? _a : null;
      setHiddenCardId(id);
    };
    try {
      window.addEventListener("lt:ghost-active", onGhost);
    } catch {
    }
    return () => {
      try {
        window.removeEventListener("lt:ghost-active", onGhost);
      } catch {
      }
    };
  }, []);
  const handleDragOver = (e) => {
    var _a;
    e.preventDefault();
    try {
      e.dataTransfer.dropEffect = "move";
    } catch {
    }
    setIsOver(true);
    let tab = getDragTab() || null;
    if (!tab) {
      const raw = e.dataTransfer.getData("application/x-linktrove-tab");
      if (raw) {
        try {
          tab = JSON.parse(raw);
        } catch {
        }
      }
    }
    if (tab) {
      setGhostTab(tab);
      setGhostType("tab");
      const gi = computeGhostIndex(e.clientX, e.clientY, e.target);
      setGhostIndex(gi);
      try {
        const list = hiddenCardId ? items.filter((x) => x.id !== hiddenCardId) : items;
        ghostBeforeRef.current = gi == null ? null : gi >= list.length ? "__END__" : list[gi].id;
      } catch {
      }
      if (gi !== prevGiRef.current) {
        prevGiRef.current = gi;
        dbg("dnd", "dragOver(tab)", { gi, len: items.length });
      }
      return;
    }
    try {
      const fromId = e.dataTransfer.getData("application/x-linktrove-webpage");
      if (fromId) {
        setGhostType("card");
        let meta = null;
        try {
          meta = getDragWebpage();
        } catch {
        }
        if (!meta) {
          try {
            const raw = e.dataTransfer.getData("application/x-linktrove-webpage-meta");
            if (raw) meta = JSON.parse(raw);
          } catch {
          }
        }
        try {
          const id = (meta == null ? void 0 : meta.id) || fromId;
          setDraggingCardId(id);
          try {
            broadcastGhostActive(id);
          } catch {
          }
        } catch {
        }
        if (meta) {
          setGhostTab({
            id: -1,
            title: meta.title,
            url: meta.url,
            favIconUrl: meta.favicon,
            description: meta.description
          });
        } else {
          setGhostTab(null);
        }
        const gi = computeGhostIndex(e.clientX, e.clientY, e.target);
        setGhostIndex(gi);
        try {
          const list = hiddenCardId ? items.filter((x) => x.id !== hiddenCardId) : items;
          ghostBeforeRef.current = gi == null ? null : gi >= list.length ? "__END__" : list[gi].id;
        } catch {
        }
        if (gi !== prevGiRef.current) {
          prevGiRef.current = gi;
          dbg("dnd", "dragOver(card)", { gi, len: items.length, fromId });
        }
        return;
      }
    } catch {
    }
    try {
      const types = Array.from(((_a = e.dataTransfer) == null ? void 0 : _a.types) || []);
      if (types.includes("application/x-linktrove-webpage")) {
        setGhostType("card");
        const meta = (() => {
          try {
            return getDragWebpage();
          } catch {
            return null;
          }
        })();
        if (meta) {
          try {
            broadcastGhostActive(meta.id || null);
          } catch {
          }
          setGhostTab({ id: -1, title: meta.title, url: meta.url, favIconUrl: meta.favicon, description: meta.description });
        } else setGhostTab(null);
        const gi = computeGhostIndex(e.clientX, e.clientY, e.target);
        setGhostIndex(gi);
        try {
          const list = hiddenCardId ? items.filter((x) => x.id !== hiddenCardId) : items;
          ghostBeforeRef.current = gi == null ? null : gi >= list.length ? "__END__" : list[gi].id;
        } catch {
        }
        if (gi !== prevGiRef.current) {
          prevGiRef.current = gi;
          dbg("dnd", "dragOver(type-detect)", { gi, len: items.length, types });
        }
        return;
      }
      if (types.includes("application/x-linktrove-tab")) {
        setGhostType("tab");
        setGhostTab(null);
        setGhostIndex(computeGhostIndex(e.clientX, e.clientY, e.target));
        return;
      }
    } catch {
    }
  };
  const handleDragLeave = () => {
    setIsOver(false);
    setGhostTab(null);
    setGhostType(null);
    setGhostIndex(null);
    setDraggingCardId(null);
    try {
      broadcastGhostActive(null);
    } catch {
    }
  };
  React.useEffect(() => {
    const onEnd = () => {
      try {
        broadcastGhostActive(null);
      } catch {
      }
    };
    try {
      window.addEventListener("dragend", onEnd);
    } catch {
    }
    return () => {
      try {
        window.removeEventListener("dragend", onEnd);
      } catch {
      }
    };
  }, []);
  const handleDrop = async (e) => {
    e.preventDefault();
    setIsOver(false);
    try {
      const fromId = e.dataTransfer.getData("application/x-linktrove-webpage");
      if (fromId) {
        let beforeId = null;
        try {
          const zone = zoneRef.current;
          const ghostCard = zone == null ? void 0 : zone.querySelector('[data-testid="ghost-card"]');
          const ghostWrap = ghostCard ? ghostCard.closest(".toby-card-flex") : null;
          let next = ghostWrap == null ? void 0 : ghostWrap.nextElementSibling;
          while (next && (!next.getAttribute("data-card-id") || next.getAttribute("data-hidden") === "true" || next.getAttribute("data-card-id") === fromId)) {
            next = next.nextElementSibling;
          }
          beforeId = (next == null ? void 0 : next.getAttribute("data-card-id")) || "__END__";
        } catch {
        }
        if (!beforeId) {
          beforeId = ghostBeforeRef.current;
        }
        if (!beforeId) {
          let idx = ghostIndex;
          if (idx == null)
            idx = computeGhostIndex(e.clientX, e.clientY, e.target);
          const list = hiddenCardId ? items.filter((x) => x.id !== hiddenCardId) : items;
          if (idx == null) idx = list.length;
          beforeId = idx >= list.length ? "__END__" : list[idx].id;
        }
        dbg("dnd", "drop(card→grid)", { fromId, idx: ghostIndex, beforeId, list: (hiddenCardId ? items.filter((x) => x.id !== hiddenCardId) : items).map((x) => x.id) });
        onDropExistingCard == null ? void 0 : onDropExistingCard(fromId, beforeId);
        setGhostTab(null);
        setGhostType(null);
        setGhostIndex(null);
        setDraggingCardId(null);
        try {
          broadcastGhostActive(null);
        } catch {
        }
        return;
      }
      let raw = "";
      try {
        raw = e.dataTransfer.getData("application/x-linktrove-tab");
      } catch {
      }
      let tab = null;
      if (raw) {
        tab = JSON.parse(raw);
      }
      if (!tab) {
        try {
          tab = getDragTab() || null;
        } catch {
          tab = null;
        }
      }
      if (tab) {
        let beforeId = null;
        try {
          const zone = zoneRef.current;
          const ghostCard = zone == null ? void 0 : zone.querySelector('[data-testid="ghost-card"]');
          const ghostWrap = ghostCard ? ghostCard.closest(".toby-card-flex") : null;
          let next = ghostWrap == null ? void 0 : ghostWrap.nextElementSibling;
          while (next && (!next.getAttribute("data-card-id") || next.getAttribute("data-hidden") === "true")) {
            next = next.nextElementSibling;
          }
          beforeId = (next == null ? void 0 : next.getAttribute("data-card-id")) || "__END__";
        } catch {
        }
        if (!beforeId) beforeId = ghostBeforeRef.current;
        if (!beforeId) {
          let idx = ghostIndex;
          if (idx == null)
            idx = computeGhostIndex(e.clientX, e.clientY, e.target);
          const list = hiddenCardId ? items.filter((x) => x.id !== hiddenCardId) : items;
          if (idx == null) idx = list.length;
          beforeId = idx >= list.length ? "__END__" : list[idx].id;
        }
        dbg("dnd", "drop(tab→grid)", { idx: ghostIndex, beforeId, list: (hiddenCardId ? items.filter((x) => x.id !== hiddenCardId) : items).map((x) => x.id) });
        let ret;
        if (((items == null ? void 0 : items.length) || 0) > 0) ret = onDropTab == null ? void 0 : onDropTab(tab, beforeId);
        else ret = onDropTab == null ? void 0 : onDropTab(tab);
        try {
          if (ret && typeof ret.then === "function") await ret;
        } catch {
        }
        try {
          setLastDropTitle(String(tab.title || tab.url || ""));
        } catch {
        }
        setGhostTab(null);
        setGhostType(null);
        setGhostIndex(null);
        setDraggingCardId(null);
        try {
          broadcastGhostActive(null);
        } catch {
        }
        return;
      }
    } catch {
      showToast("Failed to add tab", "error");
    }
    setGhostTab(null);
    setGhostType(null);
    setGhostIndex(null);
    setDraggingCardId(null);
    try {
      broadcastGhostActive(null);
    } catch {
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex items-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          className: "text-sm px-2 py-1 rounded border border-slate-600 hover:bg-slate-800",
          onClick: () => setSelectMode((v) => !v),
          children: selectMode ? "Cancel" : "Select"
        }
      ),
      selectMode && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm opacity-80", children: [
          selectedCount,
          " selected"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            className: "text-sm px-2 py-1 rounded border border-red-600 text-red-300 hover:bg-red-950/30 disabled:opacity-50",
            onClick: () => {
              var _a, _b;
              (_b = (_a = document.activeElement) == null ? void 0 : _a.blur) == null ? void 0 : _b.call(_a);
              setConfirming(true);
            },
            disabled: selectedCount === 0,
            children: "Delete Selected"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        "aria-label": "Drop Zone",
        "data-testid": "drop-zone",
        ref: zoneRef,
        onDragOver: handleDragOver,
        onDragEnter: handleDragOver,
        onDragLeave: handleDragLeave,
        onDrop: handleDrop,
        className: `min-h-[200px] rounded border p-4 transition-all ${isOver ? "border-emerald-500 ring-2 ring-emerald-500 bg-emerald-950/20" : "border-slate-700"}`,
        children: [
          lastDropTitle ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", "aria-hidden": "true", children: lastDropTitle }) : null,
          items.length === 0 && !((ghostTab != null || ghostType != null) && ghostIndex != null) ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "opacity-70", children: "Drag tabs here to save" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: `toby-cards-flex ${density === "compact" ? "density-compact" : density === "roomy" ? "density-roomy" : ""} ${collapsed ? "cards-collapsed" : ""}`,
              children: (() => {
                const ghostActive = isOver || ghostTab != null || ghostType != null || ghostIndex != null;
                const viewItems = ghostActive && draggingCardId ? items.filter((x) => x.id !== draggingCardId) : items;
                const renderList = [];
                let gIdx = -1;
                if (ghostActive) {
                  const gBefore = ghostBeforeRef.current;
                  if (gBefore === "__END__") gIdx = viewItems.length;
                  else if (gBefore) gIdx = viewItems.findIndex((it) => it.id === gBefore);
                  if (gIdx < 0) {
                    const idx = ghostIndex == null ? 0 : ghostIndex;
                    gIdx = Math.max(0, Math.min(viewItems.length, idx));
                  }
                }
                for (let i = 0; i < viewItems.length; i++) {
                  if (i === gIdx) renderList.push({ type: "ghost" });
                  renderList.push({ type: "card", item: viewItems[i] });
                }
                if (gIdx === viewItems.length) renderList.push({ type: "ghost" });
                return renderList;
              })().map((node, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                "div",
                {
                  className: "toby-card-flex relative",
                  id: node.type === "card" ? `card-${node.item.id}` : void 0,
                  "data-card-id": node.type === "card" ? node.item.id : void 0,
                  "data-hidden": node.type === "card" && hiddenCardId === node.item.id ? "true" : void 0,
                  "data-testid": node.type === "card" ? `card-wrapper-${node.item.id}` : void 0,
                  style: node.type === "card" && hiddenCardId === node.item.id ? { display: "none" } : void 0,
                  draggable: node.type === "card" && !dragDisabled,
                  onDragStart: node.type === "card" ? (e) => {
                    const it = node.item;
                    e.dataTransfer.setData(
                      "application/x-linktrove-webpage",
                      it.id
                    );
                    try {
                      e.dataTransfer.setData(
                        "application/x-linktrove-webpage-meta",
                        JSON.stringify({ id: it.id, title: it.title, url: it.url, favicon: it.favicon, description: it.description })
                      );
                    } catch {
                    }
                    e.dataTransfer.effectAllowed = "move";
                    try {
                      setDragWebpage({ id: it.id, title: it.title, url: it.url, favicon: it.favicon, description: it.description });
                    } catch {
                    }
                    e.currentTarget.setAttribute(
                      "data-dragging",
                      "true"
                    );
                  } : void 0,
                  onDragEnd: node.type === "card" ? (e) => {
                    e.currentTarget.removeAttribute(
                      "data-dragging"
                    );
                    setDraggingCardId(null);
                    try {
                      setDragWebpage(null);
                    } catch {
                    }
                  } : void 0,
                  onDrop: node.type === "card" ? (e) => {
                    e.preventDefault();
                    const it = node.item;
                    const rawTab = e.dataTransfer.getData(
                      "application/x-linktrove-tab"
                    );
                    if (rawTab) {
                      try {
                        const tab = JSON.parse(rawTab);
                        const rect = e.currentTarget.getBoundingClientRect();
                        const midY = (rect.top + rect.bottom) / 2;
                        const list = draggingCardId ? items.filter((x) => x.id !== draggingCardId) : items;
                        const isLast = list.length > 0 && it.id === list[list.length - 1].id;
                        const atEnd = isLast && e.clientY > midY;
                        const beforeId = atEnd ? "__END__" : it.id;
                        onDropTab == null ? void 0 : onDropTab(tab, beforeId);
                        return;
                      } catch {
                      }
                    }
                    const fromId = e.dataTransfer.getData(
                      "application/x-linktrove-webpage"
                    );
                    if (fromId && fromId !== it.id) {
                      if (onDropExistingCard) onDropExistingCard(fromId, it.id);
                      else onReorder == null ? void 0 : onReorder(fromId, it.id);
                    }
                  } : void 0,
                  children: node.type === "ghost" ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                    TobyLikeCard,
                    {
                      title: (ghostTab == null ? void 0 : ghostTab.title) || (ghostTab == null ? void 0 : ghostTab.url) || (ghostType === "card" ? "Moving" : "New"),
                      description: (ghostTab == null ? void 0 : ghostTab.description) || "",
                      faviconText: ((ghostTab == null ? void 0 : ghostTab.url) || "").replace(/^https?:\/\//, "").replace(/^www\./, "").slice(0, 2).toUpperCase() || "WW",
                      faviconUrl: ghostTab == null ? void 0 : ghostTab.favIconUrl,
                      ghost: true
                    }
                  ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
                    TobyLikeCard,
                    {
                      title: node.item.title,
                      description: node.item.description,
                      faviconText: (node.item.url || "").replace(/^https?:\/\//, "").replace(/^www\./, "").slice(0, 2).toUpperCase() || "WW",
                      faviconUrl: node.item.favicon,
                      url: node.item.url,
                      categoryId: node.item.category,
                      meta: node.item.meta || {},
                      selectMode,
                      selected: !!selected[node.item.id],
                      onToggleSelect: () => toggleSelect(node.item.id),
                      onOpen: () => {
                        try {
                          window.open(node.item.url, "_blank");
                        } catch {
                        }
                      },
                      onDelete: () => onDeleteOne == null ? void 0 : onDeleteOne(node.item.id),
                      onUpdateTitle: (v) => onUpdateTitle == null ? void 0 : onUpdateTitle(node.item.id, v),
                      onUpdateUrl: (v) => onUpdateUrl == null ? void 0 : onUpdateUrl(node.item.id, v),
                      onUpdateDescription: (v) => onEditDescription == null ? void 0 : onEditDescription(node.item.id, v),
                      onUpdateMeta: (m) => onUpdateMeta == null ? void 0 : onUpdateMeta(node.item.id, m),
                      onMoveToCategory: (cid) => onUpdateCategory == null ? void 0 : onUpdateCategory(node.item.id, cid),
                      onModalOpenChange: (open) => setDragDisabled(open),
                      onSave: (patch) => {
                        const it = node.item;
                        if (onSave) onSave(it.id, patch);
                        else {
                          if (patch.title) onUpdateTitle == null ? void 0 : onUpdateTitle(it.id, patch.title);
                          if (patch.url) onUpdateUrl == null ? void 0 : onUpdateUrl(it.id, patch.url);
                          if (patch.description !== void 0)
                            onEditDescription == null ? void 0 : onEditDescription(it.id, patch.description);
                          if (patch.meta) onUpdateMeta == null ? void 0 : onUpdateMeta(it.id, patch.meta);
                        }
                      }
                    }
                  )
                },
                node.type === "card" ? node.item.id : `ghost-${idx}`
              ))
            }
          )
        ]
      }
    ),
    confirming && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50",
        onClick: () => setConfirming(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--bg)] p-4",
            role: "dialog",
            "aria-label": "Confirm Delete Selected",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3 font-medium", children: "Confirm Delete Selected" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 justify-end", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => setConfirming(false),
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-red-600 text-red-300 hover:bg-red-950/30",
                    onClick: () => {
                      const ids = Object.entries(selected).filter(([, v]) => v).map(([key]) => key);
                      setConfirming(false);
                      clearSelection();
                      onDeleteMany == null ? void 0 : onDeleteMany(ids);
                    },
                    children: "Delete"
                  }
                )
              ] })
            ]
          }
        )
      }
    )
  ] });
};
function generateBooklistHTML(group, items, templates, customTitle, customDescription) {
  const now = /* @__PURE__ */ new Date();
  const formattedDate = now.toLocaleDateString("zh-TW", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
  const createBookCard = (item) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
    const customFields = [];
    const metadata = [];
    if (templates.length > 0 && item.templateId) {
      const template = templates.find((t) => t.id === item.templateId);
      if (template && template.fields) {
        for (const field of template.fields) {
          const value = (_a = item.templateData) == null ? void 0 : _a[field.key];
          if (field.type === "rating") {
            const rating = parseInt(value) || 0;
            const stars = rating > 0 ? "★".repeat(rating) + "☆".repeat(5 - rating) : "☆☆☆☆☆";
            customFields.push(`<div class="custom-field"><span class="field-label">${field.label || field.key}</span> <span class="rating">${stars}</span></div>`);
          } else if (field.type === "tags") {
            if (value && typeof value === "string") {
              const tags = value.split(",").map((tag) => tag.trim()).filter(Boolean);
              if (tags.length > 0) {
                customFields.push(`<div class="custom-field"><span class="field-label">${field.label || field.key}</span> <div class="tags">${tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}</div></div>`);
              } else {
                customFields.push(`<div class="custom-field"><span class="field-label">${field.label || field.key}</span> <span class="field-value empty">未設定</span></div>`);
              }
            } else {
              customFields.push(`<div class="custom-field"><span class="field-label">${field.label || field.key}</span> <span class="field-value empty">未設定</span></div>`);
            }
          } else {
            const displayValue = value && typeof value === "string" && value.trim() ? value.trim() : "未設定";
            const className = displayValue === "未設定" ? "field-value empty" : "field-value";
            customFields.push(`<div class="custom-field"><span class="field-label">${field.label || field.key}</span> <span class="${className}">${displayValue}</span></div>`);
          }
        }
      }
    }
    if ((_b = item.meta) == null ? void 0 : _b.bookTitle) metadata.push(`<div class="metadata-item"><span class="meta-label">書名</span> ${item.meta.bookTitle}</div>`);
    if ((_c = item.meta) == null ? void 0 : _c.author) metadata.push(`<div class="metadata-item"><span class="meta-label">作者</span> ${item.meta.author}</div>`);
    if ((_d = item.meta) == null ? void 0 : _d.genre) metadata.push(`<div class="metadata-item"><span class="meta-label">類型</span> ${item.meta.genre}</div>`);
    if ((_e = item.meta) == null ? void 0 : _e.rating) {
      const rating = parseInt(item.meta.rating) || 0;
      const stars = rating > 0 ? "★".repeat(rating) + "☆".repeat(5 - rating) : "未評分";
      metadata.push(`<div class="metadata-item"><span class="meta-label">評分</span> <span class="rating">${stars}</span></div>`);
    }
    if ((_f = item.meta) == null ? void 0 : _f.siteName) metadata.push(`<div class="metadata-item"><span class="meta-label">來源</span> ${item.meta.siteName}</div>`);
    if ((_g = item.meta) == null ? void 0 : _g.latestChapter) metadata.push(`<div class="metadata-item"><span class="meta-label">最新章節</span> ${item.meta.latestChapter}</div>`);
    if ((_h = item.meta) == null ? void 0 : _h.lastUpdate) {
      const date = new Date(item.meta.lastUpdate).toLocaleDateString("zh-TW");
      metadata.push(`<div class="metadata-item"><span class="meta-label">最後更新</span> ${date}</div>`);
    }
    if (item.updatedAt) {
      const date = new Date(item.updatedAt).toLocaleDateString("zh-TW");
      metadata.push(`<div class="metadata-item"><span class="meta-label">收藏時間</span> ${date}</div>`);
    }
    const displayUrl = ((_i = item.url) == null ? void 0 : _i.length) > 50 ? item.url.substring(0, 47) + "..." : item.url;
    return `
      <div class="book-card">
        <div class="book-left">
          <div class="book-cover">
            ${((_j = item.meta) == null ? void 0 : _j.coverImage) ? `<img src="${item.meta.coverImage}" alt="Cover" class="cover-image" onerror="this.src='${item.favicon || ""}'; this.className='favicon-fallback'">` : item.favicon ? `<img src="${item.favicon}" alt="Icon" class="favicon-fallback">` : '<div class="default-cover">🔗</div>'}
          </div>
          <div class="book-basic-info">
            <h3 class="book-title">
              <a href="${item.url}" target="_blank" rel="noopener">${item.title || "Untitled"}</a>
            </h3>
            ${metadata.length > 0 ? `<div class="metadata">${metadata.join("")}</div>` : ""}
            ${customFields.length > 0 ? `<div class="custom-fields">${customFields.join("")}</div>` : ""}
            <div class="book-url">
              <a href="${item.url}" target="_blank" rel="noopener" title="${item.url}">${displayUrl}</a>
            </div>
          </div>
        </div>
        <div class="book-right">
          <div class="description-section">
            <h4 class="description-title">內容描述</h4>
            <p class="book-description">
              ${item.description || "暫無描述..."}
            </p>
          </div>
        </div>
      </div>
    `;
  };
  return `<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${customTitle || group.name} - 分享</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Noto Sans CJK TC', 'Microsoft JhengHei', sans-serif;
      line-height: 1.6;
      color: #333;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 16px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    .header {
      background: linear-gradient(135deg, #2d3748 0%, #1a202c 100%);
      color: white;
      padding: 40px;
      text-align: center;
    }

    .header h1 {
      font-size: 2.5rem;
      margin-bottom: 10px;
      font-weight: 700;
    }

    .header .subtitle {
      font-size: 1.1rem;
      opacity: 0.9;
      margin-bottom: 10px;
    }

    .header .meta {
      font-size: 0.9rem;
      opacity: 0.7;
    }

    .content {
      padding: 40px;
    }

    .books-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 20px;
      margin-top: 30px;
    }

    .book-card {
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      background: white;
      transition: all 0.3s ease;
      display: flex;
      min-height: 180px;
      overflow: hidden;
      box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }

    .book-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 12px 40px rgba(0,0,0,0.15);
      border-color: #667eea;
    }

    .book-left {
      flex: 0 0 40%;
      padding: 24px;
      display: flex;
      gap: 16px;
      background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
      border-right: 2px solid rgba(102, 126, 234, 0.1);
    }

    .book-right {
      flex: 1;
      padding: 24px;
      display: flex;
      flex-direction: column;
      background: white;
    }

    .book-cover {
      flex-shrink: 0;
      width: 80px;
      height: 120px;
      border-radius: 12px;
      overflow: hidden;
      background: #f1f5f9;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 6px 20px rgba(0,0,0,0.15);
    }

    .book-cover img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .book-cover .cover-image {
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .book-cover .favicon-fallback {
      object-fit: contain;
      padding: 12px;
      background: #f8fafc;
      border-radius: 4px;
    }

    .default-cover {
      font-size: 24px;
      color: #64748b;
    }

    .book-basic-info {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .description-section {
      height: 100%;
      display: flex;
      flex-direction: column;
    }

    .description-title {
      font-size: 1rem;
      font-weight: 600;
      color: #667eea;
      margin: 0 0 12px 0;
      padding-bottom: 8px;
      border-bottom: 2px solid #e2e8f0;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .description-title::before {
      content: "📖";
      font-size: 1.1rem;
    }

    .book-title {
      font-size: 1.1rem;
      font-weight: 600;
      margin-bottom: 8px;
      line-height: 1.4;
    }

    .book-title a {
      color: #2d3748;
      text-decoration: none;
      border-bottom: 2px solid transparent;
      transition: border-color 0.2s ease;
    }

    .book-title a:hover {
      border-bottom-color: #667eea;
    }

    .book-description {
      font-size: 1rem;
      color: #2d3748;
      line-height: 1.6;
      flex: 1;
      overflow-y: auto;
      padding-right: 8px;
      text-align: justify;
      font-weight: 400;
      margin: 0;
    }

    .metadata {
      margin: 12px 0;
    }

    .metadata-item {
      font-size: 0.85rem;
      margin-bottom: 4px;
      color: #4a5568;
    }

    .meta-label {
      font-weight: 600;
      color: #2d3748;
      margin-right: 4px;
    }

    .custom-fields {
      margin: 12px 0;
    }

    .custom-field {
      font-size: 0.85rem;
      margin-bottom: 6px;
      color: #2d3748;
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
    }

    .field-label {
      font-weight: 600;
      color: #1a202c;
      min-width: 60px;
    }

    .field-value {
      color: #4a5568;
    }

    .field-value.empty {
      color: #9ca3af;
      font-style: italic;
      opacity: 0.7;
    }

    .rating {
      color: #f6ad55;
      font-size: 0.9rem;
    }

    .tags {
      display: flex;
      gap: 4px;
      flex-wrap: wrap;
    }

    .tag {
      background: #e2e8f0;
      color: #2d3748;
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 500;
    }

    .book-url {
      margin-top: 12px;
      font-size: 0.8rem;
    }

    .book-url a {
      color: #667eea;
      text-decoration: none;
      word-break: break-all;
      opacity: 0.8;
    }

    .book-url a:hover {
      opacity: 1;
      text-decoration: underline;
    }

    .footer {
      background: #f7fafc;
      padding: 30px 40px;
      text-align: center;
      color: #718096;
      font-size: 0.9rem;
      border-top: 1px solid #e2e8f0;
    }

    .footer a {
      color: #667eea;
      text-decoration: none;
    }

    .footer a:hover {
      text-decoration: underline;
    }

    .stats {
      display: inline-flex;
      gap: 20px;
      margin-top: 15px;
      font-size: 0.9rem;
    }

    .stat {
      background: rgba(255,255,255,0.1);
      padding: 8px 16px;
      border-radius: 20px;
    }

    /* 分組內卡片的特殊佈局 */
    .group-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 16px;
    }

    .group-grid .book-card {
      min-height: 140px;
    }

    .group-grid .book-left {
      flex: 0 0 35%;
      padding: 16px;
    }

    .group-grid .book-right {
      padding: 16px;
    }

    .group-grid .book-cover {
      width: 60px;
      height: 80px;
    }

    .group-grid .description-title {
      font-size: 0.9rem;
      margin-bottom: 8px;
    }

    .group-grid .book-description {
      font-size: 0.9rem;
    }

    @media (max-width: 768px) {
      .header {
        padding: 30px 20px;
      }

      .header h1 {
        font-size: 2rem;
      }

      .content {
        padding: 30px 20px;
      }

      .book-card {
        flex-direction: column;
        min-height: auto;
      }

      .book-left {
        flex: none;
        padding: 16px;
        border-right: none;
        border-bottom: 2px solid rgba(102, 126, 234, 0.1);
      }

      .book-right {
        padding: 16px;
      }

      .book-cover {
        width: 60px;
        height: 80px;
      }

      .group-grid .book-card {
        min-height: auto;
      }
    }

    /* 分組顯示樣式 */
    .grouped-container {
      display: block;
    }

    .group-section {
      margin-bottom: 40px;
      background: rgba(102, 126, 234, 0.02);
      border-radius: 16px;
      padding: 24px;
      border: 1px solid rgba(102, 126, 234, 0.1);
    }

    .group-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 20px;
      padding-bottom: 12px;
      border-bottom: 2px solid #e2e8f0;
    }

    .group-title {
      font-size: 1.4rem;
      font-weight: 600;
      color: #2d3748;
      margin: 0;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .group-badge {
      background: #667eea;
      color: white;
      padding: 4px 12px;
      border-radius: 16px;
      font-size: 0.75rem;
      font-weight: 500;
    }

    .empty-group {
      text-align: center;
      padding: 40px 20px;
      color: #9ca3af;
      font-style: italic;
    }

    /* 評分分組特殊樣式 */
    .rating-5 .group-title { color: #ffd700; }
    .rating-4 .group-title { color: #ffb347; }
    .rating-3 .group-title { color: #87ceeb; }
    .rating-2 .group-title { color: #dda0dd; }
    .rating-1 .group-title { color: #f0a0a0; }
    .rating-0 .group-title { color: #9ca3af; }

    @media (max-width: 768px) {
      .group-section {
        padding: 16px;
        margin-bottom: 24px;
      }

      .group-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <header class="header">
      <h1>${customTitle || group.name}</h1>
      <div class="subtitle">${customDescription || "精選收藏分享"}</div>
      <div class="stats">
        <div class="stat">${items.length} 個項目</div>
        <div class="stat">由 LinkTrove 生成</div>
      </div>
      <div class="meta">生成時間：${formattedDate}</div>
      <div class="group-controls" style="margin-top: 15px;">
        <label for="groupSelect" style="color: white; margin-right: 10px;">分組方式：</label>
        <select id="groupSelect" onchange="groupItems(this.value)" style="background: #2d3748; color: white; border: 1px solid #4a5568; padding: 8px 12px; border-radius: 6px; font-size: 14px; margin-right: 15px;">
          <option value="">不分組</option>
          <option value="genre">按類型分組</option>
          <option value="rating">按評分分組</option>
        </select>
        <button onclick="downloadJSON()" style="background: #4299e1; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 14px; transition: background 0.2s;" onmouseover="this.style.background='#3182ce'" onmouseout="this.style.background='#4299e1'">
          下載 JSON
        </button>
      </div>
    </header>

    <main class="content">
      ${items.length > 0 ? `
        <div id="defaultView" class="books-grid">
          ${items.map(createBookCard).join("")}
        </div>
        <div id="groupedView" class="grouped-container" style="display: none;">
          <!-- 分組內容將由JavaScript動態生成 -->
        </div>
      ` : `
        <div style="text-align: center; padding: 60px 20px; color: #718096;">
          <h3>此群組目前沒有內容</h3>
        </div>
      `}
    </main>

    <footer class="footer">
      <div>此分享由 <a href="https://github.com/anthropics/claude-code" target="_blank">LinkTrove</a> 生成</div>
      <div style="margin-top: 10px; font-size: 0.8rem;">
        一個用於管理和分享書籤的瀏覽器擴充功能
      </div>
    </footer>
  </div>

  <script>
    // JSON 資料
    const exportData = ${JSON.stringify({
    schemaVersion: 1,
    metadata: {
      title: customTitle || group.name,
      description: customDescription || "",
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      itemCount: items.length
    },
    group: {
      id: group.id,
      name: group.name,
      categoryId: group.categoryId
    },
    templates: templates.filter(
      (t) => items.some((item) => item.templateId === t.id)
    ),
    items: items.map((item) => ({
      id: item.id,
      title: item.title,
      url: item.url,
      description: item.description,
      favicon: item.favicon,
      templateId: item.templateId,
      templateData: item.templateData,
      meta: item.meta,
      createdAt: item.createdAt,
      updatedAt: item.updatedAt
    }))
  }, null, 2)};

    function downloadJSON() {
      const jsonContent = JSON.stringify(exportData, null, 2);
      const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = \`\${exportData.metadata.title.replace(/[^\\w\\s-]/g, '')}-bookmarks.json\`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }

    // 分組功能
    function groupItems(groupBy) {
      const defaultView = document.getElementById('defaultView');
      const groupedView = document.getElementById('groupedView');

      if (!groupBy) {
        // 顯示原始視圖
        defaultView.style.display = 'grid';
        groupedView.style.display = 'none';
        return;
      }

      // 切換到分組視圖
      defaultView.style.display = 'none';
      groupedView.style.display = 'block';

      // 收集所有卡片
      const cards = Array.from(defaultView.children);

      // 根據分組方式整理數據
      const groups = {};

      cards.forEach(card => {
        let groupKey = '未分類';

        switch (groupBy) {
          case 'genre': {
            const metaItems = card.querySelectorAll('.metadata-item');
            for (const item of metaItems) {
              if (item.textContent.includes('類型')) {
                groupKey = item.textContent.replace('類型', '').trim() || '未知類型';
                break;
              }
            }
            break;
          }

          case 'rating': {
            const ratingElement = card.querySelector('.rating');
            if (ratingElement) {
              const stars = (ratingElement.textContent.match(/★/g) || []).length;
              if (stars === 0) {
                groupKey = '未評分';
              } else {
                groupKey = \`\${stars}星評分\`;
              }
            } else {
              groupKey = '未評分';
            }
            break;
          }
        }

        if (!groups[groupKey]) {
          groups[groupKey] = [];
        }
        groups[groupKey].push(card.cloneNode(true));
      });

      // 生成分組HTML
      let groupedHTML = '';
      const sortedGroupKeys = Object.keys(groups).sort((a, b) => {
        if (groupBy === 'rating') {
          // 評分按星級排序（5星到未評分）
          const getStars = (key) => {
            if (key === '未評分') return -1;
            const match = key.match(/(\\d+)星/);
            return match ? parseInt(match[1]) : 0;
          };
          return getStars(b) - getStars(a);
        }
        return a.localeCompare(b, 'zh-TW');
      });

      sortedGroupKeys.forEach(groupKey => {
        const items = groups[groupKey];
        const ratingClass = groupBy === 'rating' && groupKey !== '未評分'
          ? \`rating-\${groupKey.match(/(\\d+)星/) ? groupKey.match(/(\\d+)星/)[1] : '0'}\`
          : '';

        groupedHTML += \`
          <div class="group-section \${ratingClass}">
            <div class="group-header">
              <h2 class="group-title">
                \${getGroupIcon(groupBy, groupKey)} \${groupKey}
              </h2>
              <span class="group-badge">\${items.length} 項目</span>
            </div>
            <div class="group-grid">
              \${items.map(item => item.outerHTML).join('')}
            </div>
          </div>
        \`;
      });

      groupedView.innerHTML = groupedHTML;
    }

    function getGroupIcon(groupBy, groupKey) {
      switch (groupBy) {
        case 'genre':
          return '📚';
        case 'rating':
          if (groupKey === '未評分') return '⭕';
          const stars = groupKey.match(/(\\d+)星/);
          return stars ? '⭐'.repeat(parseInt(stars[1])) : '📊';
        default:
          return '📋';
      }
    }
  <\/script>
</body>
</html>`;
}
const GroupsView = ({ categoryId }) => {
  const { showToast } = useFeedback();
  const { items, actions } = useWebpages();
  const [groups, setGroups] = React.useState([]);
  const [collapsed, setCollapsed] = React.useState({});
  const [renaming, setRenaming] = React.useState(null);
  const [renameText, setRenameText] = React.useState("");
  const [confirmDeleteGroup, setConfirmDeleteGroup] = React.useState(null);
  const [menuFor, setMenuFor] = React.useState(null);
  const [tobyOpenFor, setTobyOpenFor] = React.useState(null);
  const [tobyFile, setTobyFile] = React.useState(null);
  const [tobyPreview, setTobyPreview] = React.useState(null);
  const [tobyProgress, setTobyProgress] = React.useState(null);
  const tobyAbortRef = React.useRef(null);
  const [shareDialogOpen, setShareDialogOpen] = React.useState(false);
  const [shareGroup, setShareGroup] = React.useState(null);
  const [shareTitle, setShareTitle] = React.useState("");
  const [shareDescription, setShareDescription] = React.useState("");
  const [showTokenDialog, setShowTokenDialog] = React.useState(false);
  const [githubToken, setGithubToken] = React.useState("");
  const [shareResultUrl, setShareResultUrl] = React.useState(null);
  const svc = React.useMemo(() => {
    return createStorageService();
  }, []);
  const load = React.useCallback(async () => {
    var _a;
    try {
      if (!svc) return;
      const list = await ((_a = svc.listSubcategories) == null ? void 0 : _a.call(svc, categoryId)) || [];
      const m = /* @__PURE__ */ new Map();
      for (const g of list) if (!m.has(g.id)) m.set(g.id, g);
      setGroups(Array.from(m.values()));
    } catch {
    }
  }, [svc, categoryId]);
  const persistCollapsed = React.useCallback(async (next) => {
    var _a, _b, _c;
    setCollapsed(next);
    try {
      const key = `ui.groupsCollapsed.${categoryId}`;
      (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { [key]: next });
    } catch {
    }
  }, [categoryId]);
  React.useEffect(() => {
    const migrateToken = async () => {
      try {
        const oldToken = localStorage.getItem("linktrove_github_token");
        if (oldToken) {
          await new Promise((resolve, reject) => {
            var _a, _b, _c;
            (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { "github.token": oldToken }, () => {
              var _a2;
              if ((_a2 = chrome.runtime) == null ? void 0 : _a2.lastError) {
                reject(chrome.runtime.lastError);
              } else {
                resolve();
              }
            });
          });
          localStorage.removeItem("linktrove_github_token");
          console.log("[Security] Migrated GitHub token from localStorage to chrome.storage.local");
        }
      } catch (error) {
        console.warn("[Security] Failed to migrate GitHub token:", error);
      }
    };
    migrateToken();
  }, []);
  React.useEffect(() => {
    load();
    const onChanged = () => {
      load();
    };
    try {
      window.addEventListener("groups:changed", onChanged);
    } catch {
    }
    const onCollapseAll = (ev) => {
      try {
        const det = (ev == null ? void 0 : ev.detail) || {};
        if (!det || det.categoryId !== categoryId) return;
        const doCollapse = !!det.collapsed;
        const next = {};
        for (const g of groups) next[g.id] = doCollapse;
        void persistCollapsed(next);
      } catch {
      }
    };
    try {
      window.addEventListener("groups:collapse-all", onCollapseAll);
    } catch {
    }
    return () => {
      try {
        window.removeEventListener("groups:changed", onChanged);
      } catch {
      }
      try {
        window.removeEventListener("groups:collapse-all", onCollapseAll);
      } catch {
      }
    };
  }, [load, groups, categoryId, persistCollapsed]);
  React.useEffect(() => {
    (async () => {
      try {
        const key = `ui.groupsCollapsed.${categoryId}`;
        const got = await new Promise((resolve) => {
          var _a, _b, _c;
          try {
            (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { [key]: {} }, resolve);
          } catch {
            resolve({});
          }
        });
        const map = (got == null ? void 0 : got[key]) || {};
        setCollapsed(map);
      } catch {
      }
    })();
  }, [categoryId]);
  const rename = async (id, name) => {
    var _a;
    try {
      await ((_a = svc.renameSubcategory) == null ? void 0 : _a.call(svc, id, name.trim() || "group"));
      await load();
      showToast("已重新命名", "success");
    } catch {
      showToast("重新命名失敗", "error");
    }
  };
  const remove = async (id) => {
    var _a, _b;
    try {
      const latest = await ((_a = svc.listSubcategories) == null ? void 0 : _a.call(svc, categoryId)) || [];
      const others = latest.filter((g) => g.id !== id);
      if (others.length === 0) {
        showToast("刪除失敗：至少需要保留一個 group", "error");
        return;
      }
      if (svc.deleteSubcategoryAndPages) {
        await svc.deleteSubcategoryAndPages(id);
      } else {
        try {
          const ids = items.filter((it) => it.subcategoryId === id).map((it) => it.id);
          if (ids.length) await actions.deleteMany(ids);
        } catch {
        }
        try {
          await ((_b = svc.deleteSubcategory) == null ? void 0 : _b.call(svc, id, "__NO_REASSIGN__"));
        } catch {
        }
      }
      const { [id]: _omit, ...rest } = collapsed;
      await persistCollapsed(rest);
      await load();
      try {
        window.dispatchEvent(new CustomEvent("groups:changed"));
      } catch {
      }
      showToast("已刪除 group 與其書籤", "success");
    } catch {
      showToast("刪除失敗", "error");
    }
  };
  const move = async (id, dir) => {
    var _a;
    const idx = groups.findIndex((g) => g.id === id);
    if (idx === -1) return;
    const j = idx + dir;
    if (j < 0 || j >= groups.length) return;
    const next = [...groups];
    const [it] = next.splice(idx, 1);
    next.splice(j, 0, it);
    setGroups(next);
    try {
      await ((_a = svc.reorderSubcategories) == null ? void 0 : _a.call(svc, categoryId, next.map((x) => x.id)));
      showToast("已重新排序", "success");
    } catch {
    }
  };
  const openShareDialog = async (group) => {
    try {
      const groupItems = items.filter((it) => it.category === categoryId && it.subcategoryId === group.id);
      if (groupItems.length === 0) {
        showToast("此群組沒有內容可分享", "info");
        return;
      }
      setShareGroup(group);
      setShareTitle(group.name);
      setShareDescription(`精選收藏 - ${group.name} (${groupItems.length} 項目)`);
      setShareDialogOpen(true);
    } catch (error) {
      console.error("Open share dialog error:", error);
      showToast("開啟分享對話框失敗", "error");
    }
  };
  const publishToGist = async () => {
    var _a;
    if (!shareGroup) return;
    try {
      const groupItems = items.filter((it) => it.category === categoryId && it.subcategoryId === shareGroup.id);
      const { createStorageService: createStorageService2 } = await __vitePreload(async () => {
        const { createStorageService: createStorageService22 } = await import("./webpageService-CB3FiJ-p.js").then((n) => n.s);
        return { createStorageService: createStorageService22 };
      }, true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url);
      const storageService = createStorageService2();
      const templates = await ((_a = storageService.listTemplates) == null ? void 0 : _a.call(storageService)) || [];
      const htmlContent = generateBooklistHTML(
        shareGroup,
        groupItems,
        templates,
        shareTitle.trim() || shareGroup.name,
        shareDescription.trim()
      );
      let GITHUB_TOKEN = void 0;
      if (!GITHUB_TOKEN || GITHUB_TOKEN === "your_github_token_here") {
        try {
          const result = await new Promise((resolve) => {
            var _a2, _b, _c;
            (_c = (_b = (_a2 = chrome.storage) == null ? void 0 : _a2.local) == null ? void 0 : _b.get) == null ? void 0 : _c.call(_b, { "github.token": "" }, resolve);
          });
          const savedToken = result == null ? void 0 : result["github.token"];
          if (savedToken) {
            GITHUB_TOKEN = savedToken;
          } else {
            setShowTokenDialog(true);
            return;
          }
        } catch {
          setShowTokenDialog(true);
          return;
        }
      }
      const gistData = {
        description: `LinkTrove 分享：${shareTitle.trim() || shareGroup.name}`,
        public: true,
        files: {
          [`${(shareTitle.trim() || shareGroup.name).replace(/[^\w\s-]/g, "").replace(/\s+/g, "-")}.html`]: {
            content: htmlContent
          }
        }
      };
      const response = await fetch("https://api.github.com/gists", {
        method: "POST",
        headers: {
          "Authorization": `token ${GITHUB_TOKEN}`,
          "Accept": "application/vnd.github.v3+json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(gistData)
      });
      if (!response.ok) {
        throw new Error(`GitHub API error: ${response.status}`);
      }
      const gist = await response.json();
      const filename = Object.keys(gist.files)[0];
      const shareUrl = `https://htmlpreview.github.io/?${gist.files[filename].raw_url}`;
      setShareResultUrl(shareUrl);
      setShareDialogOpen(false);
    } catch (error) {
      console.error("Publish to Gist error:", error);
      showToast("發布分享連結失敗，請稍後重試", "error");
    }
  };
  const generateShareFile = async () => {
    var _a;
    if (!shareGroup) return;
    try {
      const groupItems = items.filter((it) => it.category === categoryId && it.subcategoryId === shareGroup.id);
      const { createStorageService: createStorageService2 } = await __vitePreload(async () => {
        const { createStorageService: createStorageService22 } = await import("./webpageService-CB3FiJ-p.js").then((n) => n.s);
        return { createStorageService: createStorageService22 };
      }, true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url);
      const storageService = createStorageService2();
      const templates = await ((_a = storageService.listTemplates) == null ? void 0 : _a.call(storageService)) || [];
      const htmlContent = generateBooklistHTML(shareGroup, groupItems, templates, shareTitle, shareDescription);
      const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${shareTitle.replace(/[^\w\s-]/g, "") || shareGroup.name.replace(/[^\w\s-]/g, "")}-share.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setShareDialogOpen(false);
      showToast(`已生成「${shareTitle}」分享檔案`, "success");
    } catch (error) {
      console.error("Generate share file error:", error);
      showToast("生成分享檔案失敗", "error");
    }
  };
  if (!svc) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 mt-3", children: [
    groups.map((g) => /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "rounded border border-slate-700 bg-[var(--panel)]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "header",
        {
          className: "flex items-center justify-between px-3 py-2 border-b border-slate-700",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: "text-xs px-1.5 py-0.5 rounded border border-slate-600 hover:bg-slate-800",
                  onClick: () => persistCollapsed({ ...collapsed, [g.id]: !collapsed[g.id] }),
                  "aria-expanded": collapsed[g.id] ? "false" : "true",
                  children: collapsed[g.id] ? "展開" : "摺疊"
                }
              ),
              renaming === g.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  className: "text-sm bg-slate-900 border border-slate-700 rounded px-2 py-1",
                  value: renameText,
                  onChange: (e) => setRenameText(e.target.value),
                  onBlur: () => {
                    setRenaming(null);
                    void rename(g.id, renameText);
                  },
                  onKeyDown: (e) => {
                    if (e.key === "Enter") {
                      setRenaming(null);
                      void rename(g.id, renameText);
                    }
                    if (e.key === "Escape") setRenaming(null);
                  },
                  autoFocus: true
                }
              ) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium", children: g.name })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  id: `html-file-${g.id}`,
                  type: "file",
                  accept: "text/html,.html",
                  "aria-label": "Import HTML bookmarks file",
                  className: "hidden",
                  onChange: async (e) => {
                    var _a;
                    const f = (_a = e.currentTarget.files) == null ? void 0 : _a[0];
                    e.currentTarget.value = "";
                    if (!f) return;
                    try {
                      const text = await f.text();
                      const { importNetscapeHtmlIntoGroup } = await __vitePreload(async () => {
                        const { importNetscapeHtmlIntoGroup: importNetscapeHtmlIntoGroup2 } = await import("./html-CSsQBkNy.js");
                        return { importNetscapeHtmlIntoGroup: importNetscapeHtmlIntoGroup2 };
                      }, true ? __vite__mapDeps([11,1,3]) : void 0, import.meta.url);
                      const res = await importNetscapeHtmlIntoGroup(g.id, g.categoryId, text);
                      await actions.load();
                      showToast(`已匯入 HTML：新增 ${res.pagesCreated} 筆`, "success");
                    } catch (err) {
                      showToast((err == null ? void 0 : err.message) || "匯入失敗", "error");
                    }
                  }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  id: `toby-file-${g.id}`,
                  type: "file",
                  accept: "application/json,.json",
                  "aria-label": "Import Toby JSON file",
                  className: "hidden",
                  onChange: async (e) => {
                    var _a;
                    const f = (_a = e.currentTarget.files) == null ? void 0 : _a[0];
                    e.currentTarget.value = "";
                    if (!f) return;
                    setTobyFile(f);
                    setTobyOpenFor(g.id);
                    try {
                      const txt = await f.text();
                      let count = 0;
                      try {
                        const obj = JSON.parse(txt);
                        if (Array.isArray(obj == null ? void 0 : obj.lists)) {
                          for (const l of obj.lists) if (Array.isArray(l == null ? void 0 : l.cards)) count += l.cards.length;
                        } else if (Array.isArray(obj == null ? void 0 : obj.cards)) {
                          count = obj.cards.length;
                        }
                      } catch {
                      }
                      setTobyPreview({ links: count });
                    } catch {
                      setTobyPreview(null);
                    }
                  }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: "text-xs px-2 py-1 rounded border border-slate-600 hover:bg-slate-800",
                  "aria-label": "更多操作",
                  onClick: (e) => {
                    e.stopPropagation();
                    const vw = typeof window !== "undefined" ? window.innerWidth : 1200;
                    const x = Math.max(8, Math.min(vw - 200, e.clientX - 20));
                    setMenuFor({ id: g.id, x, y: e.clientY + 6 });
                  },
                  children: "⋯"
                }
              )
            ] })
          ]
        }
      ),
      (menuFor == null ? void 0 : menuFor.id) === g.id && /* @__PURE__ */ jsxRuntimeExports.jsx(
        ContextMenu,
        {
          x: menuFor.x,
          y: menuFor.y,
          onClose: () => setMenuFor(null),
          items: [
            { key: "share", label: "分享此群組", onSelect: () => {
              setMenuFor(null);
              void openShareDialog(g);
            } },
            { key: "import-html", label: "匯入 HTML", onSelect: () => {
              var _a;
              setMenuFor(null);
              try {
                (_a = document.getElementById(`html-file-${g.id}`)) == null ? void 0 : _a.click();
              } catch {
              }
            } },
            { key: "import-toby", label: "匯入 Toby", onSelect: () => {
              var _a;
              setMenuFor(null);
              try {
                (_a = document.getElementById(`toby-file-${g.id}`)) == null ? void 0 : _a.click();
              } catch {
              }
            } },
            { key: "rename", label: "重新命名", onSelect: () => {
              setMenuFor(null);
              setRenaming(g.id);
              setRenameText(g.name);
            } },
            { key: "move-up", label: "上移", onSelect: () => {
              setMenuFor(null);
              void move(g.id, -1);
            } },
            { key: "move-down", label: "下移", onSelect: () => {
              setMenuFor(null);
              void move(g.id, 1);
            } },
            { key: "delete", label: "刪除", onSelect: () => {
              setMenuFor(null);
              setConfirmDeleteGroup(g.id);
            } }
          ]
        }
      ),
      !collapsed[g.id] && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        CardGrid,
        {
          items: items.filter((it) => it.category === categoryId && it.subcategoryId === g.id),
          onDropTab: async (tab, beforeId) => {
            var _a;
            try {
              const createdId = await actions.addFromTab(tab);
              await actions.updateCategory(createdId, g.categoryId);
              await ((_a = svc.updateCardSubcategory) == null ? void 0 : _a.call(svc, createdId, g.id));
              if (beforeId && beforeId !== "__END__") {
                dbg("dnd", "onDropTab reorder", { createdId, beforeId });
                await actions.reorder(createdId, beforeId);
              } else if (beforeId === "__END__") {
                dbg("dnd", "onDropTab moveToEnd", { createdId });
                await actions.moveToEnd(createdId);
              }
              await actions.load();
              dbg("dnd", "afterDrop load()", { groupId: g.id });
              showToast("已從分頁建立並加入 group", "success");
            } catch {
              showToast("建立失敗", "error");
            }
          },
          onDropExistingCard: async (cardId, beforeId) => {
            var _a;
            try {
              if (svc.moveCardToGroup) {
                await svc.moveCardToGroup(cardId, g.categoryId, g.id, beforeId);
              } else {
                await actions.updateCategory(cardId, g.categoryId);
                if (!beforeId || beforeId === "__END__") {
                  await ((_a = svc.updateCardSubcategory) == null ? void 0 : _a.call(svc, cardId, g.id));
                  await actions.moveToEnd(cardId);
                } else {
                  await actions.reorder(cardId, beforeId);
                }
              }
              await actions.load();
              try {
                broadcastGhostActive(null);
              } catch {
              }
              showToast("已移動到 group", "success");
            } catch (error) {
              console.error("Move card error:", error);
              try {
                broadcastGhostActive(null);
              } catch {
              }
              showToast("移動失敗", "error");
            }
          },
          onDeleteMany: async (ids) => {
            await actions.deleteMany(ids);
            showToast("Deleted selected", "success");
          },
          onDeleteOne: async (id) => {
            await actions.deleteOne(id);
            showToast("Deleted", "success");
          },
          onEditDescription: async (id, description) => {
            await actions.updateDescription(id, description);
            showToast("Saved note", "success");
          },
          onSave: async (id, patch) => {
            await actions.updateCard(id, patch);
            showToast("Saved", "success");
          },
          onReorder: async (fromId, toId) => {
            await actions.reorder(fromId, toId);
            await actions.load();
          },
          onUpdateTitle: (id, title) => actions.updateTitle(id, title),
          onUpdateUrl: (id, url) => actions.updateUrl(id, url),
          onUpdateCategory: (id, cat) => actions.updateCategory(id, cat),
          onUpdateMeta: (id, meta) => actions.updateMeta(id, meta)
        }
      ) })
    ] }, g.id)),
    confirmDeleteGroup && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3",
        onClick: () => setConfirmDeleteGroup(null),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--bg)] w-[520px] max-w-[95vw]",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "Delete Group",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-slate-700", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold", children: "刪除 Group" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs opacity-80 mt-1", children: "刪除此 group 以及其底下的書籤？此操作無法復原。" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => setConfirmDeleteGroup(null),
                    children: "取消"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-rose-700 text-rose-300 hover:bg-rose-950/30",
                    onClick: async () => {
                      const id = confirmDeleteGroup;
                      setConfirmDeleteGroup(null);
                      if (id) await remove(id);
                    },
                    children: "刪除"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    tobyOpenFor && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3",
        onClick: () => {
          setTobyOpenFor(null);
          setTobyFile(null);
          setTobyPreview(null);
        },
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--bg)] w-[520px] max-w-[95vw] p-5",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "Import Toby",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold", children: "匯入 Toby 到此 group" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 text-sm opacity-80", children: [
                "檔案：",
                tobyFile == null ? void 0 : tobyFile.name,
                " ",
                tobyPreview ? `— 連結 ${tobyPreview.links}` : ""
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: () => {
                  setTobyOpenFor(null);
                  setTobyFile(null);
                  setTobyPreview(null);
                }, children: "取消" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
                    onClick: async () => {
                      const gid = tobyOpenFor;
                      const f = tobyFile;
                      setTobyOpenFor(null);
                      if (!gid || !f) return;
                      try {
                        const text = await f.text();
                        const { importTobyV3IntoGroup } = await __vitePreload(async () => {
                          const { importTobyV3IntoGroup: importTobyV3IntoGroup2 } = await import("./toby-zdfvnhyM.js");
                          return { importTobyV3IntoGroup: importTobyV3IntoGroup2 };
                        }, true ? __vite__mapDeps([12,1,3]) : void 0, import.meta.url);
                        const g = groups.find((x) => x.id === gid);
                        const ctrl = new AbortController();
                        tobyAbortRef.current = ctrl;
                        setTobyProgress({ total: (tobyPreview == null ? void 0 : tobyPreview.links) || 0, processed: 0 });
                        const res = await importTobyV3IntoGroup(gid, (g == null ? void 0 : g.categoryId) || categoryId, text, { signal: ctrl.signal, onProgress: ({ total, processed }) => setTobyProgress({ total, processed }) });
                        await actions.load();
                        showToast(`已匯入 Toby：新增 ${res.pagesCreated} 筆`, "success");
                      } catch (err) {
                        showToast((err == null ? void 0 : err.message) || "匯入失敗", "error");
                      } finally {
                        setTobyFile(null);
                        setTobyPreview(null);
                        setTobyProgress(null);
                        tobyAbortRef.current = null;
                      }
                    },
                    children: "開始匯入"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    tobyProgress && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded border border-slate-700 bg-[var(--bg)] w-[420px] max-w-[90vw] p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold", children: "匯入中…" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 text-sm", children: [
        tobyProgress.processed,
        "/",
        tobyProgress.total
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 h-2 w-full bg-slate-800 rounded", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2 bg-[var(--accent)] rounded", style: { width: `${tobyProgress.total ? Math.min(100, Math.floor(tobyProgress.processed / tobyProgress.total * 100)) : 0}%` } }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 flex items-center justify-end gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: () => {
        var _a;
        try {
          (_a = tobyAbortRef.current) == null ? void 0 : _a.abort();
        } catch {
        }
      }, children: "取消" }) })
    ] }) }),
    shareDialogOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3",
        onClick: () => setShareDialogOpen(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--bg)] w-[520px] max-w-[95vw] p-5",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "分享設定",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-lg font-semibold mb-4", children: [
                "分享「",
                shareGroup == null ? void 0 : shareGroup.name,
                "」"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium mb-2", children: "分享標題" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: shareTitle,
                      onChange: (e) => setShareTitle(e.target.value),
                      placeholder: "自訂分享頁面的標題"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium mb-2", children: "分享描述" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "textarea",
                    {
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm h-20 resize-none",
                      value: shareDescription,
                      onChange: (e) => setShareDescription(e.target.value),
                      placeholder: "簡單描述這個分享的內容"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-400 space-y-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                    "包含 ",
                    items.filter((it) => it.category === categoryId && it.subcategoryId === (shareGroup == null ? void 0 : shareGroup.id)).length,
                    " 個項目"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "📤 ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "發布分享連結" }),
                    "：需要您的 GitHub token，自動上傳到您的 Gist"
                  ] }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                    "💾 ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "下載 HTML" }),
                    "：下載檔案到本機，可手動上傳"
                  ] }) })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => setShareDialogOpen(false),
                    children: "取消"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-green-600 text-green-300 hover:bg-green-950/30 disabled:opacity-50",
                    onClick: publishToGist,
                    disabled: !shareTitle.trim(),
                    title: "發布到 GitHub Gist 並獲得分享連結",
                    children: "發布分享連結"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
                    onClick: generateShareFile,
                    disabled: !shareTitle.trim(),
                    children: "下載 HTML"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    showTokenDialog && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[10000] bg-black/60 flex items-center justify-center p-3",
        onClick: () => {
          setShowTokenDialog(false);
          setGithubToken("");
        },
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--bg)] w-full max-w-md p-6 shadow-2xl",
            onClick: (e) => e.stopPropagation(),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold mb-4", children: "設定 GitHub Token" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-300 mb-3", children: "需要 GitHub Personal Access Token 才能發布分享連結到 Gist" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-400 space-y-2 mb-4", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      "🔗 ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://github.com/settings/tokens", target: "_blank", rel: "noopener", className: "text-blue-400 hover:underline", children: "前往 GitHub 設定頁面" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "📝 點擊「Generate new token (classic)」" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "✅ 勾選「gist」權限（僅需此權限）" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "💾 複製產生的 token" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2 bg-amber-900/20 border border-amber-700/50 rounded text-xs text-amber-200 mb-4", children: "🔒 安全提示：Token 將加密儲存於瀏覽器擴充功能的安全儲存區，不會被網頁或其他擴充功能存取" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium mb-2", children: "GitHub Personal Access Token" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "password",
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: githubToken,
                      onChange: (e) => setGithubToken(e.target.value),
                      placeholder: "ghp_xxxxxxxxxxxxxxxxxxxx"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-slate-400", children: "Token 將安全地儲存在瀏覽器本機，不會上傳到任何伺服器" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => {
                      setShowTokenDialog(false);
                      setGithubToken("");
                    },
                    children: "取消"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-green-600 text-green-300 hover:bg-green-950/30 disabled:opacity-50",
                    onClick: async () => {
                      if (githubToken.trim()) {
                        try {
                          await new Promise((resolve, reject) => {
                            var _a, _b, _c;
                            (_c = (_b = (_a = chrome.storage) == null ? void 0 : _a.local) == null ? void 0 : _b.set) == null ? void 0 : _c.call(_b, { "github.token": githubToken.trim() }, () => {
                              var _a2;
                              if ((_a2 = chrome.runtime) == null ? void 0 : _a2.lastError) {
                                reject(chrome.runtime.lastError);
                              } else {
                                resolve();
                              }
                            });
                          });
                          setShowTokenDialog(false);
                          setGithubToken("");
                          showToast("GitHub Token 已安全儲存！現在可以發布分享連結了", "success");
                          setTimeout(() => publishToGist(), 500);
                        } catch (error) {
                          showToast("儲存 Token 失敗，請重試", "error");
                        }
                      }
                    },
                    disabled: !githubToken.trim(),
                    children: "儲存"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    shareResultUrl && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[10000] bg-black/60 flex items-center justify-center p-4",
        onClick: () => setShareResultUrl(null),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--panel)] w-[560px] max-w-[95vw]",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "分享連結",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-4 py-3 border-b border-slate-700", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-base font-semibold", children: "✅ 分享連結已建立" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm opacity-90 mb-3", children: "您的分享連結已成功發布到 GitHub Gist，可以複製連結分享給他人：" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "text",
                      value: shareResultUrl,
                      readOnly: true,
                      className: "flex-1 px-3 py-2 rounded bg-slate-800 border border-slate-600 text-sm font-mono",
                      onClick: (e) => e.currentTarget.select()
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      className: "px-3 py-2 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] whitespace-nowrap text-sm",
                      onClick: async () => {
                        try {
                          await navigator.clipboard.writeText(shareResultUrl);
                          showToast("已複製到剪貼簿", "success");
                        } catch {
                          showToast("複製失敗，請手動選取複製", "error");
                        }
                      },
                      children: "複製連結"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 text-xs opacity-70", children: [
                  "💡 提示：連結會在您的 GitHub Gist 中永久保存，可隨時在 ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://gist.github.com", target: "_blank", rel: "noopener", className: "text-blue-400 hover:underline", children: "gist.github.com" }),
                  " 管理"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 border-t border-slate-700 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1.5 rounded text-sm border border-slate-600 hover:bg-slate-800",
                    onClick: () => window.open(shareResultUrl, "_blank"),
                    children: "開啟連結"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1.5 rounded text-sm border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)]",
                    onClick: () => setShareResultUrl(null),
                    children: "關閉"
                  }
                )
              ] })
            ]
          }
        )
      }
    )
  ] });
};
const AppLayout = () => {
  const { theme, setTheme } = useApp();
  const [settingsOpen, setSettingsOpen] = React.useState(false);
  React.useEffect(() => {
    __vitePreload(() => import("./syncService-BAxu3TQ3.js"), true ? __vite__mapDeps([6,2,1,3,7,8,9,10]) : void 0, import.meta.url).catch(() => {
    });
  }, []);
  React.useEffect(() => {
    const open = () => setSettingsOpen(true);
    const toggleTheme = () => setTheme(theme === "dracula" ? "gruvbox" : "dracula");
    try {
      window.addEventListener("app:open-settings", open);
    } catch {
    }
    try {
      window.addEventListener("app:toggle-theme", toggleTheme);
    } catch {
    }
    return () => {
      try {
        window.removeEventListener("app:open-settings", open);
      } catch {
      }
      try {
        window.removeEventListener("app:toggle-theme", toggleTheme);
      } catch {
      }
    };
  }, [theme, setTheme]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(FeedbackProvider, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sr-only", children: "LinkTrove Home" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorBoundary, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(OpenTabsProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(OrganizationsProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(CategoriesProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(TemplatesProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(WebpagesProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "toby-mode h-screen flex flex-col bg-[var(--bg)] text-[var(--fg)]", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "p-6 flex-1 overflow-auto min-h-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) }),
      settingsOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(SettingsModal, { open: settingsOpen, onClose: () => setSettingsOpen(false) })
    ] }) }) }) }) }) }) })
  ] });
};
const Home = () => /* @__PURE__ */ jsxRuntimeExports.jsx(HomeInner, {});
const HomeInner = () => {
  const { items, actions: pagesActions } = useWebpages();
  const {
    categories,
    selectedId,
    actions: catActions,
    setCurrentCategory
  } = useCategories();
  const { actions: orgActions, setCurrentOrganization, selectedOrgId } = useOrganizations();
  const [_collapsed, setCollapsed] = React.useState(false);
  const { showToast, setLoading } = useFeedback();
  const [creatingGroup, setCreatingGroup] = React.useState(false);
  const [showAddCat, setShowAddCat] = React.useState(false);
  const [newCatName, setNewCatName] = React.useState("");
  const [newCatColor, setNewCatColor] = React.useState("#64748b");
  const [showAddOrg, setShowAddOrg] = React.useState(false);
  const [newOrgName, setNewOrgName] = React.useState("");
  const [newOrgColor, setNewOrgColor] = React.useState("#64748b");
  const [htmlImportFile, setHtmlImportFile] = React.useState(null);
  const [htmlImportOpen, setHtmlImportOpen] = React.useState(false);
  const [htmlImportName, setHtmlImportName] = React.useState("");
  const [htmlImportMode, setHtmlImportMode] = React.useState("multi");
  const [htmlImportFlatName, setHtmlImportFlatName] = React.useState("Imported");
  const [htmlImportDedup, setHtmlImportDedup] = React.useState(true);
  const [htmlPreview, setHtmlPreview] = React.useState(null);
  const [htmlProgress, setHtmlProgress] = React.useState(null);
  const htmlAbortRef = React.useRef(null);
  const [tobyFile, setTobyFile] = React.useState(null);
  const [tobyOpen, setTobyOpen] = React.useState(false);
  const [tobyName, setTobyName] = React.useState("");
  const [tobyMode, setTobyMode] = React.useState("multi");
  const [tobyFlatName, setTobyFlatName] = React.useState("Imported");
  const [tobyPreview, setTobyPreview] = React.useState(null);
  const [tobyHasOrgs, setTobyHasOrgs] = React.useState(false);
  const [tobyProgress, setTobyProgress] = React.useState(null);
  const tobyAbortRef = React.useRef(null);
  React.useMemo(
    () => items.filter((it) => it.category === selectedId),
    [items, selectedId]
  );
  const [groupsCount, setGroupsCount] = React.useState(0);
  React.useEffect(() => {
    if (!selectedId) return;
    __vitePreload(async () => {
      const { createStorageService: createStorageService2 } = await import("./webpageService-CB3FiJ-p.js").then((n) => n.s);
      return { createStorageService: createStorageService2 };
    }, true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url).then(({ createStorageService: createStorageService2 }) => {
      var _a;
      const svc = createStorageService2();
      (_a = svc.listSubcategories) == null ? void 0 : _a.call(svc, selectedId).then((subcats) => {
        setGroupsCount((subcats == null ? void 0 : subcats.length) || 0);
      }).catch(() => setGroupsCount(0));
    });
  }, [selectedId]);
  React.useEffect(() => {
    const onHtml = () => {
      var _a;
      try {
        (_a = document.getElementById("html-cat-file")) == null ? void 0 : _a.click();
      } catch {
      }
    };
    const onToby = () => {
      var _a;
      try {
        (_a = document.getElementById("toby-cat-file")) == null ? void 0 : _a.click();
      } catch {
      }
    };
    const onAdd = () => {
      setNewCatName("");
      setNewCatColor("#64748b");
      setShowAddCat(true);
    };
    const onAddOrg = () => {
      setNewOrgName("");
      setNewOrgColor("#64748b");
      setShowAddOrg(true);
    };
    try {
      window.addEventListener("collections:import-html-new", onHtml);
    } catch {
    }
    try {
      window.addEventListener("collections:import-toby-new", onToby);
    } catch {
    }
    try {
      window.addEventListener("collections:add-new", onAdd);
    } catch {
    }
    try {
      window.addEventListener("organizations:add-new", onAddOrg);
    } catch {
    }
    return () => {
      try {
        window.removeEventListener("collections:import-html-new", onHtml);
      } catch {
      }
      try {
        window.removeEventListener("collections:import-toby-new", onToby);
      } catch {
      }
      try {
        window.removeEventListener("collections:add-new", onAdd);
      } catch {
      }
      try {
        window.removeEventListener("organizations:add-new", onAddOrg);
      } catch {
      }
    };
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-full min-h-0", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      FourColumnLayout,
      {
        organizationNav: /* @__PURE__ */ jsxRuntimeExports.jsx(OrganizationNav, {}),
        sidebar: /* @__PURE__ */ jsxRuntimeExports.jsx(Sidebar, {}),
        content: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "toby-board-header", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "title-group", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: (() => {
                const currentCategory = categories.find((c) => c.id === selectedId);
                return (currentCategory == null ? void 0 : currentCategory.name) || "Collection";
              })() }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "subtext", children: [
                groupsCount,
                " groups"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "toby-board-actions", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  id: "html-cat-file",
                  type: "file",
                  accept: "text/html,.html",
                  "aria-label": "Import HTML bookmarks to collection",
                  className: "hidden",
                  onChange: async (e) => {
                    var _a;
                    const f = (_a = e.currentTarget.files) == null ? void 0 : _a[0];
                    e.currentTarget.value = "";
                    if (!f) return;
                    setHtmlImportFile(f);
                    setHtmlImportName("");
                    setHtmlImportMode("multi");
                    setHtmlImportFlatName("Imported");
                    setHtmlImportDedup(true);
                    try {
                      const text = await f.text();
                      const mod = await __vitePreload(() => import("./html-CSsQBkNy.js"), true ? __vite__mapDeps([11,1,3]) : void 0, import.meta.url);
                      const map = mod.parseNetscapeGroups(text);
                      let groups = 0;
                      let links = 0;
                      map.forEach((arr) => {
                        groups++;
                        links += (arr == null ? void 0 : arr.length) || 0;
                      });
                      setHtmlPreview({ groups, links });
                    } catch {
                      setHtmlPreview(null);
                    }
                    setHtmlImportOpen(true);
                  }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  id: "toby-cat-file",
                  type: "file",
                  accept: "application/json,.json",
                  "aria-label": "Import Toby JSON to new collection",
                  className: "hidden",
                  onChange: async (e) => {
                    var _a;
                    const f = (_a = e.currentTarget.files) == null ? void 0 : _a[0];
                    e.currentTarget.value = "";
                    if (!f) return;
                    setTobyFile(f);
                    setTobyName("");
                    setTobyFlatName("Imported");
                    setTobyMode("multi");
                    try {
                      const text = await f.text();
                      const obj = JSON.parse(text);
                      let lists = 0;
                      let links = 0;
                      let hasOrgs = false;
                      if (Array.isArray(obj == null ? void 0 : obj.lists)) {
                        lists = obj.lists.length;
                        for (const l of obj.lists) if (Array.isArray(l == null ? void 0 : l.cards)) links += l.cards.length;
                      }
                      if (Array.isArray(obj == null ? void 0 : obj.groups)) {
                        hasOrgs = true;
                        for (const g of obj.groups) if (Array.isArray(g == null ? void 0 : g.lists)) {
                          lists += g.lists.length;
                          for (const l of g.lists) if (Array.isArray(l == null ? void 0 : l.cards)) links += l.cards.length;
                        }
                      }
                      if (Array.isArray(obj == null ? void 0 : obj.organizations)) {
                        hasOrgs = true;
                        for (const o of obj.organizations) if (Array.isArray(o == null ? void 0 : o.groups)) {
                          for (const g of o.groups) if (Array.isArray(g == null ? void 0 : g.lists)) {
                            lists += g.lists.length;
                            for (const l of g.lists) if (Array.isArray(l == null ? void 0 : l.cards)) links += l.cards.length;
                          }
                        }
                      }
                      setTobyPreview({ lists, links });
                      setTobyHasOrgs(hasOrgs);
                    } catch {
                      setTobyPreview(null);
                      setTobyHasOrgs(false);
                    }
                    setTobyOpen(true);
                  }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: "px-2 py-1 rounded border border-slate-600 hover:bg-slate-800 mr-2",
                  title: "新增 group",
                  "aria-label": "新增 group",
                  disabled: creatingGroup || !selectedId || !categories.find((c) => c.id === selectedId),
                  onClick: async () => {
                    var _a, _b;
                    try {
                      if (creatingGroup || !selectedId) return;
                      const currentCategory = categories.find((c) => c.id === selectedId);
                      if (!currentCategory) {
                        showToast("請先選擇一個 Collection", "error");
                        return;
                      }
                      setCreatingGroup(true);
                      const { createStorageService: createStorageService2 } = await __vitePreload(async () => {
                        const { createStorageService: createStorageService22 } = await import("./webpageService-CB3FiJ-p.js").then((n) => n.s);
                        return { createStorageService: createStorageService22 };
                      }, true ? __vite__mapDeps([2,1,3]) : void 0, import.meta.url);
                      const s = createStorageService2();
                      const list = await ((_a = s.listSubcategories) == null ? void 0 : _a.call(s, selectedId)) || [];
                      const lower = new Set(list.map((x) => String(x.name || "").toLowerCase()));
                      let name = "group";
                      let i = 2;
                      while (lower.has(name.toLowerCase())) name = `group ${i++}`;
                      await ((_b = s.createSubcategory) == null ? void 0 : _b.call(s, selectedId, name));
                      try {
                        window.dispatchEvent(new CustomEvent("groups:changed"));
                      } catch {
                      }
                      showToast(`已新增 ${name}`, "success");
                    } catch {
                      showToast("新增失敗", "error");
                    } finally {
                      setCreatingGroup(false);
                    }
                  },
                  children: "新增 group"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: "link muted",
                  title: "Expand all groups in this collection",
                  onClick: () => {
                    try {
                      window.dispatchEvent(
                        new CustomEvent("groups:collapse-all", {
                          detail: { categoryId: selectedId, collapsed: false }
                        })
                      );
                    } catch {
                    }
                    setCollapsed(false);
                  },
                  children: "EXPAND"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  className: "link muted",
                  title: "Collapse all groups in this collection",
                  onClick: () => {
                    try {
                      window.dispatchEvent(
                        new CustomEvent("groups:collapse-all", {
                          detail: { categoryId: selectedId, collapsed: true }
                        })
                      );
                    } catch {
                    }
                    setCollapsed(true);
                  },
                  children: "COLLAPSE"
                }
              )
            ] })
          ] }),
          selectedId && (() => {
            const currentCategory = categories.find((c) => c.id === selectedId);
            return currentCategory ? /* @__PURE__ */ jsxRuntimeExports.jsx(GroupsView, { categoryId: selectedId }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-12 text-[var(--muted)]", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg mb-2", children: "No collection selected" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm", children: "Create a new collection or select an existing one from the sidebar" })
            ] });
          })()
        ] }),
        tabsPanel: /* @__PURE__ */ jsxRuntimeExports.jsx(TabsPanel, {})
      }
    ),
    showAddCat && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/60",
        onClick: () => setShowAddCat(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--panel)] p-5 w-[420px] max-w-[90vw]",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "Add Collection",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-medium mb-3", children: "New Collection" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "Name" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: newCatName,
                      onChange: (e) => setNewCatName(e.target.value),
                      placeholder: "My Collection"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "Color" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "color",
                      className: "rounded border border-slate-700 bg-slate-900 p-1",
                      value: newCatColor,
                      onChange: (e) => setNewCatColor(e.target.value)
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "Template" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(TemplatePicker, {})
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => setShowAddCat(false),
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
                    disabled: !newCatName.trim(),
                    onClick: async () => {
                      var _a;
                      const cat = await catActions.addCategory(
                        newCatName.trim(),
                        newCatColor
                      );
                      const sel = ((_a = document.getElementById(
                        "tpl-select"
                      )) == null ? void 0 : _a.value) || "";
                      if (sel) await catActions.setDefaultTemplate(cat.id, sel);
                      setCurrentCategory(cat.id);
                      setShowAddCat(false);
                    },
                    children: "Create"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    showAddOrg && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/60",
        onClick: () => setShowAddOrg(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--panel)] p-5 w-[420px] max-w-[90vw]",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "Add Organization",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-medium mb-3", children: "New Organization" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "Name" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: newOrgName,
                      onChange: (e) => setNewOrgName(e.target.value),
                      placeholder: "My Organization"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "Color" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "color",
                      className: "rounded border border-slate-700 bg-slate-900 p-1",
                      value: newOrgColor,
                      onChange: (e) => setNewOrgColor(e.target.value)
                    }
                  )
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => setShowAddOrg(false),
                    children: "Cancel"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
                    disabled: !newOrgName.trim(),
                    onClick: async () => {
                      const org = await orgActions.add(newOrgName.trim(), newOrgColor);
                      setCurrentOrganization(org.id);
                      setShowAddOrg(false);
                      showToast(`Created organization "${org.name}"`, "success");
                    },
                    children: "Create"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    htmlImportOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/60",
        onClick: () => setHtmlImportOpen(false),
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "rounded border border-slate-700 bg-[var(--panel)] p-5 w-[420px] max-w-[90vw]",
            onClick: (e) => e.stopPropagation(),
            role: "dialog",
            "aria-label": "Import HTML to new Collection",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-medium mb-3", children: "匯入 HTML（新集合）" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm opacity-80", children: [
                  "檔案：",
                  htmlImportFile == null ? void 0 : htmlImportFile.name
                ] }),
                htmlPreview && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs opacity-80", children: [
                  "預覽：群組 ",
                  htmlPreview.groups,
                  "、連結 ",
                  htmlPreview.links
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "集合名稱（可留空自動命名）" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: htmlImportName,
                      onChange: (e) => setHtmlImportName(e.target.value),
                      placeholder: "Imported"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "匯入模式" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 text-sm", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "radio", name: "html-mode", checked: htmlImportMode === "multi", onChange: () => setHtmlImportMode("multi") }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "依資料夾建立多群組" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "radio", name: "html-mode", checked: htmlImportMode === "flat", onChange: () => setHtmlImportMode("flat") }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "扁平匯入到單一群組" })
                    ] })
                  ] })
                ] }),
                htmlImportMode === "flat" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "群組名稱" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
                      value: htmlImportFlatName,
                      onChange: (e) => setHtmlImportFlatName(e.target.value),
                      placeholder: "Imported"
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-2 text-sm", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: htmlImportDedup, onChange: (e) => setHtmlImportDedup(e.currentTarget.checked) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "略過集合內已存在的相同 URL" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center justify-end gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                    onClick: () => setHtmlImportOpen(false),
                    children: "取消"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "button",
                  {
                    className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
                    onClick: async () => {
                      var _a;
                      if (!htmlImportFile) {
                        setHtmlImportOpen(false);
                        return;
                      }
                      setHtmlImportOpen(false);
                      setLoading(true);
                      try {
                        const text = await htmlImportFile.text();
                        const { importNetscapeHtmlAsNewCategory } = await __vitePreload(async () => {
                          const { importNetscapeHtmlAsNewCategory: importNetscapeHtmlAsNewCategory2 } = await import("./html-CSsQBkNy.js");
                          return { importNetscapeHtmlAsNewCategory: importNetscapeHtmlAsNewCategory2 };
                        }, true ? __vite__mapDeps([11,1,3]) : void 0, import.meta.url);
                        const ctrl = new AbortController();
                        htmlAbortRef.current = ctrl;
                        setHtmlProgress({ total: (htmlPreview == null ? void 0 : htmlPreview.links) || 0, processed: 0 });
                        const res = await importNetscapeHtmlAsNewCategory(text, {
                          name: htmlImportName.trim() || void 0,
                          organizationId: selectedOrgId,
                          mode: htmlImportMode,
                          flatGroupName: htmlImportFlatName.trim() || void 0,
                          dedupSkip: htmlImportDedup,
                          signal: ctrl.signal,
                          onProgress: ({ total, processed }) => setHtmlProgress({ total, processed })
                        });
                        try {
                          await pagesActions.load();
                        } catch {
                        }
                        try {
                          await ((_a = catActions == null ? void 0 : catActions.reload) == null ? void 0 : _a.call(catActions));
                        } catch {
                        }
                        try {
                          setCurrentCategory(res.categoryId);
                        } catch {
                        }
                        try {
                          window.dispatchEvent(new CustomEvent("groups:changed"));
                        } catch {
                        }
                        showToast(`已匯入 HTML 至新集合「${res.categoryName}」：新增 ${res.pagesCreated} 筆，群組 ${res.groupsCreated}`, "success");
                      } catch (err) {
                        const msg = err && (err.message || String(err)) || "匯入失敗";
                        showToast(msg, "error");
                      } finally {
                        setLoading(false);
                        setHtmlImportFile(null);
                        setHtmlImportName("");
                        setHtmlPreview(null);
                        setHtmlProgress(null);
                        htmlAbortRef.current = null;
                      }
                    },
                    children: "開始匯入"
                  }
                )
              ] })
            ]
          }
        )
      }
    ),
    tobyOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/60", onClick: () => setTobyOpen(false), children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded border border-slate-700 bg-[var(--panel)] p-5 w-[420px] max-w-[90vw]", onClick: (e) => e.stopPropagation(), role: "dialog", "aria-label": "Import Toby to new Organization", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-medium mb-3", children: "匯入 Toby（新 Organization）" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm opacity-80", children: [
          "檔案：",
          tobyFile == null ? void 0 : tobyFile.name
        ] }),
        tobyPreview && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs opacity-80", children: [
          "預覽：lists ",
          tobyPreview.lists,
          "、連結 ",
          tobyPreview.links
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: tobyHasOrgs ? "Organization 名稱（可留空自動命名）" : "集合名稱（可留空自動命名）" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm", value: tobyName, onChange: (e) => setTobyName(e.target.value), placeholder: "Imported" })
        ] }),
        !tobyHasOrgs && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "匯入模式" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "radio", name: "toby-mode", checked: tobyMode === "multi", onChange: () => setTobyMode("multi") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "lists → 多群組" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "inline-flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "radio", name: "toby-mode", checked: tobyMode === "flat", onChange: () => setTobyMode("flat") }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "扁平至單一群組" })
              ] })
            ] })
          ] }),
          tobyMode === "flat" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm mb-1", children: "群組名稱" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm", value: tobyFlatName, onChange: (e) => setTobyFlatName(e.target.value), placeholder: "Imported" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center justify-end gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: () => setTobyOpen(false), children: "取消" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)]", onClick: async () => {
          var _a, _b, _c, _d;
          if (!tobyFile) {
            setTobyOpen(false);
            return;
          }
          setTobyOpen(false);
          setLoading(true);
          try {
            const text = await tobyFile.text();
            const { importTobyAsNewCategory, importTobyV4WithOrganizations } = await __vitePreload(async () => {
              const { importTobyAsNewCategory: importTobyAsNewCategory2, importTobyV4WithOrganizations: importTobyV4WithOrganizations2 } = await import("./toby-zdfvnhyM.js");
              return { importTobyAsNewCategory: importTobyAsNewCategory2, importTobyV4WithOrganizations: importTobyV4WithOrganizations2 };
            }, true ? __vite__mapDeps([12,1,3]) : void 0, import.meta.url);
            const ctrl = new AbortController();
            tobyAbortRef.current = ctrl;
            setTobyProgress({ total: (tobyPreview == null ? void 0 : tobyPreview.links) || 0, processed: 0 });
            if (tobyHasOrgs) {
              const res = await importTobyV4WithOrganizations(text, { createOrganizations: true, organizationName: tobyName.trim() || void 0, signal: ctrl.signal, onProgress: ({ total, processed }) => setTobyProgress({ total, processed }) });
              try {
                await ((_a = orgActions == null ? void 0 : orgActions.reload) == null ? void 0 : _a.call(orgActions));
              } catch {
              }
              try {
                await pagesActions.load();
              } catch {
              }
              try {
                await ((_b = catActions == null ? void 0 : catActions.reload) == null ? void 0 : _b.call(catActions));
              } catch {
              }
              if (((_c = res.organizationIds) == null ? void 0 : _c.length) > 0) {
                setCurrentOrganization(res.organizationIds[0]);
              }
              try {
                window.dispatchEvent(new CustomEvent("groups:changed"));
              } catch {
              }
              showToast(`已匯入 Toby (groups→orgs)：建立 org ${res.orgsCreated}、集合 ${res.categoriesCreated}、群組 ${res.groupsCreated}、卡片 ${res.pagesCreated}`, "success");
            } else {
              const res = await importTobyAsNewCategory(text, { name: tobyName.trim() || void 0, organizationId: selectedOrgId, mode: tobyMode, flatGroupName: tobyFlatName.trim() || void 0, signal: ctrl.signal, onProgress: ({ total, processed }) => setTobyProgress({ total, processed }) });
              try {
                await pagesActions.load();
              } catch {
              }
              try {
                await ((_d = catActions == null ? void 0 : catActions.reload) == null ? void 0 : _d.call(catActions));
              } catch {
              }
              try {
                setCurrentCategory(res.categoryId);
              } catch {
              }
              try {
                window.dispatchEvent(new CustomEvent("groups:changed"));
              } catch {
              }
              showToast(`已匯入 Toby 至新集合「${res.categoryName}」：新增 ${res.pagesCreated} 筆，群組 ${res.groupsCreated}`, "success");
            }
          } catch (err) {
            showToast((err == null ? void 0 : err.message) || "匯入失敗", "error");
          } finally {
            setLoading(false);
            setTobyFile(null);
            setTobyPreview(null);
            setTobyProgress(null);
            tobyAbortRef.current = null;
          }
        }, children: "開始匯入" })
      ] })
    ] }) }),
    tobyProgress && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded border border-slate-700 bg-[var(--panel)] w-[420px] max-w-[90vw] p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold", children: "匯入中…" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 text-sm", children: [
        tobyProgress.processed,
        "/",
        tobyProgress.total
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 h-2 w-full bg-slate-800 rounded", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2 bg-[var(--accent)] rounded", style: { width: `${tobyProgress.total ? Math.min(100, Math.floor(tobyProgress.processed / tobyProgress.total * 100)) : 0}%` } }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 flex items-center justify-end gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: () => {
        var _a;
        try {
          (_a = tobyAbortRef.current) == null ? void 0 : _a.abort();
        } catch {
        }
      }, children: "取消" }) })
    ] }) }),
    htmlProgress && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded border border-slate-700 bg-[var(--panel)] w-[420px] max-w-[90vw] p-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold", children: "匯入中…" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 text-sm", children: [
        htmlProgress.processed,
        "/",
        htmlProgress.total
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 h-2 w-full bg-slate-800 rounded", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2 bg-[var(--accent)] rounded", style: { width: `${htmlProgress.total ? Math.min(100, Math.floor(htmlProgress.processed / htmlProgress.total * 100)) : 0}%` } }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 flex items-center justify-end gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800", onClick: () => {
        var _a;
        try {
          (_a = htmlAbortRef.current) == null ? void 0 : _a.abort();
        } catch {
        }
      }, children: "取消" }) })
    ] }) })
  ] });
};
const TemplatePicker = () => {
  const { templates } = useTemplates();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "select",
    {
      id: "tpl-select",
      className: "w-full rounded bg-slate-900 border border-slate-700 p-2 text-sm",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "None" }),
        templates.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: t.id, children: t.name }, t.id))
      ]
    }
  );
};
const Settings = ({ ei }) => {
  const svc = React.useMemo(
    () => ei != null ? ei : createExportImportService({ storage: createStorageService() }),
    [ei]
  );
  const { showToast, setLoading } = useFeedback();
  const [file, setFile] = React.useState(null);
  const [confirmOpen, setConfirmOpen] = React.useState(false);
  const [inlineMsg, setInlineMsg] = React.useState(null);
  const { actions: pagesActions } = useWebpages();
  const { actions: catActions } = useCategories();
  const { actions: tplActions } = useTemplates();
  function humanSize(n) {
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  }
  async function performImport() {
    var _a, _b;
    if (!file) {
      showToast("請選擇 JSON 檔案", "error");
      return;
    }
    setConfirmOpen(false);
    setLoading(true);
    setInlineMsg(null);
    try {
      const text = await (async () => {
        try {
          if (typeof file.text === "function") return await file.text();
        } catch {
        }
        try {
          return await new Response(file).text();
        } catch {
          const content = await new Promise((resolve, reject) => {
            try {
              const fr = new FileReader();
              fr.onerror = () => reject(fr.error);
              fr.onload = () => resolve(String(fr.result || ""));
              fr.readAsText(file);
            } catch (e) {
              reject(e);
            }
          });
          return content;
        }
      })();
      let pagesCount = 0;
      let catsCount = 0;
      let parsedOk2 = false;
      try {
        const parsed = JSON.parse(text);
        pagesCount = Array.isArray(parsed == null ? void 0 : parsed.webpages) ? parsed.webpages.length : 0;
        catsCount = Array.isArray(parsed == null ? void 0 : parsed.categories) ? parsed.categories.length : 0;
        parsedOk2 = true;
      } catch {
      }
      setInlineMsg({ kind: "success", text: `Imported: ${pagesCount} pages, ${catsCount} categories` });
      if (ei) {
        await svc.importJsonMerge(text);
      } else {
        const storage = createStorageService();
        await storage.importData(text);
      }
      try {
        await pagesActions.load();
      } catch {
      }
      try {
        await ((_a = catActions == null ? void 0 : catActions.reload) == null ? void 0 : _a.call(catActions));
      } catch {
      }
      try {
        await ((_b = tplActions == null ? void 0 : tplActions.reload) == null ? void 0 : _b.call(tplActions));
      } catch {
      }
      const summary = `Imported: ${pagesCount} pages, ${catsCount} categories`;
      setInlineMsg({ kind: "success", text: summary });
      showToast("Import success", "success");
    } catch (e) {
      const msg = (e == null ? void 0 : e.message) || "Import failed";
      if (msg === "Invalid JSON" || !parsedOk) showToast("Invalid JSON", "error");
    } finally {
      setLoading(false);
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold mb-4", children: "Settings" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded border border-slate-700 bg-[var(--panel)] p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-2 text-lg font-semibold", children: "專案備份與還原（僅本專案）" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm opacity-80 mb-4", children: "此區塊用於本專案格式的 JSON 備份與還原，僅適用於本專案資料的匯出/匯入。 與「群組」的匯出/匯入不同（可對接外部來源或其他服務），這裡的匯入會完全取代目前資料，建議先匯出備份。" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium mb-2", children: "匯出備份（本專案格式）" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                className: "text-sm px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                onClick: async () => {
                  setLoading(true);
                  try {
                    const json = await svc.exportJson();
                    const blob = new Blob([json], { type: "application/json" });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = "linktrove-export.json";
                    a.click();
                    URL.revokeObjectURL(url);
                    showToast("Export ready", "success");
                  } catch {
                    showToast("Export failed", "error");
                  } finally {
                    setLoading(false);
                  }
                },
                children: "Export JSON"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-slate-700 pt-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium mb-2", children: "還原（取代現有資料）" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "div",
              {
                className: "rounded border-2 border-dashed border-slate-600 hover:border-[var(--accent)] hover:bg-[var(--accent-hover)] p-3 text-sm",
                onDragOver: (e) => e.preventDefault(),
                onDrop: async (e) => {
                  var _a;
                  e.preventDefault();
                  const f = (_a = e.dataTransfer.files) == null ? void 0 : _a[0];
                  if (f) setFile(f);
                },
                children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 flex-wrap", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      id: "import-json-file",
                      "aria-label": "Import JSON file",
                      type: "file",
                      accept: "application/json,.json",
                      className: "text-sm",
                      onChange: async (e) => {
                        var _a, _b;
                        const f = (_b = (_a = e.currentTarget.files) == null ? void 0 : _a[0]) != null ? _b : null;
                        setFile(f);
                      },
                      onClick: (e) => {
                        e.currentTarget.value = "";
                      }
                    }
                  ),
                  file && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs opacity-80", children: [
                    file.name,
                    " — ",
                    humanSize(file.size)
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "button",
                    {
                      className: "ml-auto text-sm px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)] disabled:opacity-50",
                      disabled: !file,
                      onClick: () => {
                        if (!file) return showToast("請選擇 JSON 檔案", "error");
                        if (ei) {
                          void performImport();
                        } else {
                          setConfirmOpen(true);
                        }
                      },
                      children: "Import JSON"
                    }
                  )
                ] })
              }
            )
          ] })
        ] }),
        inlineMsg && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: `mt-3 text-sm px-3 py-2 rounded border ${"bg-[var(--accent-hover)] border-[var(--accent)]/60"}`,
            children: inlineMsg.text
          }
        ),
        confirmOpen && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "fixed inset-0 z-[9999] bg-black/60 flex items-center justify-center p-3",
            onClick: () => setConfirmOpen(false),
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "rounded border border-slate-700 bg-[var(--panel)] w-[520px] max-w-[95vw]",
                onClick: (e) => e.stopPropagation(),
                role: "dialog",
                "aria-label": "Confirm Import",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-4 border-b border-slate-700", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-semibold", children: "確認匯入" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs opacity-80 mt-1", children: [
                      "將取代現有資料。檔案：",
                      file ? `${file.name} — ${humanSize(file.size)}` : ""
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-5 py-3 flex items-center justify-end gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        className: "px-3 py-1 rounded border border-slate-600 hover:bg-slate-800",
                        onClick: () => setConfirmOpen(false),
                        children: "取消"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        className: "px-3 py-1 rounded border border-[var(--accent)] text-[var(--accent)] hover:bg-[var(--accent-hover)]",
                        onClick: performImport,
                        children: "確認匯入"
                      }
                    )
                  ] })
                ]
              }
            )
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(TemplatesManager, {})
    ] })
  ] });
};
const router = createHashRouter([
  {
    path: "/",
    element: /* @__PURE__ */ jsxRuntimeExports.jsx(AppLayout, {}),
    children: [
      { index: true, element: /* @__PURE__ */ jsxRuntimeExports.jsx(Home, {}) },
      { path: "settings", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, {}) },
      { path: "*", element: /* @__PURE__ */ jsxRuntimeExports.jsx(Navigate, { to: "/", replace: true }) }
    ]
  }
]);
client.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(AppProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(RouterProvider, { router }) }) })
);
export {
  createExportImportService as c,
  metaAutoFill as m
};
//# sourceMappingURL=newtab-CEENaU6l.js.map

async function compressString(text) {
  const blob = new Blob([text]);
  const stream = blob.stream();
  const compressedStream = stream.pipeThrough(new CompressionStream("gzip"));
  const compressedBlob = await new Response(compressedStream).blob();
  return new Uint8Array(await compressedBlob.arrayBuffer());
}
async function decompressString(data) {
  const blob = new Blob([data]);
  const stream = blob.stream();
  const decompressedStream = stream.pipeThrough(new DecompressionStream("gzip"));
  const decompressedBlob = await new Response(decompressedStream).blob();
  return await decompressedBlob.text();
}
async function getAuthToken(interactive = false) {
  return new Promise((resolve, reject) => {
    try {
      chrome.identity.getAuthToken({ interactive }, (token) => {
        var _a;
        const err = (_a = chrome.runtime) == null ? void 0 : _a.lastError;
        if (token) resolve(token);
        else reject(new Error((err == null ? void 0 : err.message) || "Failed to obtain auth token"));
      });
    } catch (e) {
      reject(e);
    }
  });
}
async function driveFetch(path, init = {}, interactive = false) {
  const token = await getAuthToken(interactive);
  const res = await fetch(`https://www.googleapis.com${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...init.headers || {}
    }
  });
  if (!res.ok) {
    if (res.status === 401 && !interactive) return driveFetch(path, init, true);
    const text = await res.text().catch(() => "");
    throw new Error(`Drive API error ${res.status}: ${text}`);
  }
  return res;
}
async function connect(interactive = true) {
  await getAuthToken(interactive);
  await driveFetch(
    `/drive/v3/files?q='appDataFolder'+in+parents&spaces=appDataFolder&fields=files(id)&pageSize=1`,
    {},
    interactive
  );
  return { ok: true };
}
async function getFile(name = "linktrove.json.gz") {
  let res = await driveFetch(
    `/drive/v3/files?q='appDataFolder'+in+parents+and+name='${encodeURIComponent(
      name
    )}'&spaces=appDataFolder&fields=files(id,name,modifiedTime,md5Checksum)&pageSize=1`
  );
  let data = await res.json();
  let f = ((data == null ? void 0 : data.files) || [])[0];
  if (!f && name === "linktrove.json.gz") {
    res = await driveFetch(
      `/drive/v3/files?q='appDataFolder'+in+parents+and+name='linktrove.json'&spaces=appDataFolder&fields=files(id,name,modifiedTime,md5Checksum)&pageSize=1`
    );
    data = await res.json();
    f = ((data == null ? void 0 : data.files) || [])[0];
  }
  if (!f) return null;
  return {
    fileId: f.id,
    modifiedTime: f.modifiedTime,
    md5Checksum: f.md5Checksum
  };
}
async function download(fileId) {
  const res = await driveFetch(`/drive/v3/files/${fileId}?alt=media`);
  const arrayBuffer = await res.arrayBuffer();
  const data = new Uint8Array(arrayBuffer);
  if (data.length >= 2 && data[0] === 31 && data[1] === 139) {
    try {
      return await decompressString(data);
    } catch (e) {
      console.warn("Decompression failed, treating as plain text:", e);
      return new TextDecoder().decode(data);
    }
  }
  return new TextDecoder().decode(data);
}
async function createOrUpdate(content, name = "linktrove.json.gz") {
  const compressed = await compressString(content);
  const originalSize = new Blob([content]).size;
  const compressedSize = compressed.length;
  console.log(`[Drive] Compression: ${originalSize} → ${compressedSize} bytes (${(compressedSize / originalSize * 100).toFixed(1)}%)`);
  const existing = await getFile(name);
  if (!existing) {
    const metadata = { name, parents: ["appDataFolder"] };
    const boundary = "-------lnktrove" + Math.random().toString(36).slice(2);
    const metadataPart = `--${boundary}\r
Content-Type: application/json; charset=UTF-8\r
\r
${JSON.stringify(metadata)}\r
`;
    const contentPart = `--${boundary}\r
Content-Type: application/gzip\r
\r
`;
    const endBoundary = `\r
--${boundary}--`;
    const encoder = new TextEncoder();
    const metadataBytes = encoder.encode(metadataPart);
    const contentBytes = encoder.encode(contentPart);
    const endBytes = encoder.encode(endBoundary);
    const body = new Uint8Array(metadataBytes.length + contentBytes.length + compressed.length + endBytes.length);
    body.set(metadataBytes, 0);
    body.set(contentBytes, metadataBytes.length);
    body.set(compressed, metadataBytes.length + contentBytes.length);
    body.set(endBytes, metadataBytes.length + contentBytes.length + compressed.length);
    const res = await driveFetch(`/upload/drive/v3/files?uploadType=multipart`, {
      method: "POST",
      headers: { "Content-Type": `multipart/related; boundary=${boundary}` },
      body
    });
    const data = await res.json();
    return {
      fileId: data.id,
      modifiedTime: data.modifiedTime,
      md5Checksum: data.md5Checksum
    };
  } else {
    await driveFetch(`/upload/drive/v3/files/${existing.fileId}?uploadType=media`, {
      method: "PATCH",
      headers: { "Content-Type": "application/gzip" },
      body: compressed
    });
    const refreshed = await getFile(name);
    return refreshed || {
      fileId: existing.fileId,
      modifiedTime: existing.modifiedTime,
      md5Checksum: existing.md5Checksum
    };
  }
}
async function disconnect() {
  try {
    chrome.identity.getAuthToken({ interactive: false }, (token) => {
      if (!token) return;
      try {
        chrome.identity.removeCachedAuthToken({ token }, () => {
        });
      } catch {
      }
    });
  } catch {
  }
}
export {
  connect,
  createOrUpdate,
  disconnect,
  download,
  getFile
};
//# sourceMappingURL=googleDrive-CyCKFRry.js.map
